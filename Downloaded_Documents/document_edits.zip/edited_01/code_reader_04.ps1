# =========================================================================================
# This script writes a Markdown file that contains:
#   1) A folder/file tree of the current directory (with exclusions)
#   2) The source code of each included file (with syntax fences)
# It preserves the original behavior but adds three clear user-editable lists:
#   - $UserIgnoredFolderNames  (ignore these folder NAMES anywhere in the tree)
#   - $UserIgnoredFileNames    (ignore these exact file NAMES, e.g., 'db.sqlite3', '.env')
#   - $UserIgnoredExtensions   (ignore these file extensions anywhere in the tree)
#
# Both the tree generation and the code extraction use the same ignore rules.
# =========================================================================================

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# ---------------------------------------------
# EDIT HERE #1: Folder names to ignore (add just the folder name, not a path)
# Example: "node_modules", "dist", ".git", "__pycache__"
# ---------------------------------------------
$UserIgnoredFolderNames = @(
    # "dist",
    # "build",
    # "node_modules"
    "_runtime_backup",
    "data",
    "logs",
    "_code_copy_02",
    "_code_copy_03"
)

# ---------------------------------------------
# EDIT HERE #2: File NAMES to ignore (exact leaf names)
# Example: "db.sqlite3", ".env"
# ---------------------------------------------
$UserIgnoredFileNames = @(
    ".env", "db.sqlite3"
)

# ---------------------------------------------
# EDIT HERE #3: File extensions to ignore (add with leading dot)
# Example: ".md", ".ps1", ".png", ".zip"
# ---------------------------------------------
$UserIgnoredExtensions = @(
    ".log",
    ".ps1", ".md",
    ".csv", "xls", ".xlsx",
    ".pdf", 
    ".rar", ".zip",
    "jpg", ".jpeg", ".gif", '.webp', ".png",
    ".ico", ".svg", ".woff"
)

# Output markdown file
$outputFile = "full_folder_and_file_and_code_data.md"

# Clear or create output file
Set-Content -Path $outputFile -Value "" -Encoding utf8

# Resolve paths for exclusion of the output file and this script itself
$excludePath     = (Resolve-Path $outputFile).Path
$selfScriptPath  = (Resolve-Path $MyInvocation.MyCommand.Path).Path

# ---------------------------------------------
# Default exclusions (kept from your original logic)
# We will combine these with the user lists above.
# ---------------------------------------------
$DefaultIgnoredFolderNames = @(
    ".qodo", ".git", "venv", ".venv", "__pycache__", "prompts_and_codes",
    "ignore", ".ignore", "node_modules", "dist", "build", ".next", ".nuxt",
    ".parcel-cache", ".turbo", "_runtime_backup"
)

$DefaultIgnoredExtensions = @(
    '.pyc', '.pyd', '.dll', '.exe', '.png', '.jpg', '.jpeg', '.gif', '.pdf',
    '.docx', '.csv', '.ps1', '.md', '.rar', '.zip', '.ico', '.svg', '.woff',
    '.ttf', '.eot', '.mp4', '.mp3'
)

# NEW: default file NAMES to ignore (adds name-based ignoring without changing your logic)
$DefaultIgnoredFileNames = @(
    "Thumbs.db", "desktop.ini"
)

# Combine & normalize the ignore lists (lowercase, unique)
$IgnoreFolderNames = @($DefaultIgnoredFolderNames + $UserIgnoredFolderNames) |
    ForEach-Object { $_.ToLower() } | Select-Object -Unique

$IgnoreExtensions = @($DefaultIgnoredExtensions + $UserIgnoredExtensions) |
    ForEach-Object { $_.ToLower() } | Select-Object -Unique

# NEW: combine filenames
$IgnoreFileNames = @($DefaultIgnoredFileNames + $UserIgnoredFileNames) |
    ForEach-Object { $_.ToLower() } | Select-Object -Unique

# Build a single regex that matches any ignored folder name as a path segment,
# at ANY depth, with either "\" or "/" as separators (Windows & POSIX safe).
# Example match: "\node_modules\", "/.git", "...\dist\file.js"
$EscapedNames = $IgnoreFolderNames | ForEach-Object { [regex]::Escape($_) }
$IgnoredFoldersRegex = "(^|[\\/])(" + ($EscapedNames -join "|") + ")(?=([\\/]|$))"

# Map extensions to Markdown syntax highlighting (unchanged)
$extToLang = @{
    '.py'   = 'python'
    '.js'   = 'javascript'
    '.ts'   = 'typescript'
    '.vue'  = 'html'
    '.html' = 'html'
    '.css'  = 'css'
    '.json' = 'json'
    '.md'   = 'markdown'
    '.sh'   = 'bash'
    '.txt'  = ''
}

# ---------------------------------------------
# Helper functions
# ---------------------------------------------

function Test-PathHasIgnoredFolder {
    <#
      .SYNOPSIS
        Returns $true if $Path contains ANY ignored folder name at any depth.

      .PARAMETER Path
        Full file or directory path to test.

      .NOTES
        Uses a compiled regex built from $IgnoreFolderNames so the same rule
        applies to both the tree and code-dump phases.
    #>
    param([Parameter(Mandatory=$true)][string]$Path)
    $lower = $Path.ToLower()
    return ($lower -match $IgnoredFoldersRegex)
}

function Test-IsIgnoredFile {
    <#
      .SYNOPSIS
        Returns $true if the file should be ignored based on filename or extension,
        or if it is the output file or this script file.

      .PARAMETER FileInfo
        A FileInfo object (e.g., from Get-ChildItem).
    #>
    param([Parameter(Mandatory=$true)][System.IO.FileInfo]$FileInfo)

    # Never include the output file or this script itself
    if ($FileInfo.FullName -eq $excludePath -or $FileInfo.FullName -eq $selfScriptPath) { return $true }

    # NEW: filename-based ignore (handles '.env', 'db.sqlite3', etc.)
    if ($IgnoreFileNames -contains $FileInfo.Name.ToLower()) { return $true }

    # Extension-based ignore (case-insensitive)
    $extLower = ($FileInfo.Extension ?? "").ToLower()
    if ($IgnoreExtensions -contains $extLower) { return $true }

    return $false
}

# ---------------------------------------------
# 1) Generate folder tree manually (with exclusions)
# ---------------------------------------------
function Show-Tree {
    <#
      .SYNOPSIS
        Writes a tree-like folder view similar to the original logic,
        but now honoring the unified ignore rules.

      .PARAMETER Path
        The directory to print.

      .PARAMETER Indent
        Running indentation (used internally during recursion).
    #>
    param ( [string]$Path, [string]$Indent = "" )

    # Get all items including hidden (original script used -Force) and sort
    $items = Get-ChildItem -LiteralPath $Path -Force | Sort-Object Name

    foreach ($item in $items) {

        # Skip any item that lives inside an ignored folder at any depth
        if (Test-PathHasIgnoredFolder -Path $item.FullName) { continue }

        # Skip files by filename/extension OR if they are the output/script files
        if (-not $item.PSIsContainer) {
            if (Test-IsIgnoredFile -FileInfo $item) { continue }
        }
        else {
            # Skip folder if its NAME is in the ignored list (direct match by name)
            if ($IgnoreFolderNames -contains $item.Name.ToLower()) { continue }
        }

        # Print the item line in the tree
        Write-Output ("{0}+---{1}" -f $Indent, $item.Name)

        # Recurse into directories
        if ($item.PSIsContainer) {
            Show-Tree -Path $item.FullName -Indent ("{0}|   " -f $Indent)
        }
    }
}

# ---------------------------------------------
# 2) Append source code for all relevant files
# ---------------------------------------------
# Add the section header to the Markdown output
Add-Content -Path $outputFile -Value "# Project Folder Structure`n" -Encoding utf8

# Produce the tree and append to the file
$treeLines = Show-Tree -Path (Get-Location).Path
$treeLines | Out-File -FilePath $outputFile -Append -Encoding utf8

# Now enumerate all files recursively and dump their contents, honoring the same rules
Get-ChildItem -Recurse -File -Force |
Where-Object {
    # Exclude anything that lives under an ignored folder (at any depth)
    -not (Test-PathHasIgnoredFolder -Path $_.FullName) -and

    # Exclude hidden dotfiles by leaf-name (kept from original)
    -not $_.Name.StartsWith('.') -and

    # Exclude the output file and this script itself
    $_.FullName -ne $excludePath -and
    $_.FullName -ne $selfScriptPath -and

    # Exclude common lockfiles (kept from original)
    -not ($_.Name -in @("package-lock.json", "yarn.lock", "pnpm-lock.yaml")) -and

    # Exclude by extension (default + user extensions)
    ($IgnoreExtensions -notcontains ($_.Extension ?? "").ToLower()) -and

    # NEW: Exclude by filename (default + user filenames)
    ($IgnoreFileNames -notcontains $_.Name.ToLower())
} | ForEach-Object {
    # Lookup Markdown language fence from extension map
    $lang = $extToLang[$_.Extension]

    # Write per-file section header
    Add-Content -Path $outputFile -Value "`n# ================================" -Encoding utf8
    Add-Content -Path $outputFile -Value "# FILE: $($_.FullName)" -Encoding utf8
    Add-Content -Path $outputFile -Value "# ================================" -Encoding utf8

    # Open code fence
    Add-Content -Path $outputFile -Value "```$lang" -Encoding utf8

    # Append file content as-is
    Get-Content -Path $_.FullName -Raw | Add-Content -Path $outputFile -Encoding utf8

    # Close code fence (kept from your original)
    Add-Content -Path $outputFile -Value "``" -Encoding utf8
}

# ---------------------------------------------
# 3) Final cleanup: remove BOM and normalize line endings to LF
# ---------------------------------------------
$content = Get-Content -Path $outputFile -Raw

# Replace CRLF with LF
$content = $content -replace "`r`n", "`n"

# Save as UTF-8 without BOM
[System.IO.File]::WriteAllText($outputFile, $content, (New-Object System.Text.UTF8Encoding($false)))

Write-Host "Saved everything to $outputFile (tree + file contents, BOM/CRLF cleaned)"
