
# Project Folder Structure

+---attempt_fix_docx_xml.py
+---audit_docx.py
+---audit_report.json
+---auto_tag_checkboxes.py
+---cc_tag_assistant.py
+---controls_extracted.json
+---controls_report.json
+---controls_suggested.json
+---convert_chk_tokens_to_controls.py
+---convert_glyphs_to_controls_safe_fixed.py
+---convert_glyphs_to_controls_safe.py
+---convert_glyphs_to_controls.py
+---count_content_controls.py
+---dump_doc_controls.py
+---escape_angle_brackets_fix.py
+---escape_angle_in_text_nodes.py
+---find_remaining_chk_tokens.py
+---fix_angle_brackets_and_markers.py
+---force_escape_text_nodes.py
+---inspect_docx_tokens.py
+---inspect_docx_xml.py
+---post_extract.json
+---select_content_control.py
+---set_checkboxes_from_json_2.py
+---set_checkboxes_from_json.py
+---set_one_tag.py
+---summarize_controls.py
+---unlock_and_replace.py
+---unprotect_doc.py
+---validate_and_fix_docx.py

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\attempt_fix_docx_xml.py
# ================================
`$lang
# attempt_fix_docx_xml.py
import zipfile, re, os, shutil

DOCX_PATH = r"C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited\refernce_template_unlocked.docx"
OUT_PATH = os.path.splitext(DOCX_PATH)[0] + "_fixed.docx"
BACKUP_PATH = os.path.splitext(DOCX_PATH)[0] + "_bak.docx"

def safe_backup(src, bak):
    if not os.path.exists(bak):
        shutil.copy2(src, bak)
        print("Backup created:", bak)
    else:
        print("Backup already exists:", bak)

def escape_ampersands(xml):
    # Replace ampersands that are not part of entities (e.g. &amp; &lt; &#123;)
    # We use a regex negative lookahead for valid entity pattern: &[A-Za-z0-9#]+;
    pattern = re.compile(r'&(?![A-Za-z0-9#]+;)')
    new_xml, n = pattern.subn('&amp;', xml)
    return new_xml, n

def remove_illegal_chars(xml):
    # Remove ASCII control chars except tab(9), LF(10), CR(13)
    # Valid XML 1.0 chars: #x9 | #xA | #xD | [#x20-#xD7FF] | ...
    # We'll strip characters with ord < 32 except 9,10,13
    out = []
    removed = 0
    for ch in xml:
        o = ord(ch)
        if o == 9 or o == 10 or o == 13 or o >= 32:
            out.append(ch)
        else:
            removed += 1
    return ''.join(out), removed

def fix_document_xml_bytes(data_bytes):
    try:
        xml = data_bytes.decode('utf-8')
    except Exception:
        xml = data_bytes.decode('utf-8', errors='replace')
    xml2, amp_changes = escape_ampersands(xml)
    xml3, removed_cnt = remove_illegal_chars(xml2)
    print(f"escape_ampersands made {amp_changes} replacements; removed {removed_cnt} illegal control chars.")
    return xml3.encode('utf-8')

def main():
    if not os.path.exists(DOCX_PATH):
        print("DOCX not found:", DOCX_PATH); return
    safe_backup(DOCX_PATH, BACKUP_PATH)

    with zipfile.ZipFile(DOCX_PATH, 'r') as zin:
        namelist = zin.namelist()
        if 'word/document.xml' not in namelist:
            print("No word/document.xml found; aborting."); return
        orig_doc_xml = zin.read('word/document.xml')

        fixed_doc_xml = fix_document_xml_bytes(orig_doc_xml)

        # create new zip with replaced file
        with zipfile.ZipFile(OUT_PATH, 'w', zipfile.ZIP_DEFLATED) as zout:
            for item in namelist:
                if item == 'word/document.xml':
                    zout.writestr(item, fixed_doc_xml)
                else:
                    zout.writestr(item, zin.read(item))
    print("Wrote fixed docx to:", OUT_PATH)
    print("Try opening the fixed file in Word (Open and Repair if needed).")

if __name__ == "__main__":
    main()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\audit_docx.py
# ================================
`$lang
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DOCX Auditor
- Validates XML of all parts in a .docx package
- Checks document protection + content-control locks
- Audits content controls (type, tag/title, checkbox state symbols)
- Flags leftover tokens: <<CHK>> and ☐/☑/☒ (U+2610..U+2612)
- Detects legacy form fields (pre-content-control era)
- Compares normalized visible text to an original DOCX (optional)
- Emits console report + audit_report.json

Usage:
  python audit_docx.py "final.docx" --original "refernce_template.docx"
"""

import argparse
import difflib
import io
import json
import os
import re
import sys
import zipfile
from collections import Counter, defaultdict
from xml.etree import ElementTree as ET

NS = {
    "w":   "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "r":   "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "w14": "http://schemas.microsoft.com/office/word/2010/wordml",
    "w15": "http://schemas.microsoft.com/office/word/2012/wordml",
    "w16": "http://schemas.microsoft.com/office/word/2018/wordml",
    "mc":  "http://schemas.openxmlformats.org/markup-compatibility/2006",
}
# helpers to qualify tags/attrs
def q(tag):  # "w:sdt" -> "{ns}sdt"
    p, t = tag.split(":")
    return "{%s}%s" % (NS[p], t)
def qa(attr):
    p, t = attr.split(":")
    return "{%s}%s" % (NS[p], t)

# compiled regexes
RE_CHK_TOKEN = re.compile(re.escape("<<CHK>>"))
RE_BOX_GLYPHS = re.compile(r"[\u2610\u2611\u2612]")  # ☐☑☒
RE_XMLWS = re.compile(r"\s+")
RE_NORMALIZE_SPACES = re.compile(r"[ \t\r\f\v]+")

WORD_PART_PREFIX = "word/"
TEXTY_PARTS = (
    "document.xml", "footnotes.xml", "endnotes.xml",
    "header", "footer", "comments", "glossary/document.xml"
)

def load_docx_xml_parts(path):
    """Yield (name, xml_bytes) for all .xml parts in the package."""
    parts = []
    with zipfile.ZipFile(path, "r") as z:
        for name in z.namelist():
            if name.lower().endswith(".xml"):
                parts.append((name, z.read(name)))
    return parts

def parse_xml_or_error(name, data):
    try:
        root = ET.fromstring(data)
        return {"ok": True, "name": name, "error": None, "root": root}
    except ET.ParseError as e:
        return {"ok": False, "name": name, "error": str(e), "root": None}

def find_document_protection(parts_map):
    """Check word/settings.xml for protection elements."""
    out = {"settings_present": False, "documentProtection": None, "writeProtection": None}
    settings = parts_map.get("word/settings.xml")
    if not settings: return out
    out["settings_present"] = True
    r = ET.fromstring(settings)
    dp = r.find(".//" + q("w:documentProtection"))
    if dp is not None:
        # Word uses attributes like w:edit, w:enforcement, algorithmName, etc.
        out["documentProtection"] = {
            k.split("}")[-1]: v for k, v in dp.attrib.items()
        }
    wp = r.find(".//" + q("w:writeProtection"))
    if wp is not None:
        out["writeProtection"] = {k.split("}")[-1]: v for k, v in wp.attrib.items()}
    return out

def extract_content_controls_from_tree(root, part_name):
    """Return list of content controls with metadata from one XML tree."""
    controls = []
    for sdt in root.findall(".//" + q("w:sdt")):
        sdtPr = sdt.find("./" + q("w:sdtPr"))
        if sdtPr is None:
            controls.append({
                "part": part_name, "type": "unknown", "tag": "", "title": "",
                "locked": None, "checkbox": None
            })
            continue
        # Tag/Title
        tag_el = sdtPr.find("./" + q("w:tag"))
        alias_el = sdtPr.find("./" + q("w:alias"))
        tag = (tag_el.get(qa("w:val")) if tag_el is not None else "") or ""
        title = (alias_el.get(qa("w:val")) if alias_el is not None else "") or ""

        # Lock
        lock_el = sdtPr.find("./" + q("w:lock"))
        locked = None
        if lock_el is not None:
            locked = lock_el.get(qa("w:val"))  # 'sdtLocked' or 'contentLocked'

        # Type detection
        ctype = "unknown"
        checkbox_info = None
        if sdtPr.find(".//" + q("w14:checkbox")) is not None:
            ctype = "checkbox"
            cb = sdtPr.find(".//" + q("w14:checkbox"))
            checked_state = cb.find("./" + q("w14:checkedState"))
            unchecked_state = cb.find("./" + q("w14:uncheckedState"))
            checked = cb.find("./" + q("w14:checked"))
            checkbox_info = {
                "checked_val": (checked.get(qa("w14:val")) if checked is not None else None),
                "checked_symbol": (checked_state.get(qa("w14:val")) if checked_state is not None else None),
                "checked_font": (checked_state.get(qa("w14:font")) if checked_state is not None else None),
                "unchecked_symbol": (unchecked_state.get(qa("w14:val")) if unchecked_state is not None else None),
                "unchecked_font": (unchecked_state.get(qa("w14:font")) if unchecked_state is not None else None),
            }
        elif sdtPr.find("./" + q("w:dropDownList")) is not None:
            ctype = "dropdown"
        elif sdtPr.find("./" + q("w:comboBox")) is not None:
            ctype = "combobox"
        elif sdtPr.find("./" + q("w:date")) is not None or sdtPr.find(".//" + q("w15:datePicker")) is not None:
            ctype = "date"
        elif sdtPr.find("./" + q("w:richText")) is not None:
            ctype = "richText"
        elif sdtPr.find("./" + q("w:text")) is not None:
            ctype = "text"
        elif sdtPr.find("./" + q("w:picture")) is not None:
            ctype = "picture"
        elif sdtPr.find(".//" + q("w15:repeatingSection")) is not None:
            ctype = "repeatingSection"
        elif sdtPr.find(".//" + q("w15:repeatingSectionItem")) is not None:
            ctype = "repeatingSectionItem"

        controls.append({
            "part": part_name, "type": ctype, "tag": tag, "title": title,
            "locked": locked, "checkbox": checkbox_info
        })
    return controls

def detect_legacy_form_fields(root):
    """Detect old-style 'protected form' fields."""
    legacy = []
    # <w:fldSimple w:instr="FORMCHECKBOX"> or structured <w:ffData><w:checkBox/>
    for fld in root.findall(".//" + q("w:fldSimple")):
        instr = fld.get(qa("w:instr")) or ""
        if "FORMCHECKBOX" in instr.upper():
            legacy.append({"kind":"fldSimple", "instr": instr})
    for ff in root.findall(".//" + q("w:ffData")):
        if ff.find("./" + q("w:checkBox")) is not None:
            legacy.append({"kind":"ffData.checkBox", "instr": None})
    return legacy

def gather_text_from_tree(root):
    """Concatenate text from all w:t nodes in reading order."""
    texts = []
    for t in root.findall(".//" + q("w:t")):
        texts.append(t.text or "")
    return "".join(texts)

def normalize_visible_text(s):
    """Normalize doc text for comparison: strip control glyphs/tokens, compress whitespace."""
    if not s:
        return ""
    # remove checkbox box glyphs and literal token
    s = RE_CHK_TOKEN.sub("", s)
    s = RE_BOX_GLYPHS.sub("", s)
    # normalize quotes (Word smart quotes) to straight quotes to be robust
    s = s.replace("“", '"').replace("”", '"').replace("’", "'").replace("‘", "'")
    # collapse whitespace
    s = RE_NORMALIZE_SPACES.sub(" ", s)
    return s.strip()

def collect_text_from_docx(path):
    parts = load_docx_xml_parts(path)
    text = []
    for name, data in parts:
        lname = name.lower()
        if not lname.startswith(WORD_PART_PREFIX): 
            continue
        if not any(key in lname for key in TEXTY_PARTS):
            continue
        try:
            root = ET.fromstring(data)
        except ET.ParseError:
            # ignore broken part here (will be caught in validation phase)
            continue
        text.append(gather_text_from_tree(root))
        # add newlines to separate parts
        text.append("\n")
    return normalize_visible_text("".join(text))

def audit(path, original_path=None):
    result = {
        "file": os.path.abspath(path),
        "xml_validation": {"ok": True, "errors": []},
        "protection": {},
        "content_controls": {
            "total": 0, "by_type": {}, "locked_count": 0,
            "empty_tag_or_title": 0, "checkbox_symbol_summary": Counter()
        },
        "leftover_tokens": {"chk_tokens": [], "box_glyph_hits": []},
        "legacy_form_fields": [],
        "text_comparison": None,
    }

    # Load parts
    parts = load_docx_xml_parts(path)
    parts_map = {name: data for (name, data) in parts}

    # 1) XML validation
    xml_errors = []
    for name, data in parts:
        pr = parse_xml_or_error(name, data)
        if not pr["ok"]:
            xml_errors.append({"part": name, "error": pr["error"]})
    result["xml_validation"]["ok"] = (len(xml_errors) == 0)
    result["xml_validation"]["errors"] = xml_errors

    # 2) Document + write protection (settings.xml)
    result["protection"] = find_document_protection(parts_map)

    # 3) Content controls audit + locks + symbols
    controls = []
    locked_count = 0
    by_type = Counter()
    empty_tag_title = 0
    symbol_counter = Counter()
    legacy_all = []

    for name, data in parts:
        if not name.startswith("word/"): 
            continue
        # parse
        try:
            root = ET.fromstring(data)
        except ET.ParseError:
            continue

        # legacy
        legacy = detect_legacy_form_fields(root)
        if legacy:
            for item in legacy:
                item["part"] = name
            legacy_all.extend(legacy)

        # controls
        ccs = extract_content_controls_from_tree(root, name)
        controls.extend(ccs)
        for c in ccs:
            by_type[c["type"]] += 1
            if c["locked"]: locked_count += 1
            if (c["tag"] or "").strip() == "" and (c["title"] or "").strip() == "":
                empty_tag_title += 1
            if c["type"] == "checkbox" and c["checkbox"]:
                # summarize checked/unchecked symbol codes (hex)
                ch = c["checkbox"]["checked_symbol"]
                un = c["checkbox"]["unchecked_symbol"]
                if ch: symbol_counter[f"checked:{ch}"] += 1
                if un: symbol_counter[f"unchecked:{un}"] += 1

        # leftover tokens in this part text nodes (fast scan raw bytes too)
        # raw scan for <<CHK>>
        if RE_CHK_TOKEN.search(data.decode("utf-8", "ignore")):
            # try to grab small contexts
            s = data.decode("utf-8", "ignore")
            for m in RE_CHK_TOKEN.finditer(s):
                start = max(0, m.start() - 40)
                end = min(len(s), m.end() + 40)
                snippet = s[start:end].replace("\n", " ")
                result["leftover_tokens"]["chk_tokens"].append({"part": name, "context": snippet})

        # raw scan for box glyphs
        if RE_BOX_GLYPHS.search(data.decode("utf-8", "ignore")):
            s = data.decode("utf-8", "ignore")
            for m in RE_BOX_GLYPHS.finditer(s):
                start = max(0, m.start() - 40)
                end = min(len(s), m.end() + 40)
                snippet = s[start:end].replace("\n", " ")
                result["leftover_tokens"]["box_glyph_hits"].append({"part": name, "context": snippet})

    result["content_controls"]["total"] = len(controls)
    result["content_controls"]["by_type"] = dict(by_type)
    result["content_controls"]["locked_count"] = locked_count
    result["content_controls"]["empty_tag_or_title"] = empty_tag_title
    result["content_controls"]["checkbox_symbol_summary"] = dict(symbol_counter)
    result["legacy_form_fields"] = legacy_all

    # 4) Text comparison to original (optional)
    if original_path:
        final_text = collect_text_from_docx(path)
        orig_text  = collect_text_from_docx(original_path)
        sm = difflib.SequenceMatcher(None, orig_text, final_text)
        ratio = sm.ratio()
        # small diff samples
        diffs = []
        for tag, i1, i2, j1, j2 in sm.get_opcodes():
            if tag == "equal":
                continue
            a = orig_text[i1:i2]
            b = final_text[j1:j2]
            if len(diffs) < 8:  # limit
                diffs.append({
                    "op": tag,
                    "orig_excerpt": (a[:160] + ("…" if len(a) > 160 else "")),
                    "final_excerpt": (b[:160] + ("…" if len(b) > 160 else "")),
                    "orig_span": [i1, i2],
                    "final_span": [j1, j2],
                })
        result["text_comparison"] = {
            "similarity_ratio": round(ratio, 6),
            "orig_length": len(orig_text),
            "final_length": len(final_text),
            "diff_samples": diffs
        }

    return result

def print_human_report(rep):
    print("\n=== DOCX AUDIT REPORT ===")
    print(f"File: {rep['file']}\n")

    # XML validation
    v = rep["xml_validation"]
    print(f"[XML] All parts well-formed: {'YES' if v['ok'] else 'NO'}")
    if not v["ok"]:
        for e in v["errors"][:12]:
            print(f"  - {e['part']}: {e['error']}")
        if len(v["errors"]) > 12:
            print(f"  ... and {len(v['errors'])-12} more")

    # Protection
    p = rep["protection"]
    if not p.get("settings_present"):
        print("[Protection] word/settings.xml not found (unusual).")
    else:
        dp = p.get("documentProtection")
        wp = p.get("writeProtection")
        if dp:
            enf = dp.get("enforcement")
            print(f"[Protection] DocumentProtection present: {dp}  (ENFORCEMENT={enf})")
        else:
            print("[Protection] No documentProtection element — OK (unprotected).")
        if wp:
            print(f"[Protection] WriteProtection present: {wp}")
        else:
            print("[Protection] No writeProtection element — OK.")

    # Content controls
    cc = rep["content_controls"]
    print(f"\n[Controls] Total content controls: {cc['total']}")
    print(f"[Controls] By type: {cc['by_type']}")
    print(f"[Controls] Locked controls: {cc['locked_count']}")
    print(f"[Controls] Controls with empty Tag & Title: {cc['empty_tag_or_title']}")
    sym = cc.get("checkbox_symbol_summary") or {}
    if sym:
        print(f"[Controls] Checkbox symbol codes (hex): {sym}")
        # tip
        print("         (For an 'X' checked symbol, you typically see checked:'0058')")

    # Legacy form fields
    if rep["legacy_form_fields"]:
        print(f"\n[Legacy] Found {len(rep['legacy_form_fields'])} legacy form field(s):")
        for item in rep["legacy_form_fields"][:10]:
            print(f"  - {item['kind']} in {item['part']}  instr={item.get('instr')}")
        if len(rep["legacy_form_fields"]) > 10:
            print(f"  ... and {len(rep['legacy_form_fields'])-10} more")
    else:
        print("\n[Legacy] No legacy form fields detected — OK.")

    # Leftover tokens
    lt = rep["leftover_tokens"]
    if lt["chk_tokens"]:
        print(f"\n[Leftovers] Found {len(lt['chk_tokens'])} '<<CHK>>' token(s):")
        for it in lt["chk_tokens"][:10]:
            print(f"  - {it['part']}: …{it['context']}…")
        if len(lt["chk_tokens"]) > 10:
            print(f"  ... and {len(lt['chk_tokens'])-10} more")
    else:
        print("\n[Leftovers] No '<<CHK>>' tokens — OK.")

    if lt["box_glyph_hits"]:
        print(f"[Leftovers] Found {len(lt['box_glyph_hits'])} occurrences of ☐/☑/☒:")
        for it in lt["box_glyph_hits"][:10]:
            print(f"  - {it['part']}: …{it['context']}…")
        if len(lt["box_glyph_hits"]) > 10:
            print(f"  ... and {len(lt['box_glyph_hits'])-10} more")
    else:
        print("[Leftovers] No ☐/☑/☒ glyphs — OK.")

    # Text comparison
    tc = rep.get("text_comparison")
    if tc:
        print("\n[Content] Normalized text comparison to ORIGINAL (ignoring control markup):")
        print(f"         Similarity ratio: {tc['similarity_ratio']:.6f}")
        print(f"         Original length: {tc['orig_length']}  Final length: {tc['final_length']}")
        if tc["diff_samples"]:
            print("         Diff samples (first few):")
            for d in tc["diff_samples"][:5]:
                print(f"         - {d['op']} orig[{d['orig_span'][0]}:{d['orig_span'][1]}] vs "
                      f"final[{d['final_span'][0]}:{d['final_span'][1]}]")
                print(f"           ORIG : {d['orig_excerpt']}")
                print(f"           FINAL: {d['final_excerpt']}")
        else:
            print("         No differences detected in normalized text.")
    else:
        print("\n[Content] No original provided; skipped text comparison.")

def main():
    ap = argparse.ArgumentParser(description="Audit a DOCX for XML validity, protection, controls, leftovers, and content similarity.")
    ap.add_argument("docx", help="Path to final DOCX to audit")
    ap.add_argument("--original", help="Path to original DOCX to compare visible text against", default=None)
    ap.add_argument("--json", help="Write JSON report to this file (default: audit_report.json beside DOCX)", default=None)
    args = ap.parse_args()

    if not os.path.isfile(args.docx):
        print(f"ERROR: file not found: {args.docx}", file=sys.stderr)
        sys.exit(2)
    if args.original and not os.path.isfile(args.original):
        print(f"ERROR: original file not found: {args.original}", file=sys.stderr)
        sys.exit(2)

    rep = audit(args.docx, args.original)
    print_human_report(rep)

    # Write JSON
    out_json = args.json or os.path.join(os.path.dirname(os.path.abspath(args.docx)), "audit_report.json")
    try:
        with io.open(out_json, "w", encoding="utf-8") as fh:
            json.dump(rep, fh, indent=2, ensure_ascii=False)
        print(f"\nJSON report written to: {out_json}")
    except Exception as e:
        print(f"\nWARNING: could not write JSON report: {e}")

if __name__ == "__main__":
    main()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\audit_report.json
# ================================
`$lang
{
  "file": "C:\\Users\\K Santosh Kumar\\Desktop\\HEALTHARK\\04_thermofisher\\Downloaded_Documents\\edited\\refernce_template_real_checkbox_final.docx",
  "xml_validation": {
    "ok": true,
    "errors": []
  },
  "protection": {
    "settings_present": true,
    "documentProtection": null,
    "writeProtection": null
  },
  "content_controls": {
    "total": 330,
    "by_type": {
      "checkbox": 315,
      "dropdown": 1,
      "combobox": 10,
      "date": 4
    },
    "locked_count": 0,
    "empty_tag_or_title": 16,
    "checkbox_symbol_summary": {
      "checked:2612": 315,
      "unchecked:2610": 315
    }
  },
  "leftover_tokens": {
    "chk_tokens": [],
    "box_glyph_hits": [
      {
        "part": "word/document.xml",
        "context": "=\"20\"/><w:szCs w:val=\"20\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"20\"/><w:szCs w:val=\"20\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"20\"/><w:szCs w:val=\"20\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"20\"/><w:szCs w:val=\"20\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:p></w:tc></w:sdtContent>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "en-IN\" w:eastAsia=\"de-DE\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:pr"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:pr"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:pr"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:pr"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:pr"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "6\"/><w:lang w:val=\"en-IN\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "en-IN\" w:eastAsia=\"de-DE\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "en-IN\" w:eastAsia=\"de-DE\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "en-IN\" w:eastAsia=\"de-DE\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r>"
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "en-IN\" w:eastAsia=\"de-DE\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "en-IN\" w:eastAsia=\"de-DE\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      },
      {
        "part": "word/document.xml",
        "context": "=\"16\"/><w:szCs w:val=\"16\"/></w:rPr><w:t>☐</w:t></w:r></w:sdtContent></w:sdt><w:r "
      }
    ]
  },
  "legacy_form_fields": [],
  "text_comparison": {
    "similarity_ratio": 0.998967,
    "orig_length": 37267,
    "final_length": 37278,
    "diff_samples": [
      {
        "op": "delete",
        "orig_excerpt": "\n",
        "final_excerpt": "",
        "orig_span": [
          36469,
          36470
        ],
        "final_span": [
          36469,
          36469
        ]
      },
      {
        "op": "replace",
        "orig_excerpt": "1",
        "final_excerpt": "6",
        "orig_span": [
          36481,
          36482
        ],
        "final_span": [
          36480,
          36481
        ]
      },
      {
        "op": "replace",
        "orig_excerpt": "June 26",
        "final_excerpt": "September 17",
        "orig_span": [
          36531,
          36538
        ],
        "final_span": [
          36530,
          36542
        ]
      },
      {
        "op": "insert",
        "orig_excerpt": "",
        "final_excerpt": "\n",
        "orig_span": [
          36603,
          36603
        ],
        "final_span": [
          36607,
          36608
        ]
      },
      {
        "op": "delete",
        "orig_excerpt": " - Template",
        "final_excerpt": "",
        "orig_span": [
          36658,
          36669
        ],
        "final_span": [
          36663,
          36663
        ]
      },
      {
        "op": "insert",
        "orig_excerpt": "",
        "final_excerpt": " - Template",
        "orig_span": [
          36732,
          36732
        ],
        "final_span": [
          36726,
          36737
        ]
      },
      {
        "op": "replace",
        "orig_excerpt": " of 24",
        "final_excerpt": "1 of 16",
        "orig_span": [
          36746,
          36752
        ],
        "final_span": [
          36751,
          36758
        ]
      },
      {
        "op": "replace",
        "orig_excerpt": "June 26",
        "final_excerpt": "September 17",
        "orig_span": [
          36801,
          36808
        ],
        "final_span": [
          36807,
          36819
        ]
      }
    ]
  }
}
`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\auto_tag_checkboxes.py
# ================================
`$lang
# auto_tag_checkboxes.py
import sys, os, re
import win32com.client as com

def sanitize_tag(s):
    s = (s or "").strip()
    if not s: return "auto_chk"
    out = []
    for ch in s:
        if ch.isalnum() or ch == "_":
            out.append(ch)
        elif ch in (" ", "-", "/"):
            out.append("_")
    t = "".join(out).lower()
    return (t or "auto_chk")[:64]

IN = sys.argv[1] if len(sys.argv)>1 else "refernce_template_unlocked_forced_escaped_controls.docx"
word = com.Dispatch("Word.Application")
word.Visible = False
doc = word.Documents.Open(os.path.abspath(IN))
try:
    changed = 0
    for i in range(1, doc.ContentControls.Count+1):
        cc = doc.ContentControls.Item(i)
        if int(cc.Type) == 8 and (not cc.Tag or cc.Tag.strip() == ""):
            # grab surrounding text: 40 chars before -> 60 after
            start = max(0, cc.Range.Start - 40)
            end = min(doc.Range().End, cc.Range.End + 60)
            ctx = doc.Range(start, end).Text
            # best effort: take first sentence-like bit after the control, else before
            m = re.search(r'([A-Za-z0-9][^\.]{0,80})', ctx)
            snippet = (m.group(1).strip() if m else ctx.strip())[:80]
            tag = sanitize_tag(snippet)
            cc.Tag = tag
            cc.Title = snippet[:128]
            changed += 1
            print(f"Set tag for control #{i} -> {tag!r} title={snippet!r}")
    if changed:
        out = os.path.splitext(IN)[0] + "_tagged.docx"
        doc.SaveAs(os.path.abspath(out))
        print("Saved new doc:", out)
    else:
        print("No unnamed checkbox controls found.")
finally:
    doc.Close(False)
    word.Quit()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\cc_tag_assistant.py
# ================================
`$lang
import argparse, json, csv, re, sys, unicodedata, time
from pathlib import Path

try:
    import win32com.client as win32
    from win32com.client import constants as wdconst
except Exception as e:
    print("This script requires pywin32 on Windows with Microsoft Word installed.")
    print("pip install pywin32")
    raise

# ------------------------
# Helpers
# ------------------------

CONTROL_TYPE_MAP = {
    0: "richtext",
    2: "text",
    3: "combobox",
    4: "dropdown",
    6: "date",
    8: "checkbox",
}

def slugify(s: str, max_len: int = 63):
    """Make a machine-friendly tag: ascii, lowercase, snake_case, <= max_len."""
    if not s:
        return ""
    # Normalize accents → ASCII
    s = unicodedata.normalize("NFKD", s)
    s = s.encode("ascii", "ignore").decode("ascii")

    # Replace common separators with spaces
    s = re.sub(r"[/|&>]+", " ", s)

    # Keep words/numbers, collapse whitespace
    s = re.sub(r"[^a-zA-Z0-9]+", " ", s).strip()
    s = re.sub(r"\s+", "_", s.lower())

    # Trim
    if len(s) > max_len:
        s = s[:max_len]
    return s

def looks_good_existing_tag(t: str):
    """Heuristic: keep existing tags that look clean & descriptive."""
    if not t:
        return False
    if len(t) < 4:
        return False
    if re.fullmatch(r"[a-z0-9_]{4,63}", t) is None:
        return False
    # Avoid meaningless defaults like 'chk' or 'checkbox'
    if t in {"chk","checkbox","title","tag"}:
        return False
    return True

def get_heading_level_name(par):
    """Return (level:int or None, name:str) for a paragraph's style if it's a Heading."""
    try:
        # Prefer OutlineLevel (1..9); fallback to style name check
        lvl = int(par.OutlineLevel)
        if 1 <= lvl <= 9:
            name = par.Range.Style.NameLocal
            if isinstance(name, str) and ("Heading" in name or "Überschrift" in name or "Titre" in name):
                return lvl, name
        # Fallback purely on style name
        name = par.Range.Style.NameLocal
        if isinstance(name, str) and name.lower().startswith("heading"):
            # guess level from digits
            m = re.search(r"(\d+)", name)
            lvl = int(m.group(1)) if m else 1
            return lvl, name
    except Exception:
        pass
    return None, None

def extract_headings(doc):
    """Scan paragraphs once; return list of (start, level, text) for Heading 1..3."""
    headings = []
    for p in doc.Paragraphs:
        lvl, _name = get_heading_level_name(p)
        if lvl and 1 <= lvl <= 3:
            txt = p.Range.Text
            txt = txt.replace("\r", " ").strip()
            if txt:
                headings.append((p.Range.Start, lvl, txt))
    headings.sort(key=lambda x: x[0])
    return headings

def nearest_heading_path(headings, pos):
    """Given headings [(start, level, text)], find nearest previous H1..H3 at 'pos' and build path."""
    h1 = h2 = h3 = None
    # Walk through headings up to 'pos'
    for start, lvl, text in headings:
        if start > pos:
            break
        if lvl == 1:
            h1, h2, h3 = text, None, None
        elif lvl == 2:
            h2, h3 = text, None
        elif lvl == 3:
            h3 = text
    path = [h for h in (h1, h2, h3) if h]
    return path

def paragraph_text(par):
    try:
        return par.Range.Text.replace("\r", "\n").strip()
    except Exception:
        return ""

def previous_nonempty_par_text(ctrl):
    try:
        idx = ctrl.Range.Paragraphs(1).Index
        # Walk backwards to find first non-empty paragraph
        doc_pars = ctrl.Parent.Paragraphs
        j = idx - 1
        while j >= 1:
            t = paragraph_text(doc_pars(j))
            if t:
                return t
            j -= 1
    except Exception:
        pass
    return ""

def control_label_guess(ctrl):
    """Best-effort: label on same paragraph / immediate context."""
    t_curr = ""
    try:
        t_curr = paragraph_text(ctrl.Range.Paragraphs(1))
    except Exception:
        pass
    t_prev = previous_nonempty_par_text(ctrl)
    # Prefer the current paragraph, otherwise previous
    return (t_curr or t_prev)[:400]

def safe_get_checkbox_state(ctrl):
    try:
        # Some Word builds expose .Checked; some require .Range.ContentControls(1).Checked
        if ctrl.Type == 8:  # checkbox
            try:
                return bool(ctrl.Checked)
            except Exception:
                # Try nested
                try:
                    inner = ctrl.Range.ContentControls(1)
                    return bool(inner.Checked)
                except Exception:
                    return None
        return None
    except Exception:
        return None

def open_word(visible=False):
    word = win32.Dispatch("Word.Application")
    word.Visible = visible
    return word

def open_doc(word, path):
    return word.Documents.Open(str(Path(path).resolve()))

# ------------------------
# Commands
# ------------------------

def cmd_extract(args):
    word = open_word(visible=False)
    try:
        doc = open_doc(word, args.docx)
        headings = extract_headings(doc)

        rows = []
        for i, ctrl in enumerate(doc.ContentControls, start=1):
            ctype = CONTROL_TYPE_MAP.get(int(ctrl.Type), f"type_{int(ctrl.Type)}")
            tag = ctrl.Tag or ""
            title = ctrl.Title or ""
            start_pos = int(ctrl.Range.Start)
            path = nearest_heading_path(headings, start_pos)
            path_slug = [slugify(x) for x in path]
            para_text = control_label_guess(ctrl)
            checked = safe_get_checkbox_state(ctrl)
            rng_preview = ""
            try:
                rng_preview = ctrl.Range.Text
                rng_preview = rng_preview.replace("\r", " ").replace("\n", " ")
            except Exception:
                pass

            rows.append({
                "index": i,
                "type": ctype,
                "tag": tag,
                "title": title,
                "checked": checked,
                "heading_path": path,
                "heading_path_slug": path_slug,
                "paragraph_context": para_text,
                "range_preview": rng_preview,
            })

        # Write JSON/CSV
        if args.out:
            Path(args.out).write_text(json.dumps(rows, indent=2), encoding="utf-8")
            print(f"Wrote: {args.out}")
        if args.csv:
            with open(args.csv, "w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
                w.writeheader()
                w.writerows(rows)
            print(f"Wrote: {args.csv}")

        print(f"Extracted {len(rows)} controls.")
    finally:
        try:
            doc.Close(False)
        except Exception:
            pass
        word.Quit()

def propose_tag_for_row(row):
    # Keep existing "good" tag
    if looks_good_existing_tag(row.get("tag", "")):
        return row["tag"], row.get("title") or row["tag"]

    # Base from heading path
    parts = row.get("heading_path", [])[:3]
    base = "_".join(slugify(p) for p in parts if p)

    # Add control-type hint if helpful
    ctype = row.get("type", "")
    type_hint = {"checkbox":"chk", "combobox":"combo", "dropdown":"dd", "date":"date", "text":"text"}.get(ctype, ctype)

    # Pull a few words from the paragraph context (label)
    context = row.get("paragraph_context") or ""
    # Grab text near the control: try after the checkbox glyph or colon
    # Simple heuristic: take first 6 words that look content-ish
    words = re.findall(r"[A-Za-z0-9]+", context)
    label_slug = "_".join(w.lower() for w in words[:6])

    # Compose
    bits = [b for b in [base, label_slug, type_hint] if b]
    candidate = slugify("_".join(bits))
    if not candidate:
        candidate = f"{type_hint}_field"

    # Also propose a Title (more human-readable)
    title = " / ".join([p for p in parts if p]) or ctype.capitalize()
    return candidate, title

def cmd_suggest(args):
    rows = json.loads(Path(args.input).read_text(encoding="utf-8"))
    used = set()
    out = []
    for row in rows:
        tag, title = propose_tag_for_row(row)

        # Ensure uniqueness
        base = tag
        n = 1
        while tag in used:
            n += 1
            tag = f"{base}_{n}"
            if len(tag) > 63:
                tag = tag[:60] + f"_{n}"
        used.add(tag)

        row["proposed_tag"] = tag
        # Keep existing human title if present; else proposed
        row["proposed_title"] = row.get("title") or title
        out.append(row)

    # Save
    if args.out:
        Path(args.out).write_text(json.dumps(out, indent=2), encoding="utf-8")
        print(f"Wrote: {args.out}")
    if args.csv and out:
        with open(args.csv, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(out[0].keys()))
            w.writeheader()
            w.writerows(out)
        print(f"Wrote: {args.csv}")

    # Quick summary
    total = len(out)
    keep_existing = sum(1 for r in out if looks_good_existing_tag(r.get("tag","")))
    print(f"Suggested tags for {total} controls. Kept {keep_existing} existing tags that looked good.")

def cmd_apply(args):
    """
    Apply Tag/Title from a mapping file to a DOCX's content controls.

    Supports:
      - JSON rows with keys: index, [proposed_tag|tag], [proposed_title|title]
      - --dry-run to preview
      - --write to actually modify
      - --save-as <path> to write to a new DOCX (FileFormat=12)
    """
    import json
    from pathlib import Path

    # --- load mapping (JSON list of dicts) ---
    mapping_path = Path(args.mapping)
    rows = json.loads(mapping_path.read_text(encoding="utf-8"))

    # helpers to pick the right columns from the mapping
    def row_tag(r):
        return (r.get("proposed_tag") or r.get("tag") or "").strip()

    def row_title(r):
        return (r.get("proposed_title") or r.get("title") or "").strip()

    # --- open Word + document ---
    word = open_word(visible=args.show)
    try:
        doc = open_doc(word, args.docx)
        cc = list(doc.ContentControls)
        if len(cc) != len(rows):
            print(f"Warning: doc has {len(cc)} controls, mapping has {len(rows)} rows.")

        applied = 0
        skipped_empty = 0
        skipped_oor = 0
        errors = 0

        # allow mapping in any order
        for r in rows:
            try:
                i = int(r["index"])
            except Exception:
                print(f"Skip row without valid 'index': {r!r}")
                continue

            if i < 1 or i > len(cc):
                print(f"Skip index {i}: out of range (1..{len(cc)})")
                skipped_oor += 1
                continue

            c = cc[i - 1]
            new_tag = row_tag(r)
            new_title = row_title(r)

            if not new_tag:
                print(f"Skip index {i}: empty tag/proposed_tag")
                skipped_empty += 1
                continue

            if args.dry_run:
                print(f"[DRY] #{i}: set Tag='{new_tag}'  Title='{new_title}'  "
                      f"(was Tag='{c.Tag}' Title='{c.Title}')")
                continue

            # actually write
            try:
                c.Tag = new_tag
            except Exception as e:
                print(f"# {i}: failed to set Tag -> {e}")
                errors += 1

            try:
                c.Title = new_title
            except Exception as e:
                print(f"# {i}: failed to set Title -> {e}")
                errors += 1

            applied += 1

        # --- save ---
        if args.dry_run:
            print("Dry run complete. No changes written.")
            return

        # If --save-as provided, save to a NEW file; else save in-place
        save_as = getattr(args, "save_as", None)
        if save_as:
            out_path = Path(save_as).resolve()
            out_path.parent.mkdir(parents=True, exist_ok=True)
            # 12 = wdFormatXMLDocument (.docx)
            doc.SaveAs2(str(out_path), FileFormat=12)
            print(f"Applied tags/titles to {applied} controls and saved as:\n  {out_path}")
        else:
            doc.Save()
            print(f"Applied tags/titles to {applied} controls and saved document.")

        if skipped_empty or skipped_oor or errors:
            print(f"Notes: skipped_empty={skipped_empty}, skipped_out_of_range={skipped_oor}, errors={errors}")

    finally:
        # Leave Word running if user asked to show; otherwise quit to release file locks.
        try:
            if not getattr(args, "show", False):
                word.Quit()
        except Exception:
            pass

        if not args.show:
            try:
                doc.Close(False)
            except Exception:
                pass
            word.Quit()

def cmd_jump(args):
    word = open_word(visible=True)
    doc = open_doc(word, args.docx)
    try:
        target = None
        if args.index:
            i = int(args.index)
            if 1 <= i <= doc.ContentControls.Count:
                target = doc.ContentControls(i)
        elif args.tag:
            for c in doc.ContentControls:
                if str(c.Tag).strip().lower() == args.tag.strip().lower():
                    target = c
                    break

        if not target:
            print("Control not found.")
            return

        rng = target.Range
        rng.Select()
        word.Activate()
        # Give Word a moment to scroll/select
        time.sleep(0.4)
        print(f"Selected control #{target.Index}  Type={CONTROL_TYPE_MAP.get(int(target.Type), target.Type)}  Tag='{target.Tag}' Title='{target.Title}'")

    finally:
        # Leave Word open for user to inspect
        pass

# ------------------------
# Main
# ------------------------

def main():
    p = argparse.ArgumentParser(description="Content Control Tagging Assistant for Word DOCX (COM).")
    sub = p.add_subparsers(dest="cmd", required=True)

    p1 = sub.add_parser("extract", help="Extract controls + context to JSON/CSV")
    p1.add_argument("docx", help="Path to DOCX")
    p1.add_argument("--out", help="Output JSON", default="controls_extracted.json")
    p1.add_argument("--csv", help="Output CSV", default="controls_extracted.csv")
    p1.set_defaults(func=cmd_extract)

    p2 = sub.add_parser("suggest", help="Propose tags/titles from extracted JSON")
    p2.add_argument("input", help="controls_extracted.json")
    p2.add_argument("--out", help="Output JSON", default="controls_suggested.json")
    p2.add_argument("--csv", help="Output CSV", default="controls_suggested.csv")
    p2.set_defaults(func=cmd_suggest)

    p3 = sub.add_parser("apply", help="Apply tags/titles to DOCX from JSON mapping")
    p3.add_argument("docx", help="Path to DOCX")
    p3.add_argument("mapping", help="controls_suggested.json (or similar)")
    p3.add_argument("--dry-run", action="store_true", dest="dry_run", help="Do not modify the document")
    p3.add_argument("--write", action="store_true", help="Actually write changes (alias for not --dry-run)")
    p3.add_argument("--show", action="store_true", help="Open Word UI while applying (useful for spot checks)")
    p3.add_argument("--save-as", dest="save_as", help="Write changes to a NEW .docx (does not overwrite original)")
    p3.set_defaults(func=cmd_apply)

    p4 = sub.add_parser("jump", help="Open Word, jump to a control by index or tag")
    p4.add_argument("docx", help="Path to DOCX")
    g = p4.add_mutually_exclusive_group(required=True)
    g.add_argument("--index", type=int)
    g.add_argument("--tag", type=str)
    p4.set_defaults(func=cmd_jump)

    args = p.parse_args()
    # `--write` as an alias for not --dry-run:
    if getattr(args, "write", False):
        setattr(args, "dry_run", False)

    args.func(args)

if __name__ == "__main__":
    main()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\controls_extracted.json
# ================================
`$lang
[
  {
    "index": 1,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610EPD\t\u2610ECR\t\u2610GEPC",
    "range_preview": "\u2610"
  },
  {
    "index": 2,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610EPD\t\u2610ECR\t\u2610GEPC",
    "range_preview": "\u2610"
  },
  {
    "index": 3,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610EPD\t\u2610ECR\t\u2610GEPC",
    "range_preview": "\u2610"
  },
  {
    "index": 4,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610  <Insert Other>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 5,
    "type": "dropdown",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Level: <Choose a Project Level.>\u0007",
    "range_preview": "<Choose a Project Level.>"
  },
  {
    "index": 6,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "CAPA Associated: <Select one.>",
    "range_preview": "<Select one.>"
  },
  {
    "index": 7,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Design Owner:\t<Choose an item.>\tOther (if applicable): <Fill in if \u201cOther\u201d is chosen.> \tName of OEM (if applicable): <Name of OEM>",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 8,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 9,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 10,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 11,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 12,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 13,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 14,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 15,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 16,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Design is Copy Exact: <Choose an item.>\u0007",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 17,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 18,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 19,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 20,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 21,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 22,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 23,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 24,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 25,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 26,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 27,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 28,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 29,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 30,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 31,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 32,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 33,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 34,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 35,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 36,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 37,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change does not impact the Risk Management File",
    "range_preview": "\u2610"
  },
  {
    "index": 38,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610 The product family does not have a Risk Management File or does not have a Risk Management File aligned to the latest revisions in the QMS.",
    "range_preview": "\u2610"
  },
  {
    "index": 39,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change introduces new usage conditions, or risk of harm as defined in the Risk Management Procedure (Patient, Samples, Operators, Environment, etc.).",
    "range_preview": "\u2610"
  },
  {
    "index": 40,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change affects the current risk probability or severity associated with existing hazards",
    "range_preview": "\u2610"
  },
  {
    "index": 41,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change will mean that the device will have different end users or be used in a different manner",
    "range_preview": "\u2610"
  },
  {
    "index": 42,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The performance evaluation data for the original device is not sufficient to confirm conformity of the changed device with the required characteristics and performance",
    "range_preview": "\u2610"
  },
  {
    "index": 43,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change involves the manufacturing process (i.e., technologies, product lines)",
    "range_preview": "\u2610"
  },
  {
    "index": 44,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change impacts End of Line (EOL) testing procedures (e.g., TP902 \u2013 Test procedure for all Hi Pot and Hypatia Equipment Test Machines)",
    "range_preview": "\u2610"
  },
  {
    "index": 45,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change requires a process validation",
    "range_preview": "\u2610"
  },
  {
    "index": 46,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change affects agreements and/or arrangements (e.g., verification, validation, organizational structure, production site, outsourcing, subcontracting) for ensuring continued compliance with the requirements",
    "range_preview": "\u2610"
  },
  {
    "index": 47,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change results from actions taken related to concerns arising from post-market surveillance including incidents/recalls/complaints (CAPA associated)",
    "range_preview": "\u2610"
  },
  {
    "index": 48,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change impacts Quality Control procedures, incoming acceptance criteria, or involves a change in supplier",
    "range_preview": "\u2610"
  },
  {
    "index": 49,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  (Medical) The change results from characteristics not previously considered in the clinical evaluation",
    "range_preview": "\u2610"
  },
  {
    "index": 50,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  (Medical) The change is driven by the development of the state of the art (e.g., latest technology)",
    "range_preview": "\u2610"
  },
  {
    "index": 51,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 52,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "Next Steps: <Choose the project action item that would need to be completed based on the scope assessment.>",
    "range_preview": "<Choose the project action item that would need to be completed based on the scope assessment.>"
  },
  {
    "index": 53,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610CAPA owner notified\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 54,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610  The change does not impact the performance compliance of the product.",
    "range_preview": "\u2610"
  },
  {
    "index": 55,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect degradable, moving or friction generating components (air filters, fans, hinges, etc.)",
    "range_preview": "\u2610"
  },
  {
    "index": 56,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect the airflow into, throughout, and out of the unit (airflow vent, rearranging components, deck size, etc.)",
    "range_preview": "\u2610"
  },
  {
    "index": 57,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest requirements. Requested to add in scope of the current project.",
    "range_preview": "\u2610"
  },
  {
    "index": 58,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect critical components in compliance files (Electrical, refrigeration, labels)",
    "range_preview": "\u2610"
  },
  {
    "index": 59,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect the product performance, peak variation, temperature stability, door open recovery times",
    "range_preview": "\u2610"
  },
  {
    "index": 60,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes will be made to the product power specifications, refrigeration system, or electrical systems",
    "range_preview": "\u2610"
  },
  {
    "index": 61,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes to the internal cabinet size, construction, or configuration (inner doors, shelving, port holes)",
    "range_preview": "\u2610"
  },
  {
    "index": 62,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Change to defrosts, setpoint ranges, or code versions",
    "range_preview": "\u2610"
  },
  {
    "index": 63,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes to the software affecting behavior or timing of behaviors",
    "range_preview": "\u2610"
  },
  {
    "index": 64,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest requirements. Requested to add in scope of the current project.",
    "range_preview": "\u2610"
  },
  {
    "index": 65,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes affect the cooling capacity to cool down and maintain the temperature of the liquid",
    "range_preview": "\u2610"
  },
  {
    "index": 66,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes affect the functionality of the medium (refrigerant, water, etc.) to chill the system continuously",
    "range_preview": "\u2610"
  },
  {
    "index": 67,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes may affect the power input specifications",
    "range_preview": "\u2610"
  },
  {
    "index": 68,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest requirements. Requested to add in scope of the current project.\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 69,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect critical components in compliance files",
    "range_preview": "\u2610"
  },
  {
    "index": 70,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest requirements. Requested to add in scope of the current project.\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 71,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect critical components in compliance files",
    "range_preview": "\u2610"
  },
  {
    "index": 72,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes to the materials of construction or coatings (paint)",
    "range_preview": "\u2610"
  },
  {
    "index": 73,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes impact air flow (blowers, power supp, filters, paper catch areas, filter screen)",
    "range_preview": "\u2610"
  },
  {
    "index": 74,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes to the software",
    "range_preview": "\u2610"
  },
  {
    "index": 75,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes impacting stability (change weight distribution or change to stands)",
    "range_preview": "\u2610"
  },
  {
    "index": 76,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes impact cleanability (Sealing of openings that could harbor contamination, fasteners - Philip screws not allowed)",
    "range_preview": "\u2610"
  },
  {
    "index": 77,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes impact the cabinet pressure decay test (seals, cabinet materials)",
    "range_preview": "\u2610"
  },
  {
    "index": 78,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes impact labels or markings (add, remove, location change)",
    "range_preview": "\u2610"
  },
  {
    "index": 79,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest requirements. Requested to add in scope of the current project.\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 80,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610ENERGY STAR*",
    "range_preview": "\u2610"
  },
  {
    "index": 81,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610NSF49 BSC*",
    "range_preview": "\u2610"
  },
  {
    "index": 82,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610NSF456 Vaccine*\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 83,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Clean Room Particulate 14644-14*\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 84,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Clean Room Particulate 14644-14*",
    "range_preview": "\u2610"
  },
  {
    "index": 85,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610ErP Directive (Chillers only)\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 86,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Clean Room Particulate 14644-14*",
    "range_preview": "\u2610"
  },
  {
    "index": 87,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610South Korean Act on Environmental testing and Inspection\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 88,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other (if applicable): <Select \u201cOther\u201d if the report is not listed above. Provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 89,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610ENERGY STAR*\t\u2610CE (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 90,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610ENERGY STAR*\t\u2610CE (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 91,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610ENERGY STAR*\t\u2610CE (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 92,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Marketing claims\t\u2610CE DoC (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 93,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Marketing claims\t\u2610CE DoC (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 94,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Marketing claims\t\u2610CE DoC (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 95,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "Testing Required: <Choose an item.>",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 96,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Agency Report Revision\t\u2610Revise Engineering Drawings/Documents\t\u2610Revise Regulatory Documents (Cloud Drive)",
    "range_preview": "\u2610"
  },
  {
    "index": 97,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Agency Report Revision\t\u2610Revise Engineering Drawings/Documents\t\u2610Revise Regulatory Documents (Cloud Drive)",
    "range_preview": "\u2610"
  },
  {
    "index": 98,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Agency Report Revision\t\u2610Revise Engineering Drawings/Documents\t\u2610Revise Regulatory Documents (Cloud Drive)",
    "range_preview": "\u2610"
  },
  {
    "index": 99,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Marketing claims are validated\t\u2610 Marketing claims have not been validation",
    "range_preview": "\u2610"
  },
  {
    "index": 100,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Marketing claims are validated\t\u2610 Marketing claims have not been validation",
    "range_preview": "\u2610"
  },
  {
    "index": 101,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Change impacts product, scope is defined as requiring a new project.",
    "range_preview": "\u2610"
  },
  {
    "index": 102,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 103,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610CB of changes (ENERGY STAR, required if not testing)\t\u2610Energy Star Team Leads (ENERGY STAR)",
    "range_preview": "\u2610"
  },
  {
    "index": 104,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610CB of changes (ENERGY STAR, required if not testing)\t\u2610Energy Star Team Leads (ENERGY STAR)",
    "range_preview": "\u2610"
  },
  {
    "index": 105,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610RA at Implementation Manufacturing Location\t\u2610South Korean RA Team for in-country Testing",
    "range_preview": "\u2610"
  },
  {
    "index": 106,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610RA at Implementation Manufacturing Location\t\u2610South Korean RA Team for in-country Testing",
    "range_preview": "\u2610"
  },
  {
    "index": 107,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Authorities of Product Changes where registered\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 108,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Authorities of Product Changes where registered\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 109,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610  The change does not impact the design safety, EMC, and/or wireless compliance. Like for like components (i.e., PCBA components) should still be evaluated to ensure the safety report has not been impacted.",
    "range_preview": "\u2610"
  },
  {
    "index": 110,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Does the change affect specs, listings, warnings, or text on critical components in compliance files?",
    "range_preview": "\u2610"
  },
  {
    "index": 111,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Are the specs/ratings of the end product going to be changed? (power = re-evaluate markets)",
    "range_preview": "\u2610"
  },
  {
    "index": 112,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Are the specs/ratings of the product\u2019s environment going to be changed? (Env. conditions, spacings, etc.)",
    "range_preview": "\u2610"
  },
  {
    "index": 113,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Are the product features / use being impacted?",
    "range_preview": "\u2610"
  },
  {
    "index": 114,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Are materials going to be changed (Keeping the same part number or not)?",
    "range_preview": "\u2610"
  },
  {
    "index": 115,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Are labels, IFU, or customer facing information going to be changed?",
    "range_preview": "\u2610"
  },
  {
    "index": 116,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Will the manufacturing location or applicant of the file need to change?",
    "range_preview": "\u2610"
  },
  {
    "index": 117,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610 (Supplier change) Does the change impact split inspection locations and files? (Common for PCBA or enclosed subassemblies)",
    "range_preview": "\u2610"
  },
  {
    "index": 118,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest accepted requirements. Requested to add in scope of the current project.",
    "range_preview": "\u2610"
  },
  {
    "index": 119,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 120,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610NRTL Listing, Report # <Insert Report Number>\t\u2610EMC (EN report), Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 121,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610NRTL Listing, Report # <Insert Report Number>\t\u2610EMC (EN report), Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 122,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CB Safety, Report # <Insert Report Number>\t\u2610FCC, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 123,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CB Safety, Report # <Insert Report Number>\t\u2610FCC, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 124,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Informative Safety, Report # <Insert Report Number>\t\u2610ICES, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 125,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Informative Safety, Report # <Insert Report Number>\t\u2610ICES, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 126,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Wireless, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 127,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>, Report # <Insert Report Number>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 128,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610UL\t\u2610CSA",
    "range_preview": "\u2610"
  },
  {
    "index": 129,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610UL\t\u2610CSA",
    "range_preview": "\u2610"
  },
  {
    "index": 130,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610ETL\t\u2610TUV",
    "range_preview": "\u2610"
  },
  {
    "index": 131,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610ETL\t\u2610TUV",
    "range_preview": "\u2610"
  },
  {
    "index": 132,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610FCC / ICES\t\u2610NSF",
    "range_preview": "\u2610"
  },
  {
    "index": 133,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610FCC / ICES\t\u2610NSF",
    "range_preview": "\u2610"
  },
  {
    "index": 134,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610IRAM-S",
    "range_preview": "\u2610"
  },
  {
    "index": 135,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610INMETRO",
    "range_preview": "\u2610"
  },
  {
    "index": 136,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610ANATEL",
    "range_preview": "\u2610"
  },
  {
    "index": 137,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610 S Mark\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 138,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CE DoC (Self-Declared)",
    "range_preview": "\u2610"
  },
  {
    "index": 139,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CE DoC (EU NB)",
    "range_preview": "\u2610"
  },
  {
    "index": 140,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610UKCA\t\u2610LNE",
    "range_preview": "\u2610"
  },
  {
    "index": 141,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610UKCA\t\u2610LNE",
    "range_preview": "\u2610"
  },
  {
    "index": 142,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610GS\t\u2610WEEE\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 143,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610GS\t\u2610WEEE\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 144,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610KC Mark",
    "range_preview": "\u2610"
  },
  {
    "index": 145,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610 EAC\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 146,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the mark/label is not listed above. Provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 147,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610FCC Declaration\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 148,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CE DoC (Self-Declared)",
    "range_preview": "\u2610"
  },
  {
    "index": 149,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CE DoC (EU NB)",
    "range_preview": "\u2610"
  },
  {
    "index": 150,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610UKCA Declaration\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 151,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the document is not listed above. Provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 152,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "Testing Required: <Choose an item.>",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 153,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "Impacted Documents:\u000b\t\u2610No Update Required (justification within plan required)\t\u2610Paperwork update only",
    "range_preview": "\u2610"
  },
  {
    "index": 154,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "Impacted Documents:\u000b\t\u2610No Update Required (justification within plan required)\t\u2610Paperwork update only",
    "range_preview": "\u2610"
  },
  {
    "index": 155,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Registration with Agency required (FCC, etc.)\t\u2610Revise Engineering Drawings/Documents (i.e., labels)",
    "range_preview": "\u2610"
  },
  {
    "index": 156,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Registration with Agency required (FCC, etc.)\t\u2610Revise Engineering Drawings/Documents (i.e., labels)",
    "range_preview": "\u2610"
  },
  {
    "index": 157,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Revise Regulatory Documents (i.e., declarations)\t\u2610Re-evaluate market requirements due to changes.",
    "range_preview": "\u2610"
  },
  {
    "index": 158,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Revise Regulatory Documents (i.e., declarations)\t\u2610Re-evaluate market requirements due to changes.",
    "range_preview": "\u2610"
  },
  {
    "index": 159,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Re-evaluate product requirements due to changes.\t\u2610Re-evaluate process requirements due to changes.",
    "range_preview": "\u2610"
  },
  {
    "index": 160,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Re-evaluate product requirements due to changes.\t\u2610Re-evaluate process requirements due to changes.",
    "range_preview": "\u2610"
  },
  {
    "index": 161,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 162,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Regional Leads if registered (i.e., Saudi SASO, KC Mark, Australian RCM)\t\u2610RA at Implementation Manufacturing Location",
    "range_preview": "\u2610"
  },
  {
    "index": 163,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Regional Leads if registered (i.e., Saudi SASO, KC Mark, Australian RCM)\t\u2610RA at Implementation Manufacturing Location",
    "range_preview": "\u2610"
  },
  {
    "index": 164,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Authorities of Product Changes where registered\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 165,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Authorities of Product Changes where registered\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 166,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610  The change does not impact the end product environmental compliance. (i.e., change is associated with documentation updates)",
    "range_preview": "\u2610"
  },
  {
    "index": 167,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Change adds new or removes any components from the product (BOM update)",
    "range_preview": "\u2610"
  },
  {
    "index": 168,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610The supplier of a part number is changing",
    "range_preview": "\u2610"
  },
  {
    "index": 169,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610The manufacturing or internal part number is changing",
    "range_preview": "\u2610"
  },
  {
    "index": 170,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610End product impacted currently has an outdated BOM in Greensoft or BOM is not uploaded into GreenSoft. Requested to add in scope of the current project.",
    "range_preview": "\u2610"
  },
  {
    "index": 171,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 172,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610GreenSoft Item Submission\t\u2610GreenSoft BOM Upload Form\t\u2610GreenSoft Customer Collected Documents Form",
    "range_preview": "\u2610"
  },
  {
    "index": 173,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610GreenSoft Item Submission\t\u2610GreenSoft BOM Upload Form\t\u2610GreenSoft Customer Collected Documents Form",
    "range_preview": "\u2610"
  },
  {
    "index": 174,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610GreenSoft Item Submission\t\u2610GreenSoft BOM Upload Form\t\u2610GreenSoft Customer Collected Documents Form",
    "range_preview": "\u2610"
  },
  {
    "index": 175,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 176,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Prop65",
    "range_preview": "\u2610"
  },
  {
    "index": 177,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610FIFRA Pesticide (UV Lamp)\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 178,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610WEEE\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 179,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610WEEE\t\u2610F-Gas",
    "range_preview": "\u2610"
  },
  {
    "index": 180,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610WEEE\t\u2610F-Gas",
    "range_preview": "\u2610"
  },
  {
    "index": 181,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610PFAS\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 182,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610WEEE",
    "range_preview": "\u2610"
  },
  {
    "index": 183,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610China RoHS (C-RoHS)\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 184,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the mark/label is not listed above. Provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 185,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Prop65 Declaration",
    "range_preview": "\u2610"
  },
  {
    "index": 186,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610FIFRA Pesticide Product Reporting (UV Lamp)\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 187,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Montreal Protocol Declaration\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 188,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610REACH Declaration",
    "range_preview": "\u2610"
  },
  {
    "index": 189,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610RoHS Declaration",
    "range_preview": "\u2610"
  },
  {
    "index": 190,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610F-Gas Declaration",
    "range_preview": "\u2610"
  },
  {
    "index": 191,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610CE Declaration (Self-Declared)\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 192,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610C-RoHS \u201cTic-Tac Table\u201d Declaration\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 193,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the document is not listed above. Provide more information here, ex. Coneg, PFAS.>",
    "range_preview": "\u2610"
  },
  {
    "index": 194,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "Testing Required: <Choose an item.>",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 195,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610No Update Required\t\u2610Upload GreenSoft Form(s)\t\u2610Revise Engineering Drawings/Documents (labels)",
    "range_preview": "\u2610"
  },
  {
    "index": 196,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610No Update Required\t\u2610Upload GreenSoft Form(s)\t\u2610Revise Engineering Drawings/Documents (labels)",
    "range_preview": "\u2610"
  },
  {
    "index": 197,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610No Update Required\t\u2610Upload GreenSoft Form(s)\t\u2610Revise Engineering Drawings/Documents (labels)",
    "range_preview": "\u2610"
  },
  {
    "index": 198,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Revise Regulatory Documents (i.e., declarations)",
    "range_preview": "\u2610"
  },
  {
    "index": 199,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Change impacts product, scope is defined as requiring a new project.",
    "range_preview": "\u2610"
  },
  {
    "index": 200,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 201,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610EPA Lead if registered (FIFRA)\t\u2610GreenSoft User to load GreenSoft BOM changes (i.e., component or supplier change \u2013 site: GS Submission)",
    "range_preview": "\u2610"
  },
  {
    "index": 202,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610EPA Lead if registered (FIFRA)\t\u2610GreenSoft User to load GreenSoft BOM changes (i.e., component or supplier change \u2013 site: GS Submission)",
    "range_preview": "\u2610"
  },
  {
    "index": 203,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 204,
    "type": "checkbox",
    "tag": "",
    "title": "",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "PART A SAFETY, COMPATIBILITY, EFFECTIVENESS\u0007",
    "range_preview": "P"
  },
  {
    "index": 205,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Will the change affect the safety, compatibility, or effectiveness of the device?",
    "range_preview": "\u2610"
  },
  {
    "index": 206,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Will the technology, engineering design, or performance of the device or packaging change?",
    "range_preview": "\u2610"
  },
  {
    "index": 207,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is the change introducing a new material, or alternate component, or is it a supplier change?\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 208,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change include or impact the product\u2019s Intended use?",
    "range_preview": "\u2610"
  },
  {
    "index": 209,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change introduce new risks of harm to humans, property, or the environment?",
    "range_preview": "\u2610"
  },
  {
    "index": 210,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Will the change affect the standards this product relies upon?",
    "range_preview": "\u2610"
  },
  {
    "index": 211,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is there another registration classification that this product will align to? <Provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 212,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Will the change affect product, packaging, electronic literature, or labelling?\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 213,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IFU/User Manual\t\u2610Service Manual\t\u2610Translation(s)\t\u2610Technical Data Sheets",
    "range_preview": "\u2610"
  },
  {
    "index": 214,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IFU/User Manual\t\u2610Service Manual\t\u2610Translation(s)\t\u2610Technical Data Sheets",
    "range_preview": "\u2610"
  },
  {
    "index": 215,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IFU/User Manual\t\u2610Service Manual\t\u2610Translation(s)\t\u2610Technical Data Sheets",
    "range_preview": "\u2610"
  },
  {
    "index": 216,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IFU/User Manual\t\u2610Service Manual\t\u2610Translation(s)\t\u2610Technical Data Sheets",
    "range_preview": "\u2610"
  },
  {
    "index": 217,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610ESI/Quick Start Guide\t\u2610Marketing Material\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 218,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610ESI/Quick Start Guide\t\u2610Marketing Material\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 219,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610ESI/Quick Start Guide\t\u2610Marketing Material\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 220,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in label material\t\u2610Marking(s)\t\u2610Indication of Use\t\u2610e-IFU section",
    "range_preview": "\u2610"
  },
  {
    "index": 221,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in label material\t\u2610Marking(s)\t\u2610Indication of Use\t\u2610e-IFU section",
    "range_preview": "\u2610"
  },
  {
    "index": 222,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in label material\t\u2610Marking(s)\t\u2610Indication of Use\t\u2610e-IFU section",
    "range_preview": "\u2610"
  },
  {
    "index": 223,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in label material\t\u2610Marking(s)\t\u2610Indication of Use\t\u2610e-IFU section",
    "range_preview": "\u2610"
  },
  {
    "index": 224,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 225,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Intended Use\t\u2610Translation(s)\t\u2610Change in specs/ratings\t\u2610Change in the warnings/precautions",
    "range_preview": "\u2610"
  },
  {
    "index": 226,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Intended Use\t\u2610Translation(s)\t\u2610Change in specs/ratings\t\u2610Change in the warnings/precautions",
    "range_preview": "\u2610"
  },
  {
    "index": 227,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Intended Use\t\u2610Translation(s)\t\u2610Change in specs/ratings\t\u2610Change in the warnings/precautions",
    "range_preview": "\u2610"
  },
  {
    "index": 228,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Intended Use\t\u2610Translation(s)\t\u2610Change in specs/ratings\t\u2610Change in the warnings/precautions",
    "range_preview": "\u2610"
  },
  {
    "index": 229,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 230,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 Will the technology, engineering design, performance of the device, or packaging change?\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 231,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in control mechanism, operating principle or energy type?",
    "range_preview": "\u2610"
  },
  {
    "index": 232,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change impact the Product Requirements?",
    "range_preview": "\u2610"
  },
  {
    "index": 233,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change impact a component that is subjected to sterilization, cleaning, or disinfection?",
    "range_preview": "\u2610"
  },
  {
    "index": 234,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change to the part require that sterilization validation, cleaning validation, or disinfection validation should be repeated?",
    "range_preview": "\u2610"
  },
  {
    "index": 235,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change affect the performance or accuracy of the device?",
    "range_preview": "\u2610"
  },
  {
    "index": 236,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change involve a component, software/firmware item or other part responsible for the product achieving its intended use?",
    "range_preview": "\u2610"
  },
  {
    "index": 237,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in packaging design?",
    "range_preview": "\u2610"
  },
  {
    "index": 238,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change uses the same technology and classification as described in a previously cleared 510(k) or 510(k) exempt version?",
    "range_preview": "\u2610"
  },
  {
    "index": 239,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change impact safety critical (i.e., 61010, EMC), critical to quality, critical to performance components? (See ENG016, CTT Business Unit Engineering Change Control Process procedure for definitions.)",
    "range_preview": "\u2610"
  },
  {
    "index": 240,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change affect the intended use of the device?",
    "range_preview": "\u2610"
  },
  {
    "index": 241,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Risk-based assessment of the changed device identify any new risks or significantly modified existing risks?",
    "range_preview": "\u2610"
  },
  {
    "index": 242,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is clinical data necessary to evaluate the safety or effectiveness for purposes of design validation?\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 243,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is the change introducing a new material, alternate component, or is it a supplier change?\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 244,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is this a change in material type, material formulation, chemical composition, or the material\u2019s processing?",
    "range_preview": "\u2610"
  },
  {
    "index": 245,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Will the changed material directly or indirectly contact body tissues or fluids (Including operators and service)?",
    "range_preview": "\u2610"
  },
  {
    "index": 246,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does a risk assessment identify any new or increased biocompatibility concerns?",
    "range_preview": "\u2610"
  },
  {
    "index": 247,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Has the manufacturer used the same material in a similar legally marketed device?",
    "range_preview": "\u2610"
  },
  {
    "index": 248,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Could the change affect the device\u2019s performance specifications?",
    "range_preview": "\u2610"
  },
  {
    "index": 249,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the supplier change impact split inspection locations and files? (Common for PCBA or enclosed subassemblies)",
    "range_preview": "\u2610"
  },
  {
    "index": 250,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the supplier change affect critical components in compliance files?\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 251,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is there a change to product software or firmware?\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 252,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the SW Change impact the SW documentation? (as applicable SW QAPs/SOPs for AVL / MAR sites)",
    "range_preview": "\u2610"
  },
  {
    "index": 253,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the SW Change include a security patch related to a known vulnerability?",
    "range_preview": "\u2610"
  },
  {
    "index": 254,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is the SW Change made solely to return the system into specification of the most recently cleared device?",
    "range_preview": "\u2610"
  },
  {
    "index": 255,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the SW change introduce a new risk or modify an existing risk?",
    "range_preview": "\u2610"
  },
  {
    "index": 256,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change create or necessitate a new risk control measure or a modification of an existing risk control measure for a hazardous situation that could result in significant harm?",
    "range_preview": "\u2610"
  },
  {
    "index": 257,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Could the change impact functionality or performance specifications that are directly associated with the intended use or safety the device?",
    "range_preview": "\u2610"
  },
  {
    "index": 258,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Are there additional software factors that may affect the decision to file? (e.g., Infrastructure, Architecture, Core algorithm, Re-engineering and refactoring etc.)",
    "range_preview": "\u2610"
  },
  {
    "index": 259,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610USA: FDA 510(K) Exempt",
    "range_preview": "\u2610"
  },
  {
    "index": 260,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610USA: FDA 510(K)",
    "range_preview": "\u2610"
  },
  {
    "index": 261,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Canada: MDSAP",
    "range_preview": "\u2610"
  },
  {
    "index": 262,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Mexico: COFEPRIS\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 263,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Argentina: ANMAT",
    "range_preview": "\u2610"
  },
  {
    "index": 264,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Brazil: ANVISA",
    "range_preview": "\u2610"
  },
  {
    "index": 265,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Brazil: INMETRO",
    "range_preview": "\u2610"
  },
  {
    "index": 266,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Columbia: INVIMA",
    "range_preview": "\u2610"
  },
  {
    "index": 267,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Costa Rica: MoH",
    "range_preview": "\u2610"
  },
  {
    "index": 268,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Ecuador: ARCSA",
    "range_preview": "\u2610"
  },
  {
    "index": 269,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610El Salvador: DNM",
    "range_preview": "\u2610"
  },
  {
    "index": 270,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Guatemala: MSPAS",
    "range_preview": "\u2610"
  },
  {
    "index": 271,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Nicaragua: MINSA",
    "range_preview": "\u2610"
  },
  {
    "index": 272,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Panama: MINSA / MoH",
    "range_preview": "\u2610"
  },
  {
    "index": 273,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Peru: MINSA\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 274,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610EU: CE (NB)",
    "range_preview": "\u2610"
  },
  {
    "index": 275,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UK: MHRA",
    "range_preview": "\u2610"
  },
  {
    "index": 276,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UK: UKCA (NB)",
    "range_preview": "\u2610"
  },
  {
    "index": 277,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UK: UKCA",
    "range_preview": "\u2610"
  },
  {
    "index": 278,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Iceland: IMA",
    "range_preview": "\u2610"
  },
  {
    "index": 279,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Israel: MoH",
    "range_preview": "\u2610"
  },
  {
    "index": 280,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Egypt: EDA",
    "range_preview": "\u2610"
  },
  {
    "index": 281,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Saudi Arabia: SFDA",
    "range_preview": "\u2610"
  },
  {
    "index": 282,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Turkey: TITCK",
    "range_preview": "\u2610"
  },
  {
    "index": 283,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Norway: NoMA",
    "range_preview": "\u2610"
  },
  {
    "index": 284,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Serbia: ALIMS",
    "range_preview": "\u2610"
  },
  {
    "index": 285,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Ukraine: SMDC",
    "range_preview": "\u2610"
  },
  {
    "index": 286,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Morocco: DMP\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 287,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610China: NMPA",
    "range_preview": "\u2610"
  },
  {
    "index": 288,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Malaysia: MDA",
    "range_preview": "\u2610"
  },
  {
    "index": 289,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610South Korea: MFDS",
    "range_preview": "\u2610"
  },
  {
    "index": 290,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Taiwan: TFDA",
    "range_preview": "\u2610"
  },
  {
    "index": 291,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610India: CDSCO",
    "range_preview": "\u2610"
  },
  {
    "index": 292,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Singapore: HSA",
    "range_preview": "\u2610"
  },
  {
    "index": 293,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Japan: PMDA",
    "range_preview": "\u2610"
  },
  {
    "index": 294,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Australia: TGA",
    "range_preview": "\u2610"
  },
  {
    "index": 295,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Hong Kong: MCO",
    "range_preview": "\u2610"
  },
  {
    "index": 296,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Indonesia: MoH",
    "range_preview": "\u2610"
  },
  {
    "index": 297,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610New Zealand: MEDSAFE\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 298,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the approval/registration is not listed above. Provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 299,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610IEC 60601 Report(s), Report # <Insert Report Number>\t\u2610ILAC/IAAC Report, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 300,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610IEC 60601 Report(s), Report # <Insert Report Number>\t\u2610ILAC/IAAC Report, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 301,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IEC 61010 Report(s), Report # <Insert Report Number>\t\u2610CB Scheme Report, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 302,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IEC 61010 Report(s), Report # <Insert Report Number>\t\u2610CB Scheme Report, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 303,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the report is not listed above. Provide more information here>, Report # <Insert Report Number>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 304,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UDI\t\u2610CE (EU NB)\t \u2610  Packaging/Shipping Labels\t\u2610  Product Label",
    "range_preview": "\u2610"
  },
  {
    "index": 305,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UDI\t\u2610CE (EU NB)\t \u2610  Packaging/Shipping Labels\t\u2610  Product Label",
    "range_preview": "\u2610"
  },
  {
    "index": 306,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UDI\t\u2610CE (EU NB)\t \u2610  Packaging/Shipping Labels\t\u2610  Product Label",
    "range_preview": "\u2610"
  },
  {
    "index": 307,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UDI\t\u2610CE (EU NB)\t \u2610  Packaging/Shipping Labels\t\u2610  Product Label",
    "range_preview": "\u2610"
  },
  {
    "index": 308,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610  Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 309,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "Testing Required: <Choose an item.>",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 310,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "Registration Impact: <Choose an item.>",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 311,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Verify Intended Use consistency\t\u2610Verify changes documented in TF / DHF\t\u2610Verify changes are documented in DMR",
    "range_preview": "\u2610"
  },
  {
    "index": 312,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Verify Intended Use consistency\t\u2610Verify changes documented in TF / DHF\t\u2610Verify changes are documented in DMR",
    "range_preview": "\u2610"
  },
  {
    "index": 313,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Verify Intended Use consistency\t\u2610Verify changes documented in TF / DHF\t\u2610Verify changes are documented in DMR",
    "range_preview": "\u2610"
  },
  {
    "index": 314,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Submit to EU NB\t\u2610Submit and Update TF / DHF\t\u2610Verify 510k for change impact",
    "range_preview": "\u2610"
  },
  {
    "index": 315,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Submit to EU NB\t\u2610Submit and Update TF / DHF\t\u2610Verify 510k for change impact",
    "range_preview": "\u2610"
  },
  {
    "index": 316,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Submit to EU NB\t\u2610Submit and Update TF / DHF\t\u2610Verify 510k for change impact",
    "range_preview": "\u2610"
  },
  {
    "index": 317,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 318,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Regional RA Lead(s)\t\u2610FDA Correspondent(s)\t\u2610EU PRR(s)\t\u2610Notify RA at Implementation Manufacturing Location",
    "range_preview": "\u2610"
  },
  {
    "index": 319,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Regional RA Lead(s)\t\u2610FDA Correspondent(s)\t\u2610EU PRR(s)\t\u2610Notify RA at Implementation Manufacturing Location",
    "range_preview": "\u2610"
  },
  {
    "index": 320,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Regional RA Lead(s)\t\u2610FDA Correspondent(s)\t\u2610EU PRR(s)\t\u2610Notify RA at Implementation Manufacturing Location",
    "range_preview": "\u2610"
  },
  {
    "index": 321,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Regional RA Lead(s)\t\u2610FDA Correspondent(s)\t\u2610EU PRR(s)\t\u2610Notify RA at Implementation Manufacturing Location",
    "range_preview": "\u2610"
  },
  {
    "index": 322,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Notify Authorities of Product Changes where registered\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 323,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Notify Authorities of Product Changes where registered\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 324,
    "type": "date",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "<Click or tap to enter a date.>\u0007",
    "range_preview": "<Click or tap to enter a date.>"
  },
  {
    "index": 325,
    "type": "date",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "<Click or tap to enter a date.>\u0007",
    "range_preview": "<Click or tap to enter a date.>"
  },
  {
    "index": 326,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "(Medical Only) Did any Design verification and/or validation activities produce any unexpected issues of safety or effectiveness? <Choose an item.>",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 327,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610All affected reports were verified for change accuracy (CCL, models covered, content, etc.) and all documentation is stored in the Technical File (TF) of the product.",
    "range_preview": "\u2610"
  },
  {
    "index": 328,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Not a Medical Device",
    "range_preview": "\u2610"
  },
  {
    "index": 329,
    "type": "date",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "<Click or tap to enter a date.>\u0007",
    "range_preview": "<Click or tap to enter a date.>"
  },
  {
    "index": 330,
    "type": "date",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "<Click or tap to enter a date.>\u0007",
    "range_preview": "<Click or tap to enter a date.>"
  }
]
`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\controls_report.json
# ================================
`$lang
`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\controls_suggested.json
# ================================
`$lang
[
  {
    "index": 1,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610EPD\t\u2610ECR\t\u2610GEPC",
    "range_preview": "\u2610",
    "proposed_tag": "epd_ecr_gepc_chk",
    "proposed_title": "chk"
  },
  {
    "index": 2,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610EPD\t\u2610ECR\t\u2610GEPC",
    "range_preview": "\u2610",
    "proposed_tag": "epd_ecr_gepc_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 3,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610EPD\t\u2610ECR\t\u2610GEPC",
    "range_preview": "\u2610",
    "proposed_tag": "epd_ecr_gepc_chk_3",
    "proposed_title": "chk"
  },
  {
    "index": 4,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610  <Insert Other>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "insert_other_chk",
    "proposed_title": "chk"
  },
  {
    "index": 5,
    "type": "dropdown",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Level: <Choose a Project Level.>\u0007",
    "range_preview": "<Choose a Project Level.>",
    "proposed_tag": "level_choose_a_project_level_dd",
    "proposed_title": "Dropdown"
  },
  {
    "index": 6,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "CAPA Associated: <Select one.>",
    "range_preview": "<Select one.>",
    "proposed_tag": "capa_associated_select_one_combo",
    "proposed_title": "Combobox"
  },
  {
    "index": 7,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Design Owner:\t<Choose an item.>\tOther (if applicable): <Fill in if \u201cOther\u201d is chosen.> \tName of OEM (if applicable): <Name of OEM>",
    "range_preview": "<Choose an item.>",
    "proposed_tag": "design_owner_choose_an_item_other_combo",
    "proposed_title": "Combobox"
  },
  {
    "index": 8,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610",
    "proposed_tag": "manufacturing_site_avl_mar_lsb_oha_chk",
    "proposed_title": "chk"
  },
  {
    "index": 9,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610",
    "proposed_tag": "manufacturing_site_avl_mar_lsb_oha_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 10,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610",
    "proposed_tag": "manufacturing_site_avl_mar_lsb_oha_chk_3",
    "proposed_title": "chk"
  },
  {
    "index": 11,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610",
    "proposed_tag": "manufacturing_site_avl_mar_lsb_oha_chk_4",
    "proposed_title": "chk"
  },
  {
    "index": 12,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610",
    "proposed_tag": "manufacturing_site_avl_mar_lsb_oha_chk_5",
    "proposed_title": "chk"
  },
  {
    "index": 13,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610",
    "proposed_tag": "manufacturing_site_avl_mar_lsb_oha_chk_6",
    "proposed_title": "chk"
  },
  {
    "index": 14,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610",
    "proposed_tag": "manufacturing_site_avl_mar_lsb_oha_chk_7",
    "proposed_title": "chk"
  },
  {
    "index": 15,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610",
    "proposed_tag": "manufacturing_site_avl_mar_lsb_oha_chk_8",
    "proposed_title": "chk"
  },
  {
    "index": 16,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Design is Copy Exact: <Choose an item.>\u0007",
    "range_preview": "<Choose an item.>",
    "proposed_tag": "design_is_copy_exact_choose_an_combo",
    "proposed_title": "Combobox"
  },
  {
    "index": 17,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk",
    "proposed_title": "chk"
  },
  {
    "index": 18,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 19,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_3",
    "proposed_title": "chk"
  },
  {
    "index": 20,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_4",
    "proposed_title": "chk"
  },
  {
    "index": 21,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_5",
    "proposed_title": "chk"
  },
  {
    "index": 22,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_6",
    "proposed_title": "chk"
  },
  {
    "index": 23,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_7",
    "proposed_title": "chk"
  },
  {
    "index": 24,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_8",
    "proposed_title": "chk"
  },
  {
    "index": 25,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_9",
    "proposed_title": "chk"
  },
  {
    "index": 26,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_10",
    "proposed_title": "chk"
  },
  {
    "index": 27,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_11",
    "proposed_title": "chk"
  },
  {
    "index": 28,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_12",
    "proposed_title": "chk"
  },
  {
    "index": 29,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_13",
    "proposed_title": "chk"
  },
  {
    "index": 30,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_14",
    "proposed_title": "chk"
  },
  {
    "index": 31,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_15",
    "proposed_title": "chk"
  },
  {
    "index": 32,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_16",
    "proposed_title": "chk"
  },
  {
    "index": 33,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_17",
    "proposed_title": "chk"
  },
  {
    "index": 34,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_18",
    "proposed_title": "chk"
  },
  {
    "index": 35,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_19",
    "proposed_title": "chk"
  },
  {
    "index": 36,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "chk_20",
    "proposed_title": "chk"
  },
  {
    "index": 37,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change does not impact the Risk Management File",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_the_change_does_not_impact_the_chk",
    "proposed_title": "chk"
  },
  {
    "index": 38,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610 The product family does not have a Risk Management File or does not have a Risk Management File aligned to the latest revisions in the QMS.",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_the_product_family_does_not_have_chk",
    "proposed_title": "chk"
  },
  {
    "index": 39,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change introduces new usage conditions, or risk of harm as defined in the Risk Management Procedure (Patient, Samples, Operators, Environment, etc.).",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_the_change_introduces_new_usage_conditions",
    "proposed_title": "chk"
  },
  {
    "index": 40,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change affects the current risk probability or severity associated with existing hazards",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_the_change_affects_the_current_risk_chk",
    "proposed_title": "chk"
  },
  {
    "index": 41,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change will mean that the device will have different end users or be used in a different manner",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_the_change_will_mean_that_the_chk",
    "proposed_title": "chk"
  },
  {
    "index": 42,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The performance evaluation data for the original device is not sufficient to confirm conformity of the changed device with the required characteristics and performance",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_the_performance_evaluation_data_for_the_ch",
    "proposed_title": "chk"
  },
  {
    "index": 43,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change involves the manufacturing process (i.e., technologies, product lines)",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_the_change_involves_the_manufacturing_proc",
    "proposed_title": "chk"
  },
  {
    "index": 44,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change impacts End of Line (EOL) testing procedures (e.g., TP902 \u2013 Test procedure for all Hi Pot and Hypatia Equipment Test Machines)",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_the_change_impacts_end_of_line_chk",
    "proposed_title": "chk"
  },
  {
    "index": 45,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change requires a process validation",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_the_change_requires_a_process_validation_c",
    "proposed_title": "chk"
  },
  {
    "index": 46,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change affects agreements and/or arrangements (e.g., verification, validation, organizational structure, production site, outsourcing, subcontracting) for ensuring continued compliance with the requirements",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_the_change_affects_agreements_and_or_chk",
    "proposed_title": "chk"
  },
  {
    "index": 47,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change results from actions taken related to concerns arising from post-market surveillance including incidents/recalls/complaints (CAPA associated)",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_the_change_results_from_actions_taken_chk",
    "proposed_title": "chk"
  },
  {
    "index": 48,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change impacts Quality Control procedures, incoming acceptance criteria, or involves a change in supplier",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_the_change_impacts_quality_control_procedu",
    "proposed_title": "chk"
  },
  {
    "index": 49,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  (Medical) The change results from characteristics not previously considered in the clinical evaluation",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_medical_the_change_results_from_characteri",
    "proposed_title": "chk"
  },
  {
    "index": 50,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  (Medical) The change is driven by the development of the state of the art (e.g., latest technology)",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_medical_the_change_is_driven_by_chk",
    "proposed_title": "chk"
  },
  {
    "index": 51,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here> \u0007",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_other_if_other_is_selected_provide_chk",
    "proposed_title": "chk"
  },
  {
    "index": 52,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "Next Steps: <Choose the project action item that would need to be completed based on the scope assessment.>",
    "range_preview": "<Choose the project action item that would need to be completed based on the scope assessment.>",
    "proposed_tag": "risk_management_file_next_steps_choose_the_project_action_combo",
    "proposed_title": "RISK MANAGEMENT FILE"
  },
  {
    "index": 53,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610CAPA owner notified\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "risk_management_file_capa_owner_notified_chk",
    "proposed_title": "chk"
  },
  {
    "index": 54,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610  The change does not impact the performance compliance of the product.",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_the_change_does_not_impact_th",
    "proposed_title": "chk"
  },
  {
    "index": 55,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect degradable, moving or friction generating components (air filters, fans, hinges, etc.)",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_affect_degradable_mov",
    "proposed_title": "chk"
  },
  {
    "index": 56,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect the airflow into, throughout, and out of the unit (airflow vent, rearranging components, deck size, etc.)",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_affect_the_airflow_in",
    "proposed_title": "chk"
  },
  {
    "index": 57,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest requirements. Requested to add in scope of the current project.",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_product_currently_has_outdate",
    "proposed_title": "chk"
  },
  {
    "index": 58,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect critical components in compliance files (Electrical, refrigeration, labels)",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_affect_critical_compo",
    "proposed_title": "chk"
  },
  {
    "index": 59,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect the product performance, peak variation, temperature stability, door open recovery times",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_affect_the_product_pe",
    "proposed_title": "chk"
  },
  {
    "index": 60,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes will be made to the product power specifications, refrigeration system, or electrical systems",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_will_be_made_to_the_c",
    "proposed_title": "chk"
  },
  {
    "index": 61,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes to the internal cabinet size, construction, or configuration (inner doors, shelving, port holes)",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_to_the_internal_cabin",
    "proposed_title": "chk"
  },
  {
    "index": 62,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Change to defrosts, setpoint ranges, or code versions",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_change_to_defrosts_setpoint_r",
    "proposed_title": "chk"
  },
  {
    "index": 63,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes to the software affecting behavior or timing of behaviors",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_to_the_software_affec",
    "proposed_title": "chk"
  },
  {
    "index": 64,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest requirements. Requested to add in scope of the current project.",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_product_currently_has_outd_2",
    "proposed_title": "chk"
  },
  {
    "index": 65,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes affect the cooling capacity to cool down and maintain the temperature of the liquid",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_affect_the_cooling_ca",
    "proposed_title": "chk"
  },
  {
    "index": 66,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes affect the functionality of the medium (refrigerant, water, etc.) to chill the system continuously",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_affect_the_functional",
    "proposed_title": "chk"
  },
  {
    "index": 67,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes may affect the power input specifications",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_may_affect_the_power_",
    "proposed_title": "chk"
  },
  {
    "index": 68,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest requirements. Requested to add in scope of the current project.\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_product_currently_has_outd_3",
    "proposed_title": "chk"
  },
  {
    "index": 69,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect critical components in compliance files",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_affect_critical_co_2",
    "proposed_title": "chk"
  },
  {
    "index": 70,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest requirements. Requested to add in scope of the current project.\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_product_currently_has_outd_4",
    "proposed_title": "chk"
  },
  {
    "index": 71,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect critical components in compliance files",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_affect_critical_co_3",
    "proposed_title": "chk"
  },
  {
    "index": 72,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes to the materials of construction or coatings (paint)",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_to_the_materials_of_c",
    "proposed_title": "chk"
  },
  {
    "index": 73,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes impact air flow (blowers, power supp, filters, paper catch areas, filter screen)",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_impact_air_flow_blowe",
    "proposed_title": "chk"
  },
  {
    "index": 74,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes to the software",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_to_the_software_chk",
    "proposed_title": "chk"
  },
  {
    "index": 75,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes impacting stability (change weight distribution or change to stands)",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_impacting_stability_c",
    "proposed_title": "chk"
  },
  {
    "index": 76,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes impact cleanability (Sealing of openings that could harbor contamination, fasteners - Philip screws not allowed)",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_impact_cleanability_s",
    "proposed_title": "chk"
  },
  {
    "index": 77,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes impact the cabinet pressure decay test (seals, cabinet materials)",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_impact_the_cabinet_pr",
    "proposed_title": "chk"
  },
  {
    "index": 78,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes impact labels or markings (add, remove, location change)",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_changes_impact_labels_or_mark",
    "proposed_title": "chk"
  },
  {
    "index": 79,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest requirements. Requested to add in scope of the current project.\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_product_currently_has_outd_5",
    "proposed_title": "chk"
  },
  {
    "index": 80,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610ENERGY STAR*",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_energy_star_chk",
    "proposed_title": "chk"
  },
  {
    "index": 81,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610NSF49 BSC*",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_nsf49_bsc_chk",
    "proposed_title": "chk"
  },
  {
    "index": 82,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610NSF456 Vaccine*\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_nsf456_vaccine_chk",
    "proposed_title": "chk"
  },
  {
    "index": 83,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Clean Room Particulate 14644-14*\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_clean_room_particulate_14644_",
    "proposed_title": "chk"
  },
  {
    "index": 84,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Clean Room Particulate 14644-14*",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_clean_room_particulate_146_2",
    "proposed_title": "chk"
  },
  {
    "index": 85,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610ErP Directive (Chillers only)\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_erp_directive_chillers_only_c",
    "proposed_title": "chk"
  },
  {
    "index": 86,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Clean Room Particulate 14644-14*",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_clean_room_particulate_146_3",
    "proposed_title": "chk"
  },
  {
    "index": 87,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610South Korean Act on Environmental testing and Inspection\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_south_korean_act_on_environme",
    "proposed_title": "chk"
  },
  {
    "index": 88,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other (if applicable): <Select \u201cOther\u201d if the report is not listed above. Provide more information here.>",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_other_if_applicable_select_ot",
    "proposed_title": "chk"
  },
  {
    "index": 89,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610ENERGY STAR*\t\u2610CE (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_energy_star_ce_self_declared_",
    "proposed_title": "chk"
  },
  {
    "index": 90,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610ENERGY STAR*\t\u2610CE (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_energy_star_ce_self_declar_2",
    "proposed_title": "chk"
  },
  {
    "index": 91,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610ENERGY STAR*\t\u2610CE (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_energy_star_ce_self_declar_3",
    "proposed_title": "chk"
  },
  {
    "index": 92,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Marketing claims\t\u2610CE DoC (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_marketing_claims_ce_doc_self_",
    "proposed_title": "chk"
  },
  {
    "index": 93,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Marketing claims\t\u2610CE DoC (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_marketing_claims_ce_doc_se_2",
    "proposed_title": "chk"
  },
  {
    "index": 94,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Marketing claims\t\u2610CE DoC (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_marketing_claims_ce_doc_se_3",
    "proposed_title": "chk"
  },
  {
    "index": 95,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "Testing Required: <Choose an item.>",
    "range_preview": "<Choose an item.>",
    "proposed_tag": "performance_compliance_assessment_testing_required_choose_an_it",
    "proposed_title": "PERFORMANCE COMPLIANCE ASSESSMENT"
  },
  {
    "index": 96,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Agency Report Revision\t\u2610Revise Engineering Drawings/Documents\t\u2610Revise Regulatory Documents (Cloud Drive)",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_agency_report_revision_revise",
    "proposed_title": "chk"
  },
  {
    "index": 97,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Agency Report Revision\t\u2610Revise Engineering Drawings/Documents\t\u2610Revise Regulatory Documents (Cloud Drive)",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_agency_report_revision_rev_2",
    "proposed_title": "chk"
  },
  {
    "index": 98,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Agency Report Revision\t\u2610Revise Engineering Drawings/Documents\t\u2610Revise Regulatory Documents (Cloud Drive)",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_agency_report_revision_rev_3",
    "proposed_title": "chk"
  },
  {
    "index": 99,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Marketing claims are validated\t\u2610 Marketing claims have not been validation",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_marketing_claims_are_validate",
    "proposed_title": "chk"
  },
  {
    "index": 100,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Marketing claims are validated\t\u2610 Marketing claims have not been validation",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_marketing_claims_are_valid_2",
    "proposed_title": "chk"
  },
  {
    "index": 101,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Change impacts product, scope is defined as requiring a new project.",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_change_impacts_product_scope_",
    "proposed_title": "chk"
  },
  {
    "index": 102,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_other_if_applicable_if_other_",
    "proposed_title": "chk"
  },
  {
    "index": 103,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610CB of changes (ENERGY STAR, required if not testing)\t\u2610Energy Star Team Leads (ENERGY STAR)",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_cb_of_changes_energy_star_req",
    "proposed_title": "chk"
  },
  {
    "index": 104,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610CB of changes (ENERGY STAR, required if not testing)\t\u2610Energy Star Team Leads (ENERGY STAR)",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_cb_of_changes_energy_star__2",
    "proposed_title": "chk"
  },
  {
    "index": 105,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610RA at Implementation Manufacturing Location\t\u2610South Korean RA Team for in-country Testing",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_ra_at_implementation_manufact",
    "proposed_title": "chk"
  },
  {
    "index": 106,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610RA at Implementation Manufacturing Location\t\u2610South Korean RA Team for in-country Testing",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_ra_at_implementation_manuf_2",
    "proposed_title": "chk"
  },
  {
    "index": 107,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Authorities of Product Changes where registered\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_authorities_of_product_change",
    "proposed_title": "chk"
  },
  {
    "index": 108,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Authorities of Product Changes where registered\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "performance_compliance_assessment_authorities_of_product_cha_2",
    "proposed_title": "chk"
  },
  {
    "index": 109,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610  The change does not impact the design safety, EMC, and/or wireless compliance. Like for like components (i.e., PCBA components) should still be evaluated to ensure the safety report has not been impacted.",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_the_change_doe",
    "proposed_title": "chk"
  },
  {
    "index": 110,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Does the change affect specs, listings, warnings, or text on critical components in compliance files?",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_does_the_chang",
    "proposed_title": "chk"
  },
  {
    "index": 111,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Are the specs/ratings of the end product going to be changed? (power = re-evaluate markets)",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_are_the_specs_",
    "proposed_title": "chk"
  },
  {
    "index": 112,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Are the specs/ratings of the product\u2019s environment going to be changed? (Env. conditions, spacings, etc.)",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_are_the_spe_2",
    "proposed_title": "chk"
  },
  {
    "index": 113,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Are the product features / use being impacted?",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_are_the_produc",
    "proposed_title": "chk"
  },
  {
    "index": 114,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Are materials going to be changed (Keeping the same part number or not)?",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_are_materials_",
    "proposed_title": "chk"
  },
  {
    "index": 115,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Are labels, IFU, or customer facing information going to be changed?",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_are_labels_ifu",
    "proposed_title": "chk"
  },
  {
    "index": 116,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Will the manufacturing location or applicant of the file need to change?",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_will_the_manuf",
    "proposed_title": "chk"
  },
  {
    "index": 117,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610 (Supplier change) Does the change impact split inspection locations and files? (Common for PCBA or enclosed subassemblies)",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_supplier_chang",
    "proposed_title": "chk"
  },
  {
    "index": 118,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest accepted requirements. Requested to add in scope of the current project.",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_product_curren",
    "proposed_title": "chk"
  },
  {
    "index": 119,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_other_if_appli",
    "proposed_title": "chk"
  },
  {
    "index": 120,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610NRTL Listing, Report # <Insert Report Number>\t\u2610EMC (EN report), Report # <Insert Report Number>",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_nrtl_listing_r",
    "proposed_title": "chk"
  },
  {
    "index": 121,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610NRTL Listing, Report # <Insert Report Number>\t\u2610EMC (EN report), Report # <Insert Report Number>",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_nrtl_listin_2",
    "proposed_title": "chk"
  },
  {
    "index": 122,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CB Safety, Report # <Insert Report Number>\t\u2610FCC, Report # <Insert Report Number>",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_cb_safety_repo",
    "proposed_title": "chk"
  },
  {
    "index": 123,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CB Safety, Report # <Insert Report Number>\t\u2610FCC, Report # <Insert Report Number>",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_cb_safety_r_2",
    "proposed_title": "chk"
  },
  {
    "index": 124,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Informative Safety, Report # <Insert Report Number>\t\u2610ICES, Report # <Insert Report Number>",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_informative_sa",
    "proposed_title": "chk"
  },
  {
    "index": 125,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Informative Safety, Report # <Insert Report Number>\t\u2610ICES, Report # <Insert Report Number>",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_informative_2",
    "proposed_title": "chk"
  },
  {
    "index": 126,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Wireless, Report # <Insert Report Number>",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_wireless_repor",
    "proposed_title": "chk"
  },
  {
    "index": 127,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>, Report # <Insert Report Number>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_other_if_other",
    "proposed_title": "chk"
  },
  {
    "index": 128,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610UL\t\u2610CSA",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_ul_csa_chk",
    "proposed_title": "chk"
  },
  {
    "index": 129,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610UL\t\u2610CSA",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_ul_csa_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 130,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610ETL\t\u2610TUV",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_etl_tuv_chk",
    "proposed_title": "chk"
  },
  {
    "index": 131,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610ETL\t\u2610TUV",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_etl_tuv_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 132,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610FCC / ICES\t\u2610NSF",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_fcc_ices_nsf_c",
    "proposed_title": "chk"
  },
  {
    "index": 133,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610FCC / ICES\t\u2610NSF",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_fcc_ices_ns_2",
    "proposed_title": "chk"
  },
  {
    "index": 134,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610IRAM-S",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_iram_s_chk",
    "proposed_title": "chk"
  },
  {
    "index": 135,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610INMETRO",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_inmetro_chk",
    "proposed_title": "chk"
  },
  {
    "index": 136,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610ANATEL",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_anatel_chk",
    "proposed_title": "chk"
  },
  {
    "index": 137,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610 S Mark\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_s_mark_chk",
    "proposed_title": "chk"
  },
  {
    "index": 138,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CE DoC (Self-Declared)",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_ce_doc_self_de",
    "proposed_title": "chk"
  },
  {
    "index": 139,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CE DoC (EU NB)",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_ce_doc_eu_nb_c",
    "proposed_title": "chk"
  },
  {
    "index": 140,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610UKCA\t\u2610LNE",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_ukca_lne_chk",
    "proposed_title": "chk"
  },
  {
    "index": 141,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610UKCA\t\u2610LNE",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_ukca_lne_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 142,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610GS\t\u2610WEEE\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_gs_weee_chk",
    "proposed_title": "chk"
  },
  {
    "index": 143,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610GS\t\u2610WEEE\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_gs_weee_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 144,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610KC Mark",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_kc_mark_chk",
    "proposed_title": "chk"
  },
  {
    "index": 145,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610 EAC\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_eac_chk",
    "proposed_title": "chk"
  },
  {
    "index": 146,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the mark/label is not listed above. Provide more information here.>",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_other_select_o",
    "proposed_title": "chk"
  },
  {
    "index": 147,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610FCC Declaration\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_fcc_declaratio",
    "proposed_title": "chk"
  },
  {
    "index": 148,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CE DoC (Self-Declared)",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_ce_doc_self_2",
    "proposed_title": "chk"
  },
  {
    "index": 149,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CE DoC (EU NB)",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_ce_doc_eu_n_2",
    "proposed_title": "chk"
  },
  {
    "index": 150,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610UKCA Declaration\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_ukca_declarati",
    "proposed_title": "chk"
  },
  {
    "index": 151,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the document is not listed above. Provide more information here.>",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_other_selec_2",
    "proposed_title": "chk"
  },
  {
    "index": 152,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "Testing Required: <Choose an item.>",
    "range_preview": "<Choose an item.>",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_testing_requir",
    "proposed_title": "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
  },
  {
    "index": 153,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "Impacted Documents:\u000b\t\u2610No Update Required (justification within plan required)\t\u2610Paperwork update only",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_impacted_docum",
    "proposed_title": "chk"
  },
  {
    "index": 154,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "Impacted Documents:\u000b\t\u2610No Update Required (justification within plan required)\t\u2610Paperwork update only",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_impacted_do_2",
    "proposed_title": "chk"
  },
  {
    "index": 155,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Registration with Agency required (FCC, etc.)\t\u2610Revise Engineering Drawings/Documents (i.e., labels)",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_registration_w",
    "proposed_title": "chk"
  },
  {
    "index": 156,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Registration with Agency required (FCC, etc.)\t\u2610Revise Engineering Drawings/Documents (i.e., labels)",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_registratio_2",
    "proposed_title": "chk"
  },
  {
    "index": 157,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Revise Regulatory Documents (i.e., declarations)\t\u2610Re-evaluate market requirements due to changes.",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_revise_regulat",
    "proposed_title": "chk"
  },
  {
    "index": 158,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Revise Regulatory Documents (i.e., declarations)\t\u2610Re-evaluate market requirements due to changes.",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_revise_regu_2",
    "proposed_title": "chk"
  },
  {
    "index": 159,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Re-evaluate product requirements due to changes.\t\u2610Re-evaluate process requirements due to changes.",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_re_evaluate_pr",
    "proposed_title": "chk"
  },
  {
    "index": 160,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Re-evaluate product requirements due to changes.\t\u2610Re-evaluate process requirements due to changes.",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_re_evaluate_2",
    "proposed_title": "chk"
  },
  {
    "index": 161,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_other_if_ot_2",
    "proposed_title": "chk"
  },
  {
    "index": 162,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Regional Leads if registered (i.e., Saudi SASO, KC Mark, Australian RCM)\t\u2610RA at Implementation Manufacturing Location",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_regional_leads",
    "proposed_title": "chk"
  },
  {
    "index": 163,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Regional Leads if registered (i.e., Saudi SASO, KC Mark, Australian RCM)\t\u2610RA at Implementation Manufacturing Location",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_regional_le_2",
    "proposed_title": "chk"
  },
  {
    "index": 164,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Authorities of Product Changes where registered\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_authorities_of",
    "proposed_title": "chk"
  },
  {
    "index": 165,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Authorities of Product Changes where registered\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "design_safety_emc_wireless_compliance_assessment_authorities_2",
    "proposed_title": "chk"
  },
  {
    "index": 166,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610  The change does not impact the end product environmental compliance. (i.e., change is associated with documentation updates)",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_the_change_does_not_impact_the_chk",
    "proposed_title": "chk"
  },
  {
    "index": 167,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Change adds new or removes any components from the product (BOM update)",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_change_adds_new_or_removes_any_chk",
    "proposed_title": "chk"
  },
  {
    "index": 168,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610The supplier of a part number is changing",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_the_supplier_of_a_part_number_chk",
    "proposed_title": "chk"
  },
  {
    "index": 169,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610The manufacturing or internal part number is changing",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_the_manufacturing_or_internal_part_num",
    "proposed_title": "chk"
  },
  {
    "index": 170,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610End product impacted currently has an outdated BOM in Greensoft or BOM is not uploaded into GreenSoft. Requested to add in scope of the current project.",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_end_product_impacted_currently_has_an_",
    "proposed_title": "chk"
  },
  {
    "index": 171,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_other_if_other_is_selected_provide_chk",
    "proposed_title": "chk"
  },
  {
    "index": 172,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610GreenSoft Item Submission\t\u2610GreenSoft BOM Upload Form\t\u2610GreenSoft Customer Collected Documents Form",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_greensoft_item_submission_greensoft_bo",
    "proposed_title": "chk"
  },
  {
    "index": 173,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610GreenSoft Item Submission\t\u2610GreenSoft BOM Upload Form\t\u2610GreenSoft Customer Collected Documents Form",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_greensoft_item_submission_greensoft_2",
    "proposed_title": "chk"
  },
  {
    "index": 174,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610GreenSoft Item Submission\t\u2610GreenSoft BOM Upload Form\t\u2610GreenSoft Customer Collected Documents Form",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_greensoft_item_submission_greensoft_3",
    "proposed_title": "chk"
  },
  {
    "index": 175,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_other_if_other_is_selected_provide__2",
    "proposed_title": "chk"
  },
  {
    "index": 176,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Prop65",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_prop65_chk",
    "proposed_title": "chk"
  },
  {
    "index": 177,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610FIFRA Pesticide (UV Lamp)\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_fifra_pesticide_uv_lamp_chk",
    "proposed_title": "chk"
  },
  {
    "index": 178,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610WEEE\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_weee_chk",
    "proposed_title": "chk"
  },
  {
    "index": 179,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610WEEE\t\u2610F-Gas",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_weee_f_gas_chk",
    "proposed_title": "chk"
  },
  {
    "index": 180,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610WEEE\t\u2610F-Gas",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_weee_f_gas_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 181,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610PFAS\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_pfas_chk",
    "proposed_title": "chk"
  },
  {
    "index": 182,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610WEEE",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_weee_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 183,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610China RoHS (C-RoHS)\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_china_rohs_c_rohs_chk",
    "proposed_title": "chk"
  },
  {
    "index": 184,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the mark/label is not listed above. Provide more information here.>",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_other_select_other_if_the_mark_chk",
    "proposed_title": "chk"
  },
  {
    "index": 185,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Prop65 Declaration",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_prop65_declaration_chk",
    "proposed_title": "chk"
  },
  {
    "index": 186,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610FIFRA Pesticide Product Reporting (UV Lamp)\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_fifra_pesticide_product_reporting_uv_l",
    "proposed_title": "chk"
  },
  {
    "index": 187,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Montreal Protocol Declaration\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_montreal_protocol_declaration_chk",
    "proposed_title": "chk"
  },
  {
    "index": 188,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610REACH Declaration",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_reach_declaration_chk",
    "proposed_title": "chk"
  },
  {
    "index": 189,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610RoHS Declaration",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_rohs_declaration_chk",
    "proposed_title": "chk"
  },
  {
    "index": 190,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610F-Gas Declaration",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_f_gas_declaration_chk",
    "proposed_title": "chk"
  },
  {
    "index": 191,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610CE Declaration (Self-Declared)\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_ce_declaration_self_declared_chk",
    "proposed_title": "chk"
  },
  {
    "index": 192,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610C-RoHS \u201cTic-Tac Table\u201d Declaration\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_c_rohs_tic_tac_table_declaration_chk",
    "proposed_title": "chk"
  },
  {
    "index": 193,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the document is not listed above. Provide more information here, ex. Coneg, PFAS.>",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_other_select_other_if_the_document_chk",
    "proposed_title": "chk"
  },
  {
    "index": 194,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "Testing Required: <Choose an item.>",
    "range_preview": "<Choose an item.>",
    "proposed_tag": "environmental_assessment_testing_required_choose_an_item_combo",
    "proposed_title": "ENVIRONMENTAL ASSESSMENT"
  },
  {
    "index": 195,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610No Update Required\t\u2610Upload GreenSoft Form(s)\t\u2610Revise Engineering Drawings/Documents (labels)",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_no_update_required_upload_greensoft_fo",
    "proposed_title": "chk"
  },
  {
    "index": 196,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610No Update Required\t\u2610Upload GreenSoft Form(s)\t\u2610Revise Engineering Drawings/Documents (labels)",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_no_update_required_upload_greensoft_2",
    "proposed_title": "chk"
  },
  {
    "index": 197,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610No Update Required\t\u2610Upload GreenSoft Form(s)\t\u2610Revise Engineering Drawings/Documents (labels)",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_no_update_required_upload_greensoft_3",
    "proposed_title": "chk"
  },
  {
    "index": 198,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Revise Regulatory Documents (i.e., declarations)",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_revise_regulatory_documents_i_e_declar",
    "proposed_title": "chk"
  },
  {
    "index": 199,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Change impacts product, scope is defined as requiring a new project.",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_change_impacts_product_scope_is_define",
    "proposed_title": "chk"
  },
  {
    "index": 200,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_other_if_other_is_selected_provide__3",
    "proposed_title": "chk"
  },
  {
    "index": 201,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610EPA Lead if registered (FIFRA)\t\u2610GreenSoft User to load GreenSoft BOM changes (i.e., component or supplier change \u2013 site: GS Submission)",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_epa_lead_if_registered_fifra_greensoft",
    "proposed_title": "chk"
  },
  {
    "index": 202,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610EPA Lead if registered (FIFRA)\t\u2610GreenSoft User to load GreenSoft BOM changes (i.e., component or supplier change \u2013 site: GS Submission)",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_epa_lead_if_registered_fifra_greens_2",
    "proposed_title": "chk"
  },
  {
    "index": 203,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "environmental_assessment_other_if_other_is_selected_provide__4",
    "proposed_title": "chk"
  },
  {
    "index": 204,
    "type": "checkbox",
    "tag": "",
    "title": "",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "PART A SAFETY, COMPATIBILITY, EFFECTIVENESS\u0007",
    "range_preview": "P",
    "proposed_tag": "medical_assessment_part_a_safety_compatibility_effectiveness_ch",
    "proposed_title": "MEDICAL ASSESSMENT"
  },
  {
    "index": 205,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Will the change affect the safety, compatibility, or effectiveness of the device?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_will_the_change_affect_the_safety_chk",
    "proposed_title": "chk"
  },
  {
    "index": 206,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Will the technology, engineering design, or performance of the device or packaging change?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_will_the_technology_engineering_design_or_ch",
    "proposed_title": "chk"
  },
  {
    "index": 207,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is the change introducing a new material, or alternate component, or is it a supplier change?\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_is_the_change_introducing_a_new_chk",
    "proposed_title": "chk"
  },
  {
    "index": 208,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change include or impact the product\u2019s Intended use?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_the_change_include_or_impact_chk",
    "proposed_title": "chk"
  },
  {
    "index": 209,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change introduce new risks of harm to humans, property, or the environment?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_the_change_introduce_new_risks_chk",
    "proposed_title": "chk"
  },
  {
    "index": 210,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Will the change affect the standards this product relies upon?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_will_the_change_affect_the_standards_chk",
    "proposed_title": "chk"
  },
  {
    "index": 211,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is there another registration classification that this product will align to? <Provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_is_there_another_registration_classification",
    "proposed_title": "chk"
  },
  {
    "index": 212,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Will the change affect product, packaging, electronic literature, or labelling?\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_will_the_change_affect_product_packaging_chk",
    "proposed_title": "chk"
  },
  {
    "index": 213,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IFU/User Manual\t\u2610Service Manual\t\u2610Translation(s)\t\u2610Technical Data Sheets",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_ifu_user_manual_service_manual_translation_c",
    "proposed_title": "chk"
  },
  {
    "index": 214,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IFU/User Manual\t\u2610Service Manual\t\u2610Translation(s)\t\u2610Technical Data Sheets",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_ifu_user_manual_service_manual_translatio_2",
    "proposed_title": "chk"
  },
  {
    "index": 215,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IFU/User Manual\t\u2610Service Manual\t\u2610Translation(s)\t\u2610Technical Data Sheets",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_ifu_user_manual_service_manual_translatio_3",
    "proposed_title": "chk"
  },
  {
    "index": 216,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IFU/User Manual\t\u2610Service Manual\t\u2610Translation(s)\t\u2610Technical Data Sheets",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_ifu_user_manual_service_manual_translatio_4",
    "proposed_title": "chk"
  },
  {
    "index": 217,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610ESI/Quick Start Guide\t\u2610Marketing Material\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_esi_quick_start_guide_marketing_material_chk",
    "proposed_title": "chk"
  },
  {
    "index": 218,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610ESI/Quick Start Guide\t\u2610Marketing Material\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_esi_quick_start_guide_marketing_material__2",
    "proposed_title": "chk"
  },
  {
    "index": 219,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610ESI/Quick Start Guide\t\u2610Marketing Material\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_esi_quick_start_guide_marketing_material__3",
    "proposed_title": "chk"
  },
  {
    "index": 220,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in label material\t\u2610Marking(s)\t\u2610Indication of Use\t\u2610e-IFU section",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_change_in_label_material_marking_s_chk",
    "proposed_title": "chk"
  },
  {
    "index": 221,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in label material\t\u2610Marking(s)\t\u2610Indication of Use\t\u2610e-IFU section",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_change_in_label_material_marking_s_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 222,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in label material\t\u2610Marking(s)\t\u2610Indication of Use\t\u2610e-IFU section",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_change_in_label_material_marking_s_chk_3",
    "proposed_title": "chk"
  },
  {
    "index": 223,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in label material\t\u2610Marking(s)\t\u2610Indication of Use\t\u2610e-IFU section",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_change_in_label_material_marking_s_chk_4",
    "proposed_title": "chk"
  },
  {
    "index": 224,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_other_if_other_is_selected_provide_chk",
    "proposed_title": "chk"
  },
  {
    "index": 225,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Intended Use\t\u2610Translation(s)\t\u2610Change in specs/ratings\t\u2610Change in the warnings/precautions",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_intended_use_translation_s_change_in_chk",
    "proposed_title": "chk"
  },
  {
    "index": 226,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Intended Use\t\u2610Translation(s)\t\u2610Change in specs/ratings\t\u2610Change in the warnings/precautions",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_intended_use_translation_s_change_in_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 227,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Intended Use\t\u2610Translation(s)\t\u2610Change in specs/ratings\t\u2610Change in the warnings/precautions",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_intended_use_translation_s_change_in_chk_3",
    "proposed_title": "chk"
  },
  {
    "index": 228,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Intended Use\t\u2610Translation(s)\t\u2610Change in specs/ratings\t\u2610Change in the warnings/precautions",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_intended_use_translation_s_change_in_chk_4",
    "proposed_title": "chk"
  },
  {
    "index": 229,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_other_if_other_is_selected_provide_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 230,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 Will the technology, engineering design, performance of the device, or packaging change?\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_will_the_technology_engineering_design_perfo",
    "proposed_title": "chk"
  },
  {
    "index": 231,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in control mechanism, operating principle or energy type?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_change_in_control_mechanism_operating_princi",
    "proposed_title": "chk"
  },
  {
    "index": 232,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change impact the Product Requirements?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_the_change_impact_the_product_chk",
    "proposed_title": "chk"
  },
  {
    "index": 233,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change impact a component that is subjected to sterilization, cleaning, or disinfection?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_the_change_impact_a_component_chk",
    "proposed_title": "chk"
  },
  {
    "index": 234,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change to the part require that sterilization validation, cleaning validation, or disinfection validation should be repeated?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_the_change_to_the_part_chk",
    "proposed_title": "chk"
  },
  {
    "index": 235,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change affect the performance or accuracy of the device?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_the_change_affect_the_performance_chk",
    "proposed_title": "chk"
  },
  {
    "index": 236,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change involve a component, software/firmware item or other part responsible for the product achieving its intended use?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_the_change_involve_a_component_chk",
    "proposed_title": "chk"
  },
  {
    "index": 237,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in packaging design?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_change_in_packaging_design_chk",
    "proposed_title": "chk"
  },
  {
    "index": 238,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change uses the same technology and classification as described in a previously cleared 510(k) or 510(k) exempt version?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_change_uses_the_same_technology_and_chk",
    "proposed_title": "chk"
  },
  {
    "index": 239,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change impact safety critical (i.e., 61010, EMC), critical to quality, critical to performance components? (See ENG016, CTT Business Unit Engineering Change Control Process procedure for definitions.)",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_the_change_impact_safety_critical_chk",
    "proposed_title": "chk"
  },
  {
    "index": 240,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change affect the intended use of the device?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_the_change_affect_the_intended_chk",
    "proposed_title": "chk"
  },
  {
    "index": 241,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Risk-based assessment of the changed device identify any new risks or significantly modified existing risks?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_risk_based_assessment_of_the_changed_chk",
    "proposed_title": "chk"
  },
  {
    "index": 242,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is clinical data necessary to evaluate the safety or effectiveness for purposes of design validation?\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_is_clinical_data_necessary_to_evaluate_chk",
    "proposed_title": "chk"
  },
  {
    "index": 243,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is the change introducing a new material, alternate component, or is it a supplier change?\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_is_the_change_introducing_a_new_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 244,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is this a change in material type, material formulation, chemical composition, or the material\u2019s processing?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_is_this_a_change_in_material_chk",
    "proposed_title": "chk"
  },
  {
    "index": 245,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Will the changed material directly or indirectly contact body tissues or fluids (Including operators and service)?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_will_the_changed_material_directly_or_chk",
    "proposed_title": "chk"
  },
  {
    "index": 246,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does a risk assessment identify any new or increased biocompatibility concerns?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_a_risk_assessment_identify_any_chk",
    "proposed_title": "chk"
  },
  {
    "index": 247,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Has the manufacturer used the same material in a similar legally marketed device?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_has_the_manufacturer_used_the_same_chk",
    "proposed_title": "chk"
  },
  {
    "index": 248,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Could the change affect the device\u2019s performance specifications?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_could_the_change_affect_the_device_chk",
    "proposed_title": "chk"
  },
  {
    "index": 249,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the supplier change impact split inspection locations and files? (Common for PCBA or enclosed subassemblies)",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_the_supplier_change_impact_split_chk",
    "proposed_title": "chk"
  },
  {
    "index": 250,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the supplier change affect critical components in compliance files?\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_the_supplier_change_affect_critical_chk",
    "proposed_title": "chk"
  },
  {
    "index": 251,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is there a change to product software or firmware?\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_is_there_a_change_to_product_chk",
    "proposed_title": "chk"
  },
  {
    "index": 252,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the SW Change impact the SW documentation? (as applicable SW QAPs/SOPs for AVL / MAR sites)",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_the_sw_change_impact_the_chk",
    "proposed_title": "chk"
  },
  {
    "index": 253,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the SW Change include a security patch related to a known vulnerability?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_the_sw_change_include_a_chk",
    "proposed_title": "chk"
  },
  {
    "index": 254,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is the SW Change made solely to return the system into specification of the most recently cleared device?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_is_the_sw_change_made_solely_chk",
    "proposed_title": "chk"
  },
  {
    "index": 255,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the SW change introduce a new risk or modify an existing risk?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_the_sw_change_introduce_a_chk",
    "proposed_title": "chk"
  },
  {
    "index": 256,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change create or necessitate a new risk control measure or a modification of an existing risk control measure for a hazardous situation that could result in significant harm?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_does_the_change_create_or_necessitate_chk",
    "proposed_title": "chk"
  },
  {
    "index": 257,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Could the change impact functionality or performance specifications that are directly associated with the intended use or safety the device?",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_could_the_change_impact_functionality_or_chk",
    "proposed_title": "chk"
  },
  {
    "index": 258,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Are there additional software factors that may affect the decision to file? (e.g., Infrastructure, Architecture, Core algorithm, Re-engineering and refactoring etc.)",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_are_there_additional_software_factors_that_c",
    "proposed_title": "chk"
  },
  {
    "index": 259,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610USA: FDA 510(K) Exempt",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_usa_fda_510_k_exempt_chk",
    "proposed_title": "chk"
  },
  {
    "index": 260,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610USA: FDA 510(K)",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_usa_fda_510_k_chk",
    "proposed_title": "chk"
  },
  {
    "index": 261,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Canada: MDSAP",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_canada_mdsap_chk",
    "proposed_title": "chk"
  },
  {
    "index": 262,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Mexico: COFEPRIS\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_mexico_cofepris_chk",
    "proposed_title": "chk"
  },
  {
    "index": 263,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Argentina: ANMAT",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_argentina_anmat_chk",
    "proposed_title": "chk"
  },
  {
    "index": 264,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Brazil: ANVISA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_brazil_anvisa_chk",
    "proposed_title": "chk"
  },
  {
    "index": 265,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Brazil: INMETRO",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_brazil_inmetro_chk",
    "proposed_title": "chk"
  },
  {
    "index": 266,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Columbia: INVIMA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_columbia_invima_chk",
    "proposed_title": "chk"
  },
  {
    "index": 267,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Costa Rica: MoH",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_costa_rica_moh_chk",
    "proposed_title": "chk"
  },
  {
    "index": 268,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Ecuador: ARCSA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_ecuador_arcsa_chk",
    "proposed_title": "chk"
  },
  {
    "index": 269,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610El Salvador: DNM",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_el_salvador_dnm_chk",
    "proposed_title": "chk"
  },
  {
    "index": 270,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Guatemala: MSPAS",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_guatemala_mspas_chk",
    "proposed_title": "chk"
  },
  {
    "index": 271,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Nicaragua: MINSA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_nicaragua_minsa_chk",
    "proposed_title": "chk"
  },
  {
    "index": 272,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Panama: MINSA / MoH",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_panama_minsa_moh_chk",
    "proposed_title": "chk"
  },
  {
    "index": 273,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Peru: MINSA\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_peru_minsa_chk",
    "proposed_title": "chk"
  },
  {
    "index": 274,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610EU: CE (NB)",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_eu_ce_nb_chk",
    "proposed_title": "chk"
  },
  {
    "index": 275,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UK: MHRA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_uk_mhra_chk",
    "proposed_title": "chk"
  },
  {
    "index": 276,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UK: UKCA (NB)",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_uk_ukca_nb_chk",
    "proposed_title": "chk"
  },
  {
    "index": 277,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UK: UKCA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_uk_ukca_chk",
    "proposed_title": "chk"
  },
  {
    "index": 278,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Iceland: IMA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_iceland_ima_chk",
    "proposed_title": "chk"
  },
  {
    "index": 279,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Israel: MoH",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_israel_moh_chk",
    "proposed_title": "chk"
  },
  {
    "index": 280,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Egypt: EDA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_egypt_eda_chk",
    "proposed_title": "chk"
  },
  {
    "index": 281,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Saudi Arabia: SFDA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_saudi_arabia_sfda_chk",
    "proposed_title": "chk"
  },
  {
    "index": 282,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Turkey: TITCK",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_turkey_titck_chk",
    "proposed_title": "chk"
  },
  {
    "index": 283,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Norway: NoMA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_norway_noma_chk",
    "proposed_title": "chk"
  },
  {
    "index": 284,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Serbia: ALIMS",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_serbia_alims_chk",
    "proposed_title": "chk"
  },
  {
    "index": 285,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Ukraine: SMDC",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_ukraine_smdc_chk",
    "proposed_title": "chk"
  },
  {
    "index": 286,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Morocco: DMP\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_morocco_dmp_chk",
    "proposed_title": "chk"
  },
  {
    "index": 287,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610China: NMPA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_china_nmpa_chk",
    "proposed_title": "chk"
  },
  {
    "index": 288,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Malaysia: MDA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_malaysia_mda_chk",
    "proposed_title": "chk"
  },
  {
    "index": 289,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610South Korea: MFDS",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_south_korea_mfds_chk",
    "proposed_title": "chk"
  },
  {
    "index": 290,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Taiwan: TFDA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_taiwan_tfda_chk",
    "proposed_title": "chk"
  },
  {
    "index": 291,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610India: CDSCO",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_india_cdsco_chk",
    "proposed_title": "chk"
  },
  {
    "index": 292,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Singapore: HSA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_singapore_hsa_chk",
    "proposed_title": "chk"
  },
  {
    "index": 293,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Japan: PMDA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_japan_pmda_chk",
    "proposed_title": "chk"
  },
  {
    "index": 294,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Australia: TGA",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_australia_tga_chk",
    "proposed_title": "chk"
  },
  {
    "index": 295,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Hong Kong: MCO",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_hong_kong_mco_chk",
    "proposed_title": "chk"
  },
  {
    "index": 296,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Indonesia: MoH",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_indonesia_moh_chk",
    "proposed_title": "chk"
  },
  {
    "index": 297,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610New Zealand: MEDSAFE\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_new_zealand_medsafe_chk",
    "proposed_title": "chk"
  },
  {
    "index": 298,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the approval/registration is not listed above. Provide more information here.>",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_other_select_other_if_the_approval_chk",
    "proposed_title": "chk"
  },
  {
    "index": 299,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610IEC 60601 Report(s), Report # <Insert Report Number>\t\u2610ILAC/IAAC Report, Report # <Insert Report Number>",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_iec_60601_report_s_report_insert_chk",
    "proposed_title": "chk"
  },
  {
    "index": 300,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610IEC 60601 Report(s), Report # <Insert Report Number>\t\u2610ILAC/IAAC Report, Report # <Insert Report Number>",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_iec_60601_report_s_report_insert_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 301,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IEC 61010 Report(s), Report # <Insert Report Number>\t\u2610CB Scheme Report, Report # <Insert Report Number>",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_iec_61010_report_s_report_insert_chk",
    "proposed_title": "chk"
  },
  {
    "index": 302,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IEC 61010 Report(s), Report # <Insert Report Number>\t\u2610CB Scheme Report, Report # <Insert Report Number>",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_iec_61010_report_s_report_insert_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 303,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the report is not listed above. Provide more information here>, Report # <Insert Report Number>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_other_select_other_if_the_report_chk",
    "proposed_title": "chk"
  },
  {
    "index": 304,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UDI\t\u2610CE (EU NB)\t \u2610  Packaging/Shipping Labels\t\u2610  Product Label",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_udi_ce_eu_nb_packaging_shipping_chk",
    "proposed_title": "chk"
  },
  {
    "index": 305,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UDI\t\u2610CE (EU NB)\t \u2610  Packaging/Shipping Labels\t\u2610  Product Label",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_udi_ce_eu_nb_packaging_shipping_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 306,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UDI\t\u2610CE (EU NB)\t \u2610  Packaging/Shipping Labels\t\u2610  Product Label",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_udi_ce_eu_nb_packaging_shipping_chk_3",
    "proposed_title": "chk"
  },
  {
    "index": 307,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UDI\t\u2610CE (EU NB)\t \u2610  Packaging/Shipping Labels\t\u2610  Product Label",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_udi_ce_eu_nb_packaging_shipping_chk_4",
    "proposed_title": "chk"
  },
  {
    "index": 308,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610  Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_other_if_other_is_selected_provide_chk_3",
    "proposed_title": "chk"
  },
  {
    "index": 309,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "Testing Required: <Choose an item.>",
    "range_preview": "<Choose an item.>",
    "proposed_tag": "medical_assessment_testing_required_choose_an_item_combo",
    "proposed_title": "MEDICAL ASSESSMENT"
  },
  {
    "index": 310,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "Registration Impact: <Choose an item.>",
    "range_preview": "<Choose an item.>",
    "proposed_tag": "medical_assessment_registration_impact_choose_an_item_combo",
    "proposed_title": "MEDICAL ASSESSMENT"
  },
  {
    "index": 311,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Verify Intended Use consistency\t\u2610Verify changes documented in TF / DHF\t\u2610Verify changes are documented in DMR",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_verify_intended_use_consistency_verify_chang",
    "proposed_title": "chk"
  },
  {
    "index": 312,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Verify Intended Use consistency\t\u2610Verify changes documented in TF / DHF\t\u2610Verify changes are documented in DMR",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_verify_intended_use_consistency_verify_ch_2",
    "proposed_title": "chk"
  },
  {
    "index": 313,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Verify Intended Use consistency\t\u2610Verify changes documented in TF / DHF\t\u2610Verify changes are documented in DMR",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_verify_intended_use_consistency_verify_ch_3",
    "proposed_title": "chk"
  },
  {
    "index": 314,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Submit to EU NB\t\u2610Submit and Update TF / DHF\t\u2610Verify 510k for change impact",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_submit_to_eu_nb_submit_and_chk",
    "proposed_title": "chk"
  },
  {
    "index": 315,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Submit to EU NB\t\u2610Submit and Update TF / DHF\t\u2610Verify 510k for change impact",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_submit_to_eu_nb_submit_and_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 316,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Submit to EU NB\t\u2610Submit and Update TF / DHF\t\u2610Verify 510k for change impact",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_submit_to_eu_nb_submit_and_chk_3",
    "proposed_title": "chk"
  },
  {
    "index": 317,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_other_if_other_is_selected_provide_chk_4",
    "proposed_title": "chk"
  },
  {
    "index": 318,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Regional RA Lead(s)\t\u2610FDA Correspondent(s)\t\u2610EU PRR(s)\t\u2610Notify RA at Implementation Manufacturing Location",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_regional_ra_lead_s_fda_correspondent_chk",
    "proposed_title": "chk"
  },
  {
    "index": 319,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Regional RA Lead(s)\t\u2610FDA Correspondent(s)\t\u2610EU PRR(s)\t\u2610Notify RA at Implementation Manufacturing Location",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_regional_ra_lead_s_fda_correspondent_chk_2",
    "proposed_title": "chk"
  },
  {
    "index": 320,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Regional RA Lead(s)\t\u2610FDA Correspondent(s)\t\u2610EU PRR(s)\t\u2610Notify RA at Implementation Manufacturing Location",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_regional_ra_lead_s_fda_correspondent_chk_3",
    "proposed_title": "chk"
  },
  {
    "index": 321,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Regional RA Lead(s)\t\u2610FDA Correspondent(s)\t\u2610EU PRR(s)\t\u2610Notify RA at Implementation Manufacturing Location",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_regional_ra_lead_s_fda_correspondent_chk_4",
    "proposed_title": "chk"
  },
  {
    "index": 322,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Notify Authorities of Product Changes where registered\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_notify_authorities_of_product_changes_where_",
    "proposed_title": "chk"
  },
  {
    "index": 323,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Notify Authorities of Product Changes where registered\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_notify_authorities_of_product_changes_whe_2",
    "proposed_title": "chk"
  },
  {
    "index": 324,
    "type": "date",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "<Click or tap to enter a date.>\u0007",
    "range_preview": "<Click or tap to enter a date.>",
    "proposed_tag": "medical_assessment_click_or_tap_to_enter_a_date",
    "proposed_title": "MEDICAL ASSESSMENT"
  },
  {
    "index": 325,
    "type": "date",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "<Click or tap to enter a date.>\u0007",
    "range_preview": "<Click or tap to enter a date.>",
    "proposed_tag": "medical_assessment_click_or_tap_to_enter_a_date_2",
    "proposed_title": "MEDICAL ASSESSMENT"
  },
  {
    "index": 326,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "(Medical Only) Did any Design verification and/or validation activities produce any unexpected issues of safety or effectiveness? <Choose an item.>",
    "range_preview": "<Choose an item.>",
    "proposed_tag": "medical_assessment_medical_only_did_any_design_verification_com",
    "proposed_title": "MEDICAL ASSESSMENT"
  },
  {
    "index": 327,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610All affected reports were verified for change accuracy (CCL, models covered, content, etc.) and all documentation is stored in the Technical File (TF) of the product.",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_all_affected_reports_were_verified_for_chk",
    "proposed_title": "chk"
  },
  {
    "index": 328,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Not a Medical Device",
    "range_preview": "\u2610",
    "proposed_tag": "medical_assessment_not_a_medical_device_chk",
    "proposed_title": "chk"
  },
  {
    "index": 329,
    "type": "date",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "<Click or tap to enter a date.>\u0007",
    "range_preview": "<Click or tap to enter a date.>",
    "proposed_tag": "medical_assessment_click_or_tap_to_enter_a_date_3",
    "proposed_title": "MEDICAL ASSESSMENT"
  },
  {
    "index": 330,
    "type": "date",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "<Click or tap to enter a date.>\u0007",
    "range_preview": "<Click or tap to enter a date.>",
    "proposed_tag": "medical_assessment_click_or_tap_to_enter_a_date_4",
    "proposed_title": "MEDICAL ASSESSMENT"
  }
]
`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\convert_chk_tokens_to_controls.py
# ================================
`$lang
# convert_chk_tokens_to_controls.py
# Usage:
#   python convert_chk_tokens_to_controls.py "C:\path\to\refernce_template_unlocked_forced_escaped.docx"
#
# Requires: pywin32 (pip install pywin32)
import sys
import os
import traceback
import win32com.client as com

if len(sys.argv) < 2:
    print("Usage: python convert_chk_tokens_to_controls.py <docx_path> [out_path]")
    sys.exit(1)

IN_PATH = sys.argv[1]
OUT_PATH = sys.argv[2] if len(sys.argv) > 2 else IN_PATH.replace(".docx", "_controls.docx")

# Word constants (we only need small subset)
wdFindStop = 0
wdCollapseEnd = 0
wdCharacter = 1
wdContentControlCheckBox = 8

def sanitize_tag(s: str) -> str:
    s = (s or "").strip()
    if not s:
        return "chk"
    out = []
    for ch in s:
        if ch.isalnum() or ch == "_":
            out.append(ch)
        elif ch in (" ", "-", "/"):
            out.append("_")
    t = "".join(out).lower()[:64]
    return t or "chk"

def process_story_range(doc, story_range):
    """Searches for literal token <<CHK>> and replaces with checkbox content control.
       Returns number converted in this story.
    """
    converted = 0
    rng = story_range
    f = rng.Find
    f.ClearFormatting()
    f.Replacement.ClearFormatting()
    # Literal token to find
    f.Text = "<<CHK>>"
    f.MatchCase = False
    f.MatchWholeWord = False
    f.MatchWildcards = False
    f.Wrap = wdFindStop

    iteration = 0
    # We use Execute() in a loop; after each replacement we move the search start to the end of inserted CC
    while True:
        found = f.Execute()
        if not found:
            break
        iteration += 1
        hit = f.Parent  # Range of the found token
        sample = (hit.Text or "").replace("\r","\\r").replace("\n","\\n")
        print(f"  Found token (storyType={getattr(story_range, 'StoryType', '?')}) sample={repr(sample[:60])}")

        # Try to get label right after token (a small run of text until next token or paragraph break)
        lbl = hit.Duplicate
        try:
            lbl.Collapse(0)  # collapse to start
        except Exception:
            pass

        # Extend label until next token occurrence or paragraph/line break (character stepping)
        try:
            while lbl.End < rng.End:
                nxt = lbl.Document.Range(lbl.End, lbl.End+1).Text
                if not nxt:
                    break
                if nxt in ("<", ">", "\r", "\n"):  # stop on new tokens or paragraph
                    break
                # also stop if we see start of another "<<"
                # check the next two chars
                look = lbl.Document.Range(lbl.End, min(lbl.End+2, rng.End)).Text
                if look.startswith("<<"):
                    break
                lbl.MoveEnd(Unit=wdCharacter, Count=1)
        except Exception:
            # defensive: if stepping fails, bail to avoid infinite loop
            pass

        label_text = (lbl.Text or "").strip()
        if label_text:
            print(f"    label preview: {repr(label_text[:80])}")
        else:
            print("    no label found (empty)")

        # Replace the token text with a content-control checkbox anchored at the hit range
        try:
            # delete token
            hit.Text = ""
            # ensure spacing before label if needed
            if lbl.Start > hit.Start:
                # if the char right after the inserted spot is not a space, insert a space so label sits nicely
                if hit.Document.Range(hit.Start, hit.Start+1).Text != " ":
                    hit.Text = " "
                    # collapse to end of run
                    try:
                        hit.Collapse(wdCollapseEnd)
                    except Exception:
                        pass

            cc = doc.ContentControls.Add(wdContentControlCheckBox, hit)
            # default unchecked; if later you want checked by token, detect variant token e.g. <<CHK_ON>>
            try:
                cc.Checked = False
            except Exception:
                # some Word versions may raise — ignore
                pass
            cc.Tag = sanitize_tag(label_text or "chk")
            cc.Title = label_text[:255] if label_text else "chk"
            converted += 1
            print(f"    inserted checkbox control tag={cc.Tag}")
            # Move the parent search range start to the end of the inserted control
            rng.Start = cc.Range.End
            f = rng.Find
            f.ClearFormatting(); f.Replacement.ClearFormatting()
            f.Text = "<<CHK>>"; f.MatchWildcards = False; f.Wrap = wdFindStop
        except Exception as e:
            print("    ERROR inserting control:", e)
            traceback.print_exc()
            # advance search to avoid infinite loop
            try:
                rng.Start = hit.End + 1
                f = rng.Find
                f.Text = "<<CHK>>"; f.MatchWildcards = False; f.Wrap = wdFindStop
            except Exception:
                break

    return converted

def main():
    print("Opening Word (COM)...")
    word = com.Dispatch("Word.Application")
    word.Visible = False
    # try to open read-write; allow Word to repair if needed by setting AddToRecentFiles=False (optional)
    doc = None
    try:
        doc = word.Documents.Open(os.path.abspath(IN_PATH))
    except Exception as e:
        print("Failed to open document. Trying Unprotect / OpenReadOnly fallback. Error:", e)
        # try reopening read-only then copy - but simplest: re-raise
        raise

    total_converted = 0
    try:
        # Try to unprotect if protected with empty password
        try:
            if doc.ProtectionType != -1:  # -1 = wdNoProtection
                try:
                    doc.Unprotect("")  # try empty password
                    print("Document was protected: attempted Unprotect(\"\")")
                except Exception:
                    print("Document is protected and could not be automatically unprotected. Please unprotect manually and re-run.")
        except Exception:
            # some doc types may not expose ProtectionType; ignore
            pass

        # iterate story ranges
        story = doc.StoryRanges(1)  # wdMainTextStory
        story_n = 0
        while story is not None:
            story_n += 1
            print(f"Processing story #{story_n} (Type={getattr(story, 'StoryType', '?')})")
            converted = process_story_range(doc, story)
            print(f"  converted in this story: {converted}")
            total_converted += converted
            try:
                story = story.NextStoryRange
            except Exception:
                story = None

        if total_converted:
            doc.SaveAs(os.path.abspath(OUT_PATH))
            print("Saved new document with controls at:", OUT_PATH)
        else:
            print("Converted 0 tokens — no changes made.")
    finally:
        if doc:
            doc.Close(False)
        word.Quit()
        print("Done. Total converted:", total_converted)

if __name__ == "__main__":
    main()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\convert_glyphs_to_controls_safe_fixed.py
# ================================
`$lang
# convert_glyphs_to_controls_safe_fixed.py
"""
Safe converter: replace checkbox glyphs (☐, ☑) with Word checkbox content-controls.
Use on Windows with MS Word + pywin32.

Usage:
  python convert_glyphs_to_controls_safe_fixed.py <input.docx>

Output:
  <input>_controls.docx (or timestamped if exists)
"""

import os, sys, time
import win32com.client as com
from win32com.client import constants as _const_module

# ---------- CONFIG ----------
INPUT_DOCX = None   # or set path here
# ----------------------------

def get_const(name, default):
    try:
        return getattr(_const_module, name)
    except Exception:
        return default

# Fallback numeric values used by Word interop
WD_FIND_STOP = get_const("wdFindStop", 0)         # 0
WD_COLLAPSE_START = get_const("wdCollapseStart", 1)  # 1
WD_COLLAPSE_END = get_const("wdCollapseEnd", 0)      # 0 (note: Word's numeric mapping can vary; using common values)
WD_CHARACTER = get_const("wdCharacter", 1)        # unit for MoveEnd
WD_MAIN_TEXT_STORY = get_const("wdMainTextStory", 1)

def sanitize_tag(s):
    s = (s or "").strip()
    if not s:
        return "auto_checkbox"
    out = []
    for ch in s:
        if ch.isalnum() or ch == "_":
            out.append(ch)
        elif ch in (" ", "-", "/"):
            out.append("_")
    t = "".join(out).lower() or "auto_checkbox"
    return (t[:60]).rstrip("_")

def process_story_range(story_range, rng_doc_end):
    if story_range is None:
        return 0
    converted = 0
    rng = story_range.Duplicate
    rng.Start = story_range.Start
    rng.End = story_range.End

    # We'll search for both checked (☑) and unchecked (☐)
    for glyph in ("☑", "☐"):
        f = rng.Find
        # Clear formatting if available
        try:
            f.ClearFormatting()
            f.Replacement.ClearFormatting()
        except Exception:
            pass
        f.Text = glyph
        # safe flags
        try:
            f.MatchCase = True
        except Exception:
            pass
        try:
            f.MatchWildcards = False
        except Exception:
            pass
        try:
            f.Wrap = WD_FIND_STOP
        except Exception:
            pass

        # iterate finds
        while True:
            try:
                found = f.Execute()
            except Exception:
                # If Execute fails, break to avoid infinite loop
                break
            if not found:
                break
            try:
                hit = f.Parent
            except Exception:
                break
            was_checked = (glyph == "☑")

            # Create a label range immediately after the hit (to use as Title/Tag)
            lbl = hit.Duplicate
            # Collapse to end (so label starts at the end of the glyph)
            try:
                lbl.Collapse(WD_COLLAPSE_END)
            except Exception:
                # Try alternate numeric fallback
                try:
                    lbl.Collapse(0)
                except Exception:
                    pass

            # extend label until next glyph or paragraph break
            cset = set(["☐", "☑", "\r"])
            unit_char = WD_CHARACTER
            while True:
                try:
                    if lbl.End >= rng.End:
                        break
                    next_char = lbl.Document.Range(lbl.End, lbl.End+1).Text
                except Exception:
                    break
                if next_char in cset:
                    break
                try:
                    lbl.MoveEnd(Unit=unit_char, Count=1)
                except Exception:
                    # fallback to manual End increment
                    try:
                        lbl.End = lbl.End + 1
                    except Exception:
                        break

            label_text = (lbl.Text or "").strip()

            # Remove the glyph text (replace with nothing; if spacing needed, ensure space inserted)
            try:
                hit.Text = ""
            except Exception:
                try:
                    hit.Delete()
                except Exception:
                    pass

            # Ensure a space before label if the label is immediate next to where glyph was
            try:
                if lbl.Start > hit.Start:
                    if hit.Document.Range(hit.Start, hit.Start+1).Text != " ":
                        hit.Text = " "
            except Exception:
                pass

            # Add checkbox content control at 'hit' range (which may be an insertion point or single space)
            try:
                cc = rng.Document.ContentControls.Add(get_const("wdContentControlCheckBox", 8), hit)
                try:
                    cc.Checked = was_checked
                except Exception:
                    # Some Word versions don't allow setting Checked directly; ignore
                    pass
                tt = label_text or "checkbox"
                cc.Tag = sanitize_tag(tt)
                cc.Title = tt
                converted += 1
                # move search start forward to avoid re-finding same area
                try:
                    rng.Start = cc.Range.End
                except Exception:
                    try:
                        rng.Start = hit.End + 1
                    except Exception:
                        rng.Start = hit.End
                # rebind the Find object to new rng
                f = rng.Find
                try:
                    f.ClearFormatting(); f.Replacement.ClearFormatting()
                except Exception:
                    pass
                f.Text = glyph
                try:
                    f.Wrap = WD_FIND_STOP
                except Exception:
                    pass
            except Exception:
                # If adding CC failed, skip forward a bit to avoid infinite loop
                try:
                    rng.Start = hit.End + 1
                except Exception:
                    try:
                        rng.Start = hit.End
                    except Exception:
                        break

    return converted

def main():
    global INPUT_DOCX
    infile = INPUT_DOCX or (sys.argv[1] if len(sys.argv) > 1 else None)
    if not infile:
        print("Usage: python convert_glyphs_to_controls_safe_fixed.py <input.docx>")
        return
    infile = os.path.abspath(infile)
    if not os.path.exists(infile):
        print("Input file not found:", infile); return

    outpath = infile.replace(".docx", "_controls.docx")
    if os.path.exists(outpath):
        base = outpath.replace(".docx", "")
        outpath = f"{base}_{int(time.time())}.docx"

    word = com.Dispatch("Word.Application")
    word.Visible = False
    try:
        doc = word.Documents.Open(infile)
    except Exception as e:
        print("Failed to open document in Word COM:", e)
        try:
            word.Quit()
        except:
            pass
        return

    total_converted = 0
    try:
        # Try to unprotect if needed (no password)
        try:
            if getattr(doc, "ProtectionType", -1) != -1:
                try:
                    doc.Unprotect()
                except Exception:
                    pass
        except Exception:
            pass

        story = doc.StoryRanges(WD_MAIN_TEXT_STORY)
        processed = 0
        while story is not None:
            processed += 1
            converted = process_story_range(story, doc.Range().End)
            total_converted += converted
            try:
                story = story.NextStoryRange
            except Exception:
                break

        # Save as new file
        try:
            doc.SaveAs2(outpath)
        except Exception:
            try:
                doc.SaveAs(outpath)
            except Exception as e2:
                print("SaveAs failed:", e2)
                try:
                    doc.Save()
                    import shutil
                    shutil.copy2(infile, outpath)
                except Exception:
                    pass

        print(f"Processed {processed} story ranges.")
        print(f"Converted {total_converted} glyphs to checkbox content-controls.")
        print("Saved new file at:", outpath)
    finally:
        try:
            doc.Close(False)
        except:
            pass
        try:
            word.Quit()
        except:
            pass

if __name__ == "__main__":
    main()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\convert_glyphs_to_controls_safe.py
# ================================
`$lang
# convert_glyphs_to_controls_safe.py
"""
Converts glyph checkboxes (☐, ☑) into Word content-control checkboxes using COM.
Saves output to a new file: <input>_controls.docx

Requirements: Windows + MS Word + pywin32 installed
( pip install pywin32 )
"""

import os, sys, time
import win32com.client as com
from win32com.client import constants

# ---------- CONFIG ----------
# set to None to accept filename via argv, otherwise edit below
INPUT_DOCX = None
# ----------------------------

def sanitize_tag(s):
    s = (s or "").strip()
    if not s:
        return "auto_checkbox"
    out = []
    for ch in s:
        if ch.isalnum() or ch == "_":
            out.append(ch)
        elif ch in (" ", "-", "/"):
            out.append("_")
    t = "".join(out).lower() or "auto_checkbox"
    # ensure tag isn't too long
    return (t[:60]).rstrip("_")

def process_story_range(story_range, doc_end):
    """
    Process glyphs inside the provided story_range (Range object).
    We'll do two passes: '☑' then '☐' to reliably capture checked state.
    """
    if story_range is None:
        return 0
    converted = 0
    rng = story_range.Duplicate
    rng.Start = story_range.Start
    rng.End = story_range.End

    # two passes so we detect checked vs unchecked properly
    for glyph in ("☑", "☐"):
        f = rng.Find
        f.ClearFormatting()
        f.Replacement.ClearFormatting()
        f.Text = glyph
        f.MatchCase = True
        f.MatchWildcards = False
        f.Wrap = constants.wdFindStop
        # search forward until no more occurrences in this range
        while True:
            found = f.Execute()
            if not found:
                break
            try:
                hit = f.Parent  # the Range containing the found glyph
            except Exception:
                break
            was_checked = (glyph == "☑")
            # build label: from after hit to next glyph or paragraph end
            lbl = hit.Duplicate
            try:
                lbl.Collapse(constants.wdCollapseEnd)
            except Exception:
                # collapse may use different constants on some systems; try numeric fallback:
                try:
                    lbl.Collapse(0)
                except:
                    pass
            # extend label until next checkbox glyph or paragraph break
            cset = set(["☐","☑","\r"])
            # MoveEnd with Unit=wdCharacter (1)
            unit_char = constants.wdCharacter if hasattr(constants, "wdCharacter") else 1
            while True:
                if lbl.End >= rng.End:
                    break
                next_char = lbl.Document.Range(lbl.End, lbl.End+1).Text
                if next_char in cset:
                    break
                try:
                    lbl.MoveEnd(Unit=unit_char, Count=1)
                except Exception:
                    # if MoveEnd fails, fall back to incrementing End index (best-effort)
                    try:
                        lbl.End = lbl.End + 1
                    except Exception:
                        break
            label_text = lbl.Text.strip()
            # Remove the glyph from document (replace with nothing or a space if needed)
            try:
                hit.Text = ""
            except Exception:
                # fallback: replace using range
                try:
                    hit.Delete()
                except:
                    pass
            # ensure a space before label if there was no spacing originally
            if lbl.Start > hit.Start:
                try:
                    if hit.Document.Range(hit.Start, hit.Start+1).Text != " ":
                        hit.Text = " "
                except Exception:
                    pass

            # create the checkbox content control at the location of 'hit' (which is now a small range)
            try:
                cc = rng.Document.ContentControls.Add(constants.wdContentControlCheckBox, hit)
                try:
                    cc.Checked = was_checked
                except Exception:
                    pass
                tt = label_text or "checkbox"
                cc.Tag = sanitize_tag(tt)
                cc.Title = tt
                converted += 1
                # advance the search range forward (start after the newly created CC)
                rng.Start = cc.Range.End
                # rewire find to current rng
                f = rng.Find
                f.ClearFormatting()
                f.Replacement.ClearFormatting()
                f.Text = glyph
                f.MatchCase = True
                f.MatchWildcards = False
                f.Wrap = constants.wdFindStop
            except Exception as e:
                # If adding control fails, try to skip past this position to avoid infinite loop
                try:
                    rng.Start = hit.End + 1
                except Exception:
                    rng.Start = hit.End
    return converted

def main():
    global INPUT_DOCX
    infile = INPUT_DOCX or (sys.argv[1] if len(sys.argv) > 1 else None)
    if not infile:
        print("Usage: python convert_glyphs_to_controls_safe.py <input.docx>")
        return
    infile = os.path.abspath(infile)
    if not os.path.exists(infile):
        print("Input file not found:", infile); return

    outpath = infile.replace(".docx", "_controls.docx")
    # ensure we don't overwrite existing file - append timestamp if needed
    if os.path.exists(outpath):
        base = outpath.replace(".docx", "")
        outpath = f"{base}_{int(time.time())}.docx"

    word = com.Dispatch("Word.Application")
    word.Visible = False
    try:
        doc = word.Documents.Open(infile)
    except Exception as e:
        print("Failed to open document in Word COM:", e)
        try:
            word.Quit()
        except:
            pass
        return

    total_converted = 0
    try:
        # If doc is protected and unprotectable w/o password, try to call Unprotect()
        try:
            if getattr(doc, "ProtectionType", -1) != -1:
                # If protected, attempt to unprotect (no password)
                try:
                    doc.Unprotect()
                except Exception:
                    pass
        except Exception:
            pass

        # Process all story ranges (main+headers/footers/etc)
        story = doc.StoryRanges(1)  # wdMainTextStory == 1
        processed_stories = 0
        while story is not None:
            processed_stories += 1
            converted = process_story_range(story, doc.Range().End)
            total_converted += converted
            # go to next story
            try:
                story = story.NextStoryRange
            except Exception:
                break

        # Save to new file
        try:
            doc.SaveAs2(outpath)
        except Exception:
            try:
                doc.SaveAs(outpath)
            except Exception as e2:
                print("Failed saving with SaveAs2/SaveAs:", e2)
                # fallback: Save and then copy
                doc.Save()
                import shutil
                shutil.copy2(infile, outpath)
        print(f"Converted {total_converted} glyphs to content-controls.")
        print("Saved new file at:", outpath)
    finally:
        try:
            doc.Close(False)
        except:
            pass
        try:
            word.Quit()
        except:
            pass

if __name__ == "__main__":
    main()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\convert_glyphs_to_controls.py
# ================================
`$lang
# convert_glyphs_to_controls.py
import win32com.client as com

DOC = r"C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited\refernce_template_unlocked.docx"

def sanitize_tag(s):
    s = (s or "").strip()
    if not s:
        return "auto_checkbox"
    out = []
    for ch in s:
        if ch.isalnum() or ch == "_":
            out.append(ch)
        elif ch in (" ", "-", "/"):
            out.append("_")
    t = "".join(out).lower() or "auto_checkbox"
    return t

def process_range(rng):
    wdFindStop = 0
    wdCollapseEnd = 0
    wdContentControlCheckBox = 8

    f = rng.Duplicate.Find
    f.ClearFormatting()
    f.Replacement.ClearFormatting()
    # Find either ☐ (U+2610) or ☑ (U+2611)
    f.Text = "[\u2610\u2611]"
    f.MatchWildcards = True
    f.Wrap = wdFindStop

    while f.Execute():
        hit = f.Parent  # the glyph range
        was_checked = (hit.Text == "\u2611")

        # Label to the right: up to next checkbox or paragraph break
        lbl = hit.Duplicate
        lbl.Collapse(0)  # wdCollapseStart=1, End=0 (Word quirk via pywin32; try both if needed)
        # Extend until next ☐/☑ or paragraph end
        # Workaround: step char-by-char
        cset = set(["\u2610", "\u2611", "\r"])
        while True:
            if lbl.End >= rng.End:
                break
            next_char = lbl.Document.Range(lbl.End, lbl.End+1).Text
            if next_char in cset:
                break
            lbl.MoveEnd(Unit=1, Count=1)  # wdCharacter
        label_text = lbl.Text.strip()

        # Replace glyph with control
        hit.Text = ""
        # If label starts immediately, add a space
        if lbl.Start > hit.Start:
            if hit.Document.Range(hit.Start, hit.Start+1).Text != " ":
                hit.Text = " "
                hit.Collapse(wdCollapseEnd)

        cc = rng.Document.ContentControls.Add(wdContentControlCheckBox, hit)
        try:
            cc.Checked = was_checked
        except Exception:
            pass
        cc.Tag = sanitize_tag(label_text)
        cc.Title = label_text

        # Continue after this control
        rng.Start = cc.Range.End
        f = rng.Find
        f.Text = "[\u2610\u2611]"
        f.MatchWildcards = True
        f.Wrap = wdFindStop

def main():
    word = com.Dispatch("Word.Application")
    word.Visible = False
    doc = word.Documents.Open(DOC)
    try:
        # Process all stories (body + headers/footers)
        story = doc.StoryRanges(1)  # wdMainTextStory
        while True:
            process_range(story)
            try:
                story = story.NextStoryRange
                if story is None: break
            except Exception:
                break
        doc.Save()
        print("Converted and saved.")
    finally:
        doc.Close(False)
        word.Quit()

if __name__ == "__main__":
    main()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\count_content_controls.py
# ================================
`$lang
# count_content_controls.py
# Usage: python count_content_controls.py "path\to\refernce_template_unlocked_forced_escaped_controls.docx"
import sys, os
import win32com.client as com
IN = sys.argv[1] if len(sys.argv)>1 else "refernce_template_unlocked_forced_escaped_controls.docx"
wdContentControlCheckBox = 8

word = com.Dispatch("Word.Application")
word.Visible = False
doc = word.Documents.Open(os.path.abspath(IN))
try:
    cc_count = doc.ContentControls.Count
    print("Total content controls:", cc_count)
    for i in range(1, cc_count+1):
        cc = doc.ContentControls.Item(i)
        t = getattr(cc, "Title", "")
        tag = getattr(cc, "Tag", "")
        ctype = getattr(cc, "Type", None)
        is_cb = (ctype == wdContentControlCheckBox)
        checked = None
        try:
            checked = getattr(cc, "Checked")
        except Exception:
            pass
        rng_text = cc.Range.Text.replace("\r","\\r").replace("\n","\\n")
        print(f"{i:03d}: type={ctype} checkbox={is_cb} checked={checked} tag={tag!r} title={t!r} range_preview={repr(rng_text[:80])}")
finally:
    doc.Close(False)
    word.Quit()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\dump_doc_controls.py
# ================================
`$lang
# dump_doc_controls.py
# Usage: python dump_doc_controls.py <file.docx>
import sys
import os
import win32com.client as com
import json

def dump(path):
    word = com.Dispatch("Word.Application")
    word.Visible = False
    doc = word.Documents.Open(os.path.abspath(path))
    try:
        out = {"file": path, "content_controls": [], "formfields": []}
        consts = com.constants
        # ContentControls
        for i in range(1, doc.ContentControls.Count + 1):
            cc = doc.ContentControls.Item(i)
            try:
                ctype = cc.Type
            except Exception:
                ctype = None
            item = {
                "index": i,
                "type_raw": ctype,
                "type_name": getattr(com.constants, f"wdContentControl{''}", "unknown"),
                "tag": getattr(cc, "Tag", ""),
                "title": getattr(cc, "Title", ""),
                "placeholder_text": getattr(cc, "PlaceholderText", "") if hasattr(cc, "PlaceholderText") else "",
                "text": (cc.Range.Text or "").strip(),
            }
            # helpful flags for dropdown/checkbox
            try:
                item["is_checkbox"] = bool(getattr(cc, "Checked", None) is not None)
            except Exception:
                item["is_checkbox"] = False
            try:
                item["dropdown_entries_count"] = cc.DropdownListEntries.Count if hasattr(cc, "DropdownListEntries") else 0
            except Exception:
                item["dropdown_entries_count"] = 0
            out["content_controls"].append(item)

        # Legacy FormFields
        for i in range(1, doc.FormFields.Count + 1):
            ff = doc.FormFields.Item(i)
            try:
                ftype = ff.Type
            except Exception:
                ftype = None
            entry = {
                "index": i,
                "type_raw": ftype,
                "name": ff.Name if hasattr(ff, "Name") else "",
                "result": getattr(ff, "Result", ""),
            }
            # check for checkbox-type legacy field
            try:
                if ftype == com.constants.wdFieldFormCheckBox:
                    entry["is_legacy_checkbox"] = True
                    entry["checked"] = bool(ff.CheckBox.Value)
                else:
                    entry["is_legacy_checkbox"] = False
            except Exception:
                pass
            out["formfields"].append(entry)

        print(json.dumps(out, indent=2, ensure_ascii=False))
    finally:
        doc.Close(False)
        word.Quit()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python dump_doc_controls.py <file.docx>")
        sys.exit(1)
    dump(sys.argv[1])

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\escape_angle_brackets_fix.py
# ================================
`$lang
#!/usr/bin/env python3
# escape_angle_brackets_fix.py
import zipfile, os, io, shutil
from lxml import etree as ET

# -- EDIT this path to point to your problematic docx --
IN_PATH = r"refernce_template_unlocked.docx"
# Backup and output names (auto)
BACKUP = IN_PATH.replace(".docx", "_bak.docx")
OUT_PATH = IN_PATH.replace(".docx", "_escaped.docx")

NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}

def escape_text_nodes(xml_bytes):
    parser = ET.XMLParser(ns_clean=True, recover=False, encoding='utf-8')
    root = ET.fromstring(xml_bytes, parser=parser)
    changed = False
    for t in root.xpath('.//w:t', namespaces=NS):
        if t.text:
            new = t.text.replace("<", "&lt;").replace(">", "&gt;")
            if new != t.text:
                t.text = new
                changed = True
    return ET.tostring(root, encoding='utf-8', xml_declaration=True), changed

def main():
    if not os.path.exists(IN_PATH):
        print("Input not found:", IN_PATH); return
    shutil.copy2(IN_PATH, BACKUP)
    print("Backup created:", BACKUP)

    with zipfile.ZipFile(IN_PATH, 'r') as zin:
        names = zin.namelist()

        # we'll write to a new zip
        with zipfile.ZipFile(OUT_PATH, 'w', compression=zipfile.ZIP_DEFLATED) as zout:
            made_changes = False
            for name in names:
                data = zin.read(name)
                # Only attempt to parse / change Word XML parts (document, headers, footers, glossary)
                if name in ("word/document.xml",) or name.startswith("word/header") or name.startswith("word/footer") or name.startswith("word/glossary"):
                    try:
                        newdata, changed = escape_text_nodes(data)
                        if changed:
                            made_changes = True
                            zout.writestr(name, newdata)
                        else:
                            zout.writestr(name, data)
                    except Exception as e:
                        # If parse fails, write original and note it
                        print("Warning: could not parse part", name, " — leaving unchanged. Error:", e)
                        zout.writestr(name, data)
                else:
                    zout.writestr(name, data)
    print("Wrote copy at:", OUT_PATH)
    if not made_changes:
        print("No text nodes required escaping (no changes).")
    # quick validation: try to parse document.xml
    try:
        with zipfile.ZipFile(OUT_PATH, 'r') as z2:
            _ = z2.read("word/document.xml")
            ET.fromstring(_, parser=ET.XMLParser(ns_clean=True, recover=False))
        print("Validation: word/document.xml parsed OK.")
    except Exception as e:
        print("Validation: ERROR parsing word/document.xml:", e)
        print("Try opening the file in Word (Open & Repair).")

if __name__ == "__main__":
    main()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\escape_angle_in_text_nodes.py
# ================================
`$lang
# escape_angle_in_text_nodes.py
# Usage:
#   pip install lxml
#   python escape_angle_in_text_nodes.py
#
# This script:
# - makes a backup of DOCX_PATH (if not already present)
# - for each word/*.xml part, finds <w:t>...</w:t> and <w:instrText>...</w:instrText>
#   and replaces any literal '<' or '>' chars inside those text contents with &lt; / &gt;
# - writes a new DOCX with suffix _fixed.docx and validates with lxml.
#
import os, sys, shutil, zipfile, re
from lxml import etree

DOCX_PATH = r"C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited\refernce_template_unlocked_angles_fixed.docx"
# adjust path above to match the file you want to repair

if not os.path.exists(DOCX_PATH):
    print("DOCX not found:", DOCX_PATH); sys.exit(1)

BASE = os.path.splitext(DOCX_PATH)[0]
BACKUP = BASE + "_escape_bak.docx"
OUTPATH = BASE + "_escaped_fixed.docx"

def backup_if_needed():
    if not os.path.exists(BACKUP):
        shutil.copy2(DOCX_PATH, BACKUP)
        print("Backup created:", BACKUP)
    else:
        print("Backup already exists:", BACKUP)

# regex to find <w:t ...> ... </w:t> (non-greedy)
# xml parts are typically one long line, so use DOTALL
T_TAG_RE = re.compile(r'(<w:t\b[^>]*>)(.*?)(</w:t>)', flags=re.DOTALL)
INSTR_RE = re.compile(r'(<w:instrText\b[^>]*>)(.*?)(</w:instrText>)', flags=re.DOTALL)
# fldSimple encloses text as attribute/value or content; handle common <w:fldSimple instr="...">text</w:fldSimple>
FLDS_RE = re.compile(r'(<w:fldSimple\b[^>]*>)(.*?)(</w:fldSimple>)', flags=re.DOTALL)

def escape_text_content(s: str) -> str:
    # escape literal < and > inside the text node
    # (ampersands are left alone - assume they are already &amp; or valid entities)
    # but ensure we don't double-escape existing entities &lt; &gt;
    # safe approach: replace literal < and > characters
    s = s.replace('<', '&lt;')
    s = s.replace('>', '&gt;')
    return s

def process_xml_text(xml_bytes: bytes) -> (bytes, bool):
    """
    Returns (possibly_modified_bytes, changed_flag)
    Operates on decoded utf-8 text. If decoding fails, tries replace errors.
    """
    try:
        txt = xml_bytes.decode('utf-8')
    except Exception:
        txt = xml_bytes.decode('utf-8', errors='replace')

    changed = False

    def repl_t(m):
        nonlocal changed
        head, body, tail = m.group(1), m.group(2), m.group(3)
        # if body contains any literal < or >, escape them
        if '<' in body or '>' in body:
            newbody = escape_text_content(body)
            changed = True
            return head + newbody + tail
        return m.group(0)

    txt2 = T_TAG_RE.sub(repl_t, txt)
    # instrText nodes (fields/field codes)
    def repl_instr(m):
        nonlocal changed
        head, body, tail = m.group(1), m.group(2), m.group(3)
        if '<' in body or '>' in body:
            newbody = escape_text_content(body)
            changed = True
            return head + newbody + tail
        return m.group(0)

    txt2 = INSTR_RE.sub(repl_instr, txt2)

    def repl_fld(m):
        nonlocal changed
        head, body, tail = m.group(1), m.group(2), m.group(3)
        if '<' in body or '>' in body:
            newbody = escape_text_content(body)
            changed = True
            return head + newbody + tail
        return m.group(0)

    txt2 = FLDS_RE.sub(repl_fld, txt2)

    return txt2.encode('utf-8'), changed

def build_fixed_docx(in_path, out_path):
    names = None
    modified_any = []
    with zipfile.ZipFile(in_path, 'r') as zin:
        names = zin.namelist()
        # prepare new zip
        with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as zout:
            for name in names:
                data = zin.read(name)
                if name.startswith('word/') and name.endswith('.xml'):
                    newbytes, changed = process_xml_text(data)
                    if changed:
                        modified_any.append(name)
                        zout.writestr(name, newbytes)
                        print("Escaped angle-brackets in text nodes of:", name)
                    else:
                        zout.writestr(name, data)
                else:
                    # copy other parts unchanged
                    zout.writestr(name, data)
    return modified_any

def validate_docx(path):
    errs = []
    with zipfile.ZipFile(path, 'r') as z:
        for name in z.namelist():
            if name.endswith('.xml'):
                raw = z.read(name)
                try:
                    etree.fromstring(raw)
                except etree.XMLSyntaxError as e:
                    errs.append({
                        "part": name,
                        "error": str(e),
                        "position": getattr(e, 'position', None)
                    })
    return errs

def main():
    backup_if_needed()
    print("Processing and escaping angle brackets inside <w:t> and similar text nodes...")
    modified = build_fixed_docx(DOCX_PATH, OUTPATH)
    if not modified:
        print("No text nodes required escaping (no changes). Wrote copy at:", OUTPATH)
    else:
        print("Wrote fixed candidate to:", OUTPATH)
    print("Validating fixed package...")
    errors = validate_docx(OUTPATH)
    if not errors:
        print("Validation OK. Try opening the file in Word (Open and Repair if prompted):", OUTPATH)
    else:
        print("Validation still finds XML errors. First few errors:")
        for e in errors[:6]:
            print("Part:", e['part'])
            print("Error:", e['error'])
            print("Position:", e['position'])
            print("-" * 60)
        print("If errors persist, paste the first part+error here and I'll analyze further.")

if __name__ == '__main__':
    main()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\find_remaining_chk_tokens.py
# ================================
`$lang
# find_remaining_chk_tokens.py
import sys, zipfile, re
IN = sys.argv[1] if len(sys.argv)>1 else "refernce_template_unlocked_forced_escaped_controls.docx"
tok = "<<CHK>>"
ctx = 60

with zipfile.ZipFile(IN, "r") as z:
    parts = [n for n in z.namelist() if n.startswith("word/")]
    found = []
    for p in parts:
        data = z.read(p).decode("utf-8", errors="replace")
        for m in re.finditer(re.escape(tok), data):
            i = m.start()
            s = data[max(0, i-ctx): i+len(tok)+ctx]
            found.append((p, i, s))
    if not found:
        print("No literal <<CHK>> tokens left inside package.")
    else:
        for p,i,s in found:
            print(f"{p} @ {i}:\n...{s}...\n")
        print("Total occurrences:", len(found))

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\fix_angle_brackets_and_markers.py
# ================================
`$lang
# fix_angle_brackets_and_markers.py
import zipfile, re, os, shutil

# << EDIT THIS >>
DOCX_PATH = r"C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited\refernce_template_unlocked.docx"
# --------------------------------

OUT_PATH = os.path.splitext(DOCX_PATH)[0] + "_angles_fixed.docx"
BACKUP_PATH = os.path.splitext(DOCX_PATH)[0] + "_bak.docx"

def safe_backup(src, bak):
    if not os.path.exists(bak):
        shutil.copy2(src, bak)
        print("Backup created:", bak)
    else:
        print("Backup already exists:", bak)

# pattern to find all <w:t ...>...</w:t> (including tags with attributes)
WT_RE = re.compile(r'(<w:t[^>]*>)(.*?)(</w:t>)', flags=re.DOTALL)

def fix_wt_text(xml_text):
    changed_total = 0

    def repl(m):
        nonlocal changed_total
        open_tag, inner, close_tag = m.group(1), m.group(2), m.group(3)
        orig_inner = inner

        # 1) escape lone '<' and '>' inside text (leave existing entities like &lt; intact)
        # We do this by replacing literal < and > characters
        # (we avoid touching &xxx; sequences)
        # Because inner is text content, any '<' or '>' present are invalid and must be escaped
        inner2 = inner.replace('<', '&lt;').replace('>', '&gt;')

        # 2) optionally replace the marker &lt;&lt;CHK&gt;&gt; (or literal <<CHK>>) with checkbox glyph
        # handle both cases (in case markers were already escaped or not)
        if '&lt;&lt;CHK&gt;&gt;' in inner2:
            inner2 = inner2.replace('&lt;&lt;CHK&gt;&gt;', '\u2610')  # ☐
        if '<<CHK>>' in inner2:
            inner2 = inner2.replace('<<CHK>>', '\u2610')

        if inner2 != orig_inner:
            changed_total += 1
        return open_tag + inner2 + close_tag

    new_xml, n = WT_RE.subn(repl, xml_text)
    return new_xml, changed_total

def process_docx(in_path, out_path):
    with zipfile.ZipFile(in_path, 'r') as zin:
        names = zin.namelist()
        if 'word/document.xml' not in names:
            raise RuntimeError("No word/document.xml in docx")
        fixed_parts = {}
        # process all word/*.xml parts (document + headers/footers/footnotes/endnotes)
        for part in names:
            if part.startswith('word/') and part.endswith('.xml'):
                data = zin.read(part)
                try:
                    txt = data.decode('utf-8')
                except Exception:
                    txt = data.decode('utf-8', errors='replace')
                new_txt, changed = fix_wt_text(txt)
                if changed:
                    fixed_parts[part] = new_txt.encode('utf-8')
                    print(f"Fixed {changed} <w:t> entries in {part}")
            # else: leave as-is

        # write a new zip copying unchanged files, replacing modified parts
        with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as zout:
            for item in names:
                if item in fixed_parts:
                    zout.writestr(item, fixed_parts[item])
                else:
                    zout.writestr(item, zin.read(item))

def main():
    if not os.path.exists(DOCX_PATH):
        print("DOCX not found:", DOCX_PATH); return
    safe_backup(DOCX_PATH, BACKUP_PATH)
    process_docx(DOCX_PATH, OUT_PATH)
    print("Wrote fixed docx to:", OUT_PATH)
    print("Open the fixed file in Word (try Open and Repair if Word warns).")

if __name__ == "__main__":
    main()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\force_escape_text_nodes.py
# ================================
`$lang
#!/usr/bin/env python3
# force_escape_text_nodes.py
# Raw-text-based fixer: escapes literal < and > inside <w:t>...</w:t> sequences
# so the document XML becomes parseable.

import zipfile, os, shutil, re, sys
from lxml import etree as ET

INPUT_DOCX = "refernce_template_unlocked.docx"   # <<--- change if needed
BACKUP = INPUT_DOCX.replace(".docx", "_rawfix_bak.docx")
OUT_DOCX = INPUT_DOCX.replace(".docx", "_forced_escaped.docx")

# Parts we will attempt to fix (main doc + headers/footers + glossary)
TARGET_PARTS = set([
    "word/document.xml",
    "word/footer1.xml", "word/footer2.xml", "word/footer3.xml",
    "word/header1.xml", "word/header2.xml", "word/header3.xml",
    "word/glossary/document.xml", "word/footnotes.xml", "word/endnotes.xml"
])

# regex finds <w:t ...> ... </w:t> with non-greedy match for inner text
RE_W_T = re.compile(r'(<w:t\b[^>]*>)(.*?)(</w:t>)', flags=re.DOTALL | re.IGNORECASE)

def escape_inner_text(m):
    open_tag, inner, close_tag = m.group(1), m.group(2), m.group(3)
    # protect already-escaped sequences
    inner = inner.replace('&lt;', '\0LT_ESC\0').replace('&gt;', '\0GT_ESC\0')
    # replace raw < and > in inner text
    inner = inner.replace('<', '&lt;').replace('>', '&gt;')
    # restore previously escaped placeholders
    inner = inner.replace('\0LT_ESC\0', '&lt;').replace('\0GT_ESC\0', '&gt;')
    return open_tag + inner + close_tag

def process_part_bytes(b):
    try:
        s = b.decode('utf-8')
    except UnicodeDecodeError:
        # try with windows-1252 fallback (sometimes Word uses different encoding declaration)
        s = b.decode('cp1252', errors='replace')
    new_s, n = RE_W_T.subn(escape_inner_text, s)
    return new_s.encode('utf-8'), n

def main():
    if not os.path.exists(INPUT_DOCX):
        print("Input DOCX not found:", INPUT_DOCX); sys.exit(1)

    # Backup original
    shutil.copy2(INPUT_DOCX, BACKUP)
    print("Backup created:", BACKUP)

    changed_any = False
    with zipfile.ZipFile(INPUT_DOCX, 'r') as zin:
        names = zin.namelist()
        with zipfile.ZipFile(OUT_DOCX, 'w', compression=zipfile.ZIP_DEFLATED) as zout:
            for nm in names:
                data = zin.read(nm)
                if nm in TARGET_PARTS or (nm.startswith("word/header") or nm.startswith("word/footer") or nm.startswith("word/")):
                    # We will attempt to process only common Word xml parts (but be conservative)
                    if nm in TARGET_PARTS or nm.startswith("word/"):
                        try:
                            newdata, nrepl = process_part_bytes(data)
                            if nrepl > 0:
                                changed_any = True
                                print(f"Escaped {nrepl} <w:t> inner occurrences in {nm}")
                                zout.writestr(nm, newdata)
                                continue
                        except Exception as e:
                            print(f"Warning: processing {nm} failed with: {e}; writing original")
                # default: copy original
                zout.writestr(nm, data)

    print("Wrote fixed docx to:", OUT_DOCX)
    if not changed_any:
        print("Note: no replacements were made. The file may not contain raw < or > inside w:t nodes.")
    # Quick validation: try to parse document.xml inside out file
    try:
        with zipfile.ZipFile(OUT_DOCX, 'r') as z2:
            content = z2.read("word/document.xml")
            ET.fromstring(content)   # will raise if still broken
        print("Validation: word/document.xml parsed OK.")
    except Exception as e:
        print("Validation: ERROR parsing word/document.xml:", e)
        print("Try opening the output in Word with Open & Repair. If it still fails, paste the first snippet+error here.")
    print("Done.")

if __name__ == '__main__':
    main()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\inspect_docx_tokens.py
# ================================
`$lang
# inspect_docx_tokens.py
# finds occurrences of common checkbox-like tokens in a .docx (searches word/document.xml)
# Usage: python inspect_docx_tokens.py <file.docx>

import sys, zipfile, re, os

TOKENS = [
    "\u2610", "\u2611",            # ☐ ☑
    "<<CHK>>", "<CHK>", "<CHECK>",
    "[ ]", "[x]", "[X]",
    "<CHK/>", "<CHK />", "<<BOX>>"
]
TOKENS_RE = re.compile("|".join(re.escape(t) for t in TOKENS), re.IGNORECASE)

def sample_around(text, pos, radius=80):
    start = max(0, pos - radius)
    end = min(len(text), pos + radius)
    return text[start:end].replace("\n"," ")

def inspect_docx(path):
    if not os.path.exists(path):
        print("Not found:", path); return 1
    with zipfile.ZipFile(path, "r") as z:
        parts = [p for p in z.namelist() if p.startswith("word/")]
        found = []
        for p in parts:
            try:
                raw = z.read(p).decode("utf-8", errors="replace")
            except Exception as e:
                print("Failed reading part",p,":",e); continue
            for m in TOKENS_RE.finditer(raw):
                context = sample_around(raw, m.start())
                found.append((p, m.group(0), m.start(), context[:200]))
        if not found:
            print("No candidate tokens found in word/ parts using the token list.")
            # also try to detect angle-bracket placeholders like <<...>>
            angle_re = re.compile(r"&lt;{0,2}[^&]{1,40}&gt;{0,2}")  # handles already-escaped < >
            ang_found=[]
            for p in parts:
                try:
                    raw = z.read(p).decode("utf-8", errors="replace")
                except:
                    continue
                for m in re.finditer(r"<<[^>]{1,40}>>|<[^>]{1,40}>", raw):
                    ang_found.append((p, m.group(0), m.start(), raw[max(0,m.start()-60):m.start()+60].replace("\n"," ")))
            if ang_found:
                print("\nAngle-bracket-like tokens (raw):")
                for p, token, pos, ctx in ang_found[:200]:
                    print(p, token, "context:", ctx[:180])
                return 0
            print("Also consider symbol font glyphs / legacy fields. See notes in README.")
            return 0
        print("Found candidate tokens (first 200):")
        for p, token, pos, ctx in found[:200]:
            print("PART:", p, "TOKEN:", repr(token), "pos:", pos)
            print("  context:", ctx)
            print("--------------------------------------------------")
    return 0

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python inspect_docx_tokens.py <file.docx>")
        sys.exit(1)
    sys.exit(inspect_docx(sys.argv[1]))

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\inspect_docx_xml.py
# ================================
`$lang
# inspect_docx_xml.py
import zipfile, sys, os

DOCX_PATH = r"C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited\refernce_template_unlocked.docx"
# Use the filename you tried to open — set it above.

# If you have a line & column from the Word error, set here:
ERR_LINE = 2
ERR_COL = 33639

def show_context(xml_bytes, line, col, context_chars=200):
    try:
        xml = xml_bytes.decode("utf-8")
    except UnicodeDecodeError:
        xml = xml_bytes.decode("utf-8", errors="replace")
    # compute offset: sum of lengths up to line-1 + (col-1)
    lines = xml.splitlines(keepends=True)
    if line <= 0 or line > len(lines):
        print("Given line is outside file lines. File has", len(lines), "lines.")
        return
    # compute offset up to beginning of that line
    offset = sum(len(lines[i]) for i in range(line-1))
    offset += max(0, col-1)
    start = max(0, offset - context_chars)
    end = min(len(xml), offset + context_chars)
    snippet = xml[start:end]
    print(f"Showing context around line {line} col {col} (byte offset ~{offset}):")
    print("-" * 80)
    # show with visible markers
    marker_pos = offset - start
    print(snippet)
    print("-" * 80)
    print(" " * marker_pos + "^ <- error position (approx)")
    # also print a slice with non-printables escaped
    print("\nEscaped view:")
    esc = snippet.encode("unicode_escape").decode("ascii")
    print(esc)
    print("-" * 80)

def main():
    if not os.path.exists(DOCX_PATH):
        print("DOCX not found:", DOCX_PATH); return
    with zipfile.ZipFile(DOCX_PATH, "r") as z:
        try:
            data = z.read("word/document.xml")
        except KeyError:
            print("The docx has no word/document.xml inside!")
            return
    show_context(data, ERR_LINE, ERR_COL, context_chars=400)

if __name__ == "__main__":
    main()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\post_extract.json
# ================================
`$lang
[
  {
    "index": 1,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610EPD\t\u2610ECR\t\u2610GEPC",
    "range_preview": "\u2610"
  },
  {
    "index": 2,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610EPD\t\u2610ECR\t\u2610GEPC",
    "range_preview": "\u2610"
  },
  {
    "index": 3,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610EPD\t\u2610ECR\t\u2610GEPC",
    "range_preview": "\u2610"
  },
  {
    "index": 4,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610  <Insert Other>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 5,
    "type": "dropdown",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Level: <Choose a Project Level.>\u0007",
    "range_preview": "<Choose a Project Level.>"
  },
  {
    "index": 6,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "CAPA Associated: <Select one.>",
    "range_preview": "<Select one.>"
  },
  {
    "index": 7,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Design Owner:\t<Choose an item.>\tOther (if applicable): <Fill in if \u201cOther\u201d is chosen.> \tName of OEM (if applicable): <Name of OEM>",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 8,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 9,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 10,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 11,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 12,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 13,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 14,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 15,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Manufacturing Site:\t\u2610AVL \u2610 MAR \u2610 LSB \u2610 OHA \u2610 SNG \u2610 Other\t\u2610OEM \u2610 CM (External)",
    "range_preview": "\u2610"
  },
  {
    "index": 16,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "Design is Copy Exact: <Choose an item.>\u0007",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 17,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 18,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 19,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 20,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 21,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 22,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 23,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 24,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 25,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 26,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 27,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 28,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 29,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 30,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 31,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 32,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 33,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 34,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 35,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 36,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [],
    "heading_path_slug": [],
    "paragraph_context": "\u2610\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 37,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change does not impact the Risk Management File",
    "range_preview": "\u2610"
  },
  {
    "index": 38,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610 The product family does not have a Risk Management File or does not have a Risk Management File aligned to the latest revisions in the QMS.",
    "range_preview": "\u2610"
  },
  {
    "index": 39,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change introduces new usage conditions, or risk of harm as defined in the Risk Management Procedure (Patient, Samples, Operators, Environment, etc.).",
    "range_preview": "\u2610"
  },
  {
    "index": 40,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change affects the current risk probability or severity associated with existing hazards",
    "range_preview": "\u2610"
  },
  {
    "index": 41,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change will mean that the device will have different end users or be used in a different manner",
    "range_preview": "\u2610"
  },
  {
    "index": 42,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The performance evaluation data for the original device is not sufficient to confirm conformity of the changed device with the required characteristics and performance",
    "range_preview": "\u2610"
  },
  {
    "index": 43,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change involves the manufacturing process (i.e., technologies, product lines)",
    "range_preview": "\u2610"
  },
  {
    "index": 44,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change impacts End of Line (EOL) testing procedures (e.g., TP902 \u2013 Test procedure for all Hi Pot and Hypatia Equipment Test Machines)",
    "range_preview": "\u2610"
  },
  {
    "index": 45,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change requires a process validation",
    "range_preview": "\u2610"
  },
  {
    "index": 46,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change affects agreements and/or arrangements (e.g., verification, validation, organizational structure, production site, outsourcing, subcontracting) for ensuring continued compliance with the requirements",
    "range_preview": "\u2610"
  },
  {
    "index": 47,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change results from actions taken related to concerns arising from post-market surveillance including incidents/recalls/complaints (CAPA associated)",
    "range_preview": "\u2610"
  },
  {
    "index": 48,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  The change impacts Quality Control procedures, incoming acceptance criteria, or involves a change in supplier",
    "range_preview": "\u2610"
  },
  {
    "index": 49,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  (Medical) The change results from characteristics not previously considered in the clinical evaluation",
    "range_preview": "\u2610"
  },
  {
    "index": 50,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610  (Medical) The change is driven by the development of the state of the art (e.g., latest technology)",
    "range_preview": "\u2610"
  },
  {
    "index": 51,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 52,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "Next Steps: <Choose the project action item that would need to be completed based on the scope assessment.>",
    "range_preview": "<Choose the project action item that would need to be completed based on the scope assessment.>"
  },
  {
    "index": 53,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "RISK MANAGEMENT FILE"
    ],
    "heading_path_slug": [
      "risk_management_file"
    ],
    "paragraph_context": "\u2610CAPA owner notified\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 54,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610  The change does not impact the performance compliance of the product.",
    "range_preview": "\u2610"
  },
  {
    "index": 55,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect degradable, moving or friction generating components (air filters, fans, hinges, etc.)",
    "range_preview": "\u2610"
  },
  {
    "index": 56,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect the airflow into, throughout, and out of the unit (airflow vent, rearranging components, deck size, etc.)",
    "range_preview": "\u2610"
  },
  {
    "index": 57,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest requirements. Requested to add in scope of the current project.",
    "range_preview": "\u2610"
  },
  {
    "index": 58,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect critical components in compliance files (Electrical, refrigeration, labels)",
    "range_preview": "\u2610"
  },
  {
    "index": 59,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect the product performance, peak variation, temperature stability, door open recovery times",
    "range_preview": "\u2610"
  },
  {
    "index": 60,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes will be made to the product power specifications, refrigeration system, or electrical systems",
    "range_preview": "\u2610"
  },
  {
    "index": 61,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes to the internal cabinet size, construction, or configuration (inner doors, shelving, port holes)",
    "range_preview": "\u2610"
  },
  {
    "index": 62,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Change to defrosts, setpoint ranges, or code versions",
    "range_preview": "\u2610"
  },
  {
    "index": 63,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes to the software affecting behavior or timing of behaviors",
    "range_preview": "\u2610"
  },
  {
    "index": 64,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest requirements. Requested to add in scope of the current project.",
    "range_preview": "\u2610"
  },
  {
    "index": 65,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes affect the cooling capacity to cool down and maintain the temperature of the liquid",
    "range_preview": "\u2610"
  },
  {
    "index": 66,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes affect the functionality of the medium (refrigerant, water, etc.) to chill the system continuously",
    "range_preview": "\u2610"
  },
  {
    "index": 67,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes may affect the power input specifications",
    "range_preview": "\u2610"
  },
  {
    "index": 68,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest requirements. Requested to add in scope of the current project.\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 69,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect critical components in compliance files",
    "range_preview": "\u2610"
  },
  {
    "index": 70,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest requirements. Requested to add in scope of the current project.\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 71,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes affect critical components in compliance files",
    "range_preview": "\u2610"
  },
  {
    "index": 72,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes to the materials of construction or coatings (paint)",
    "range_preview": "\u2610"
  },
  {
    "index": 73,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes impact air flow (blowers, power supp, filters, paper catch areas, filter screen)",
    "range_preview": "\u2610"
  },
  {
    "index": 74,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes to the software",
    "range_preview": "\u2610"
  },
  {
    "index": 75,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes impacting stability (change weight distribution or change to stands)",
    "range_preview": "\u2610"
  },
  {
    "index": 76,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Changes impact cleanability (Sealing of openings that could harbor contamination, fasteners - Philip screws not allowed)",
    "range_preview": "\u2610"
  },
  {
    "index": 77,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes impact the cabinet pressure decay test (seals, cabinet materials)",
    "range_preview": "\u2610"
  },
  {
    "index": 78,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Changes impact labels or markings (add, remove, location change)",
    "range_preview": "\u2610"
  },
  {
    "index": 79,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest requirements. Requested to add in scope of the current project.\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 80,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610ENERGY STAR*",
    "range_preview": "\u2610"
  },
  {
    "index": 81,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610NSF49 BSC*",
    "range_preview": "\u2610"
  },
  {
    "index": 82,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610NSF456 Vaccine*\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 83,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Clean Room Particulate 14644-14*\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 84,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Clean Room Particulate 14644-14*",
    "range_preview": "\u2610"
  },
  {
    "index": 85,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610ErP Directive (Chillers only)\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 86,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Clean Room Particulate 14644-14*",
    "range_preview": "\u2610"
  },
  {
    "index": 87,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610South Korean Act on Environmental testing and Inspection\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 88,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other (if applicable): <Select \u201cOther\u201d if the report is not listed above. Provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 89,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610ENERGY STAR*\t\u2610CE (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 90,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610ENERGY STAR*\t\u2610CE (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 91,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610ENERGY STAR*\t\u2610CE (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 92,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Marketing claims\t\u2610CE DoC (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 93,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Marketing claims\t\u2610CE DoC (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 94,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Marketing claims\t\u2610CE DoC (Self-Declared)\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 95,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "Testing Required: <Choose an item.>",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 96,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Agency Report Revision\t\u2610Revise Engineering Drawings/Documents\t\u2610Revise Regulatory Documents (Cloud Drive)",
    "range_preview": "\u2610"
  },
  {
    "index": 97,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Agency Report Revision\t\u2610Revise Engineering Drawings/Documents\t\u2610Revise Regulatory Documents (Cloud Drive)",
    "range_preview": "\u2610"
  },
  {
    "index": 98,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Agency Report Revision\t\u2610Revise Engineering Drawings/Documents\t\u2610Revise Regulatory Documents (Cloud Drive)",
    "range_preview": "\u2610"
  },
  {
    "index": 99,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Marketing claims are validated\t\u2610 Marketing claims have not been validation",
    "range_preview": "\u2610"
  },
  {
    "index": 100,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Marketing claims are validated\t\u2610 Marketing claims have not been validation",
    "range_preview": "\u2610"
  },
  {
    "index": 101,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610 Change impacts product, scope is defined as requiring a new project.",
    "range_preview": "\u2610"
  },
  {
    "index": 102,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 103,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610CB of changes (ENERGY STAR, required if not testing)\t\u2610Energy Star Team Leads (ENERGY STAR)",
    "range_preview": "\u2610"
  },
  {
    "index": 104,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610CB of changes (ENERGY STAR, required if not testing)\t\u2610Energy Star Team Leads (ENERGY STAR)",
    "range_preview": "\u2610"
  },
  {
    "index": 105,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610RA at Implementation Manufacturing Location\t\u2610South Korean RA Team for in-country Testing",
    "range_preview": "\u2610"
  },
  {
    "index": 106,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610RA at Implementation Manufacturing Location\t\u2610South Korean RA Team for in-country Testing",
    "range_preview": "\u2610"
  },
  {
    "index": 107,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Authorities of Product Changes where registered\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 108,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "PERFORMANCE COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "performance_compliance_assessment"
    ],
    "paragraph_context": "\u2610Authorities of Product Changes where registered\t\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 109,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610  The change does not impact the design safety, EMC, and/or wireless compliance. Like for like components (i.e., PCBA components) should still be evaluated to ensure the safety report has not been impacted.",
    "range_preview": "\u2610"
  },
  {
    "index": 110,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Does the change affect specs, listings, warnings, or text on critical components in compliance files?",
    "range_preview": "\u2610"
  },
  {
    "index": 111,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Are the specs/ratings of the end product going to be changed? (power = re-evaluate markets)",
    "range_preview": "\u2610"
  },
  {
    "index": 112,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Are the specs/ratings of the product\u2019s environment going to be changed? (Env. conditions, spacings, etc.)",
    "range_preview": "\u2610"
  },
  {
    "index": 113,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Are the product features / use being impacted?",
    "range_preview": "\u2610"
  },
  {
    "index": 114,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Are materials going to be changed (Keeping the same part number or not)?",
    "range_preview": "\u2610"
  },
  {
    "index": 115,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Are labels, IFU, or customer facing information going to be changed?",
    "range_preview": "\u2610"
  },
  {
    "index": 116,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Will the manufacturing location or applicant of the file need to change?",
    "range_preview": "\u2610"
  },
  {
    "index": 117,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610 (Supplier change) Does the change impact split inspection locations and files? (Common for PCBA or enclosed subassemblies)",
    "range_preview": "\u2610"
  },
  {
    "index": 118,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Product currently has outdated testing or missing testing to the latest accepted requirements. Requested to add in scope of the current project.",
    "range_preview": "\u2610"
  },
  {
    "index": 119,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other (if applicable): <If \u201cOther\u201d is selected, provide more information here.> \u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 120,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610NRTL Listing, Report # <Insert Report Number>\t\u2610EMC (EN report), Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 121,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610NRTL Listing, Report # <Insert Report Number>\t\u2610EMC (EN report), Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 122,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CB Safety, Report # <Insert Report Number>\t\u2610FCC, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 123,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CB Safety, Report # <Insert Report Number>\t\u2610FCC, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 124,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Informative Safety, Report # <Insert Report Number>\t\u2610ICES, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 125,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Informative Safety, Report # <Insert Report Number>\t\u2610ICES, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 126,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Wireless, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 127,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>, Report # <Insert Report Number>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 128,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610UL\t\u2610CSA",
    "range_preview": "\u2610"
  },
  {
    "index": 129,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610UL\t\u2610CSA",
    "range_preview": "\u2610"
  },
  {
    "index": 130,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610ETL\t\u2610TUV",
    "range_preview": "\u2610"
  },
  {
    "index": 131,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610ETL\t\u2610TUV",
    "range_preview": "\u2610"
  },
  {
    "index": 132,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610FCC / ICES\t\u2610NSF",
    "range_preview": "\u2610"
  },
  {
    "index": 133,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610FCC / ICES\t\u2610NSF",
    "range_preview": "\u2610"
  },
  {
    "index": 134,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610IRAM-S",
    "range_preview": "\u2610"
  },
  {
    "index": 135,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610INMETRO",
    "range_preview": "\u2610"
  },
  {
    "index": 136,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610ANATEL",
    "range_preview": "\u2610"
  },
  {
    "index": 137,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610 S Mark\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 138,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CE DoC (Self-Declared)",
    "range_preview": "\u2610"
  },
  {
    "index": 139,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CE DoC (EU NB)",
    "range_preview": "\u2610"
  },
  {
    "index": 140,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610UKCA\t\u2610LNE",
    "range_preview": "\u2610"
  },
  {
    "index": 141,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610UKCA\t\u2610LNE",
    "range_preview": "\u2610"
  },
  {
    "index": 142,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610GS\t\u2610WEEE\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 143,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610GS\t\u2610WEEE\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 144,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610KC Mark",
    "range_preview": "\u2610"
  },
  {
    "index": 145,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610 EAC\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 146,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the mark/label is not listed above. Provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 147,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610FCC Declaration\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 148,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CE DoC (Self-Declared)",
    "range_preview": "\u2610"
  },
  {
    "index": 149,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610CE DoC (EU NB)",
    "range_preview": "\u2610"
  },
  {
    "index": 150,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610UKCA Declaration\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 151,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the document is not listed above. Provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 152,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "Testing Required: <Choose an item.>",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 153,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "Impacted Documents:\u000b\t\u2610No Update Required (justification within plan required)\t\u2610Paperwork update only",
    "range_preview": "\u2610"
  },
  {
    "index": 154,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "Impacted Documents:\u000b\t\u2610No Update Required (justification within plan required)\t\u2610Paperwork update only",
    "range_preview": "\u2610"
  },
  {
    "index": 155,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Registration with Agency required (FCC, etc.)\t\u2610Revise Engineering Drawings/Documents (i.e., labels)",
    "range_preview": "\u2610"
  },
  {
    "index": 156,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Registration with Agency required (FCC, etc.)\t\u2610Revise Engineering Drawings/Documents (i.e., labels)",
    "range_preview": "\u2610"
  },
  {
    "index": 157,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Revise Regulatory Documents (i.e., declarations)\t\u2610Re-evaluate market requirements due to changes.",
    "range_preview": "\u2610"
  },
  {
    "index": 158,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Revise Regulatory Documents (i.e., declarations)\t\u2610Re-evaluate market requirements due to changes.",
    "range_preview": "\u2610"
  },
  {
    "index": 159,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Re-evaluate product requirements due to changes.\t\u2610Re-evaluate process requirements due to changes.",
    "range_preview": "\u2610"
  },
  {
    "index": 160,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Re-evaluate product requirements due to changes.\t\u2610Re-evaluate process requirements due to changes.",
    "range_preview": "\u2610"
  },
  {
    "index": 161,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 162,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Regional Leads if registered (i.e., Saudi SASO, KC Mark, Australian RCM)\t\u2610RA at Implementation Manufacturing Location",
    "range_preview": "\u2610"
  },
  {
    "index": 163,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Regional Leads if registered (i.e., Saudi SASO, KC Mark, Australian RCM)\t\u2610RA at Implementation Manufacturing Location",
    "range_preview": "\u2610"
  },
  {
    "index": 164,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Authorities of Product Changes where registered\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 165,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "DESIGN SAFETY, EMC, & WIRELESS COMPLIANCE ASSESSMENT"
    ],
    "heading_path_slug": [
      "design_safety_emc_wireless_compliance_assessment"
    ],
    "paragraph_context": "\u2610Authorities of Product Changes where registered\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 166,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610  The change does not impact the end product environmental compliance. (i.e., change is associated with documentation updates)",
    "range_preview": "\u2610"
  },
  {
    "index": 167,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Change adds new or removes any components from the product (BOM update)",
    "range_preview": "\u2610"
  },
  {
    "index": 168,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610The supplier of a part number is changing",
    "range_preview": "\u2610"
  },
  {
    "index": 169,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610The manufacturing or internal part number is changing",
    "range_preview": "\u2610"
  },
  {
    "index": 170,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610End product impacted currently has an outdated BOM in Greensoft or BOM is not uploaded into GreenSoft. Requested to add in scope of the current project.",
    "range_preview": "\u2610"
  },
  {
    "index": 171,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 172,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610GreenSoft Item Submission\t\u2610GreenSoft BOM Upload Form\t\u2610GreenSoft Customer Collected Documents Form",
    "range_preview": "\u2610"
  },
  {
    "index": 173,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610GreenSoft Item Submission\t\u2610GreenSoft BOM Upload Form\t\u2610GreenSoft Customer Collected Documents Form",
    "range_preview": "\u2610"
  },
  {
    "index": 174,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610GreenSoft Item Submission\t\u2610GreenSoft BOM Upload Form\t\u2610GreenSoft Customer Collected Documents Form",
    "range_preview": "\u2610"
  },
  {
    "index": 175,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 176,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Prop65",
    "range_preview": "\u2610"
  },
  {
    "index": 177,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610FIFRA Pesticide (UV Lamp)\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 178,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610WEEE\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 179,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610WEEE\t\u2610F-Gas",
    "range_preview": "\u2610"
  },
  {
    "index": 180,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610WEEE\t\u2610F-Gas",
    "range_preview": "\u2610"
  },
  {
    "index": 181,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610PFAS\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 182,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610WEEE",
    "range_preview": "\u2610"
  },
  {
    "index": 183,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610China RoHS (C-RoHS)\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 184,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the mark/label is not listed above. Provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 185,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Prop65 Declaration",
    "range_preview": "\u2610"
  },
  {
    "index": 186,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610FIFRA Pesticide Product Reporting (UV Lamp)\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 187,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Montreal Protocol Declaration\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 188,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610REACH Declaration",
    "range_preview": "\u2610"
  },
  {
    "index": 189,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610RoHS Declaration",
    "range_preview": "\u2610"
  },
  {
    "index": 190,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610F-Gas Declaration",
    "range_preview": "\u2610"
  },
  {
    "index": 191,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610CE Declaration (Self-Declared)\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 192,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610C-RoHS \u201cTic-Tac Table\u201d Declaration\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 193,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the document is not listed above. Provide more information here, ex. Coneg, PFAS.>",
    "range_preview": "\u2610"
  },
  {
    "index": 194,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "Testing Required: <Choose an item.>",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 195,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610No Update Required\t\u2610Upload GreenSoft Form(s)\t\u2610Revise Engineering Drawings/Documents (labels)",
    "range_preview": "\u2610"
  },
  {
    "index": 196,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610No Update Required\t\u2610Upload GreenSoft Form(s)\t\u2610Revise Engineering Drawings/Documents (labels)",
    "range_preview": "\u2610"
  },
  {
    "index": 197,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610No Update Required\t\u2610Upload GreenSoft Form(s)\t\u2610Revise Engineering Drawings/Documents (labels)",
    "range_preview": "\u2610"
  },
  {
    "index": 198,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Revise Regulatory Documents (i.e., declarations)",
    "range_preview": "\u2610"
  },
  {
    "index": 199,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Change impacts product, scope is defined as requiring a new project.",
    "range_preview": "\u2610"
  },
  {
    "index": 200,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 201,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610EPA Lead if registered (FIFRA)\t\u2610GreenSoft User to load GreenSoft BOM changes (i.e., component or supplier change \u2013 site: GS Submission)",
    "range_preview": "\u2610"
  },
  {
    "index": 202,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610EPA Lead if registered (FIFRA)\t\u2610GreenSoft User to load GreenSoft BOM changes (i.e., component or supplier change \u2013 site: GS Submission)",
    "range_preview": "\u2610"
  },
  {
    "index": 203,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "ENVIRONMENTAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "environmental_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 204,
    "type": "checkbox",
    "tag": "",
    "title": "",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "PART A SAFETY, COMPATIBILITY, EFFECTIVENESS\u0007",
    "range_preview": "P"
  },
  {
    "index": 205,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Will the change affect the safety, compatibility, or effectiveness of the device?",
    "range_preview": "\u2610"
  },
  {
    "index": 206,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Will the technology, engineering design, or performance of the device or packaging change?",
    "range_preview": "\u2610"
  },
  {
    "index": 207,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is the change introducing a new material, or alternate component, or is it a supplier change?\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 208,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change include or impact the product\u2019s Intended use?",
    "range_preview": "\u2610"
  },
  {
    "index": 209,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change introduce new risks of harm to humans, property, or the environment?",
    "range_preview": "\u2610"
  },
  {
    "index": 210,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Will the change affect the standards this product relies upon?",
    "range_preview": "\u2610"
  },
  {
    "index": 211,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is there another registration classification that this product will align to? <Provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 212,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Will the change affect product, packaging, electronic literature, or labelling?\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 213,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IFU/User Manual\t\u2610Service Manual\t\u2610Translation(s)\t\u2610Technical Data Sheets",
    "range_preview": "\u2610"
  },
  {
    "index": 214,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IFU/User Manual\t\u2610Service Manual\t\u2610Translation(s)\t\u2610Technical Data Sheets",
    "range_preview": "\u2610"
  },
  {
    "index": 215,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IFU/User Manual\t\u2610Service Manual\t\u2610Translation(s)\t\u2610Technical Data Sheets",
    "range_preview": "\u2610"
  },
  {
    "index": 216,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IFU/User Manual\t\u2610Service Manual\t\u2610Translation(s)\t\u2610Technical Data Sheets",
    "range_preview": "\u2610"
  },
  {
    "index": 217,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610ESI/Quick Start Guide\t\u2610Marketing Material\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 218,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610ESI/Quick Start Guide\t\u2610Marketing Material\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 219,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610ESI/Quick Start Guide\t\u2610Marketing Material\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 220,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in label material\t\u2610Marking(s)\t\u2610Indication of Use\t\u2610e-IFU section",
    "range_preview": "\u2610"
  },
  {
    "index": 221,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in label material\t\u2610Marking(s)\t\u2610Indication of Use\t\u2610e-IFU section",
    "range_preview": "\u2610"
  },
  {
    "index": 222,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in label material\t\u2610Marking(s)\t\u2610Indication of Use\t\u2610e-IFU section",
    "range_preview": "\u2610"
  },
  {
    "index": 223,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in label material\t\u2610Marking(s)\t\u2610Indication of Use\t\u2610e-IFU section",
    "range_preview": "\u2610"
  },
  {
    "index": 224,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 225,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Intended Use\t\u2610Translation(s)\t\u2610Change in specs/ratings\t\u2610Change in the warnings/precautions",
    "range_preview": "\u2610"
  },
  {
    "index": 226,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Intended Use\t\u2610Translation(s)\t\u2610Change in specs/ratings\t\u2610Change in the warnings/precautions",
    "range_preview": "\u2610"
  },
  {
    "index": 227,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Intended Use\t\u2610Translation(s)\t\u2610Change in specs/ratings\t\u2610Change in the warnings/precautions",
    "range_preview": "\u2610"
  },
  {
    "index": 228,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Intended Use\t\u2610Translation(s)\t\u2610Change in specs/ratings\t\u2610Change in the warnings/precautions",
    "range_preview": "\u2610"
  },
  {
    "index": 229,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 230,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 Will the technology, engineering design, performance of the device, or packaging change?\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 231,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in control mechanism, operating principle or energy type?",
    "range_preview": "\u2610"
  },
  {
    "index": 232,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change impact the Product Requirements?",
    "range_preview": "\u2610"
  },
  {
    "index": 233,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change impact a component that is subjected to sterilization, cleaning, or disinfection?",
    "range_preview": "\u2610"
  },
  {
    "index": 234,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change to the part require that sterilization validation, cleaning validation, or disinfection validation should be repeated?",
    "range_preview": "\u2610"
  },
  {
    "index": 235,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change affect the performance or accuracy of the device?",
    "range_preview": "\u2610"
  },
  {
    "index": 236,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change involve a component, software/firmware item or other part responsible for the product achieving its intended use?",
    "range_preview": "\u2610"
  },
  {
    "index": 237,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change in packaging design?",
    "range_preview": "\u2610"
  },
  {
    "index": 238,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Change uses the same technology and classification as described in a previously cleared 510(k) or 510(k) exempt version?",
    "range_preview": "\u2610"
  },
  {
    "index": 239,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change impact safety critical (i.e., 61010, EMC), critical to quality, critical to performance components? (See ENG016, CTT Business Unit Engineering Change Control Process procedure for definitions.)",
    "range_preview": "\u2610"
  },
  {
    "index": 240,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change affect the intended use of the device?",
    "range_preview": "\u2610"
  },
  {
    "index": 241,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Risk-based assessment of the changed device identify any new risks or significantly modified existing risks?",
    "range_preview": "\u2610"
  },
  {
    "index": 242,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is clinical data necessary to evaluate the safety or effectiveness for purposes of design validation?\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 243,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is the change introducing a new material, alternate component, or is it a supplier change?\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 244,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is this a change in material type, material formulation, chemical composition, or the material\u2019s processing?",
    "range_preview": "\u2610"
  },
  {
    "index": 245,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Will the changed material directly or indirectly contact body tissues or fluids (Including operators and service)?",
    "range_preview": "\u2610"
  },
  {
    "index": 246,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does a risk assessment identify any new or increased biocompatibility concerns?",
    "range_preview": "\u2610"
  },
  {
    "index": 247,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Has the manufacturer used the same material in a similar legally marketed device?",
    "range_preview": "\u2610"
  },
  {
    "index": 248,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Could the change affect the device\u2019s performance specifications?",
    "range_preview": "\u2610"
  },
  {
    "index": 249,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the supplier change impact split inspection locations and files? (Common for PCBA or enclosed subassemblies)",
    "range_preview": "\u2610"
  },
  {
    "index": 250,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the supplier change affect critical components in compliance files?\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 251,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is there a change to product software or firmware?\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 252,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the SW Change impact the SW documentation? (as applicable SW QAPs/SOPs for AVL / MAR sites)",
    "range_preview": "\u2610"
  },
  {
    "index": 253,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the SW Change include a security patch related to a known vulnerability?",
    "range_preview": "\u2610"
  },
  {
    "index": 254,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Is the SW Change made solely to return the system into specification of the most recently cleared device?",
    "range_preview": "\u2610"
  },
  {
    "index": 255,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the SW change introduce a new risk or modify an existing risk?",
    "range_preview": "\u2610"
  },
  {
    "index": 256,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Does the change create or necessitate a new risk control measure or a modification of an existing risk control measure for a hazardous situation that could result in significant harm?",
    "range_preview": "\u2610"
  },
  {
    "index": 257,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Could the change impact functionality or performance specifications that are directly associated with the intended use or safety the device?",
    "range_preview": "\u2610"
  },
  {
    "index": 258,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Are there additional software factors that may affect the decision to file? (e.g., Infrastructure, Architecture, Core algorithm, Re-engineering and refactoring etc.)",
    "range_preview": "\u2610"
  },
  {
    "index": 259,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610USA: FDA 510(K) Exempt",
    "range_preview": "\u2610"
  },
  {
    "index": 260,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610USA: FDA 510(K)",
    "range_preview": "\u2610"
  },
  {
    "index": 261,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Canada: MDSAP",
    "range_preview": "\u2610"
  },
  {
    "index": 262,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Mexico: COFEPRIS\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 263,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Argentina: ANMAT",
    "range_preview": "\u2610"
  },
  {
    "index": 264,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Brazil: ANVISA",
    "range_preview": "\u2610"
  },
  {
    "index": 265,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Brazil: INMETRO",
    "range_preview": "\u2610"
  },
  {
    "index": 266,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Columbia: INVIMA",
    "range_preview": "\u2610"
  },
  {
    "index": 267,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Costa Rica: MoH",
    "range_preview": "\u2610"
  },
  {
    "index": 268,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Ecuador: ARCSA",
    "range_preview": "\u2610"
  },
  {
    "index": 269,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610El Salvador: DNM",
    "range_preview": "\u2610"
  },
  {
    "index": 270,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Guatemala: MSPAS",
    "range_preview": "\u2610"
  },
  {
    "index": 271,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Nicaragua: MINSA",
    "range_preview": "\u2610"
  },
  {
    "index": 272,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Panama: MINSA / MoH",
    "range_preview": "\u2610"
  },
  {
    "index": 273,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Peru: MINSA\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 274,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610EU: CE (NB)",
    "range_preview": "\u2610"
  },
  {
    "index": 275,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UK: MHRA",
    "range_preview": "\u2610"
  },
  {
    "index": 276,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UK: UKCA (NB)",
    "range_preview": "\u2610"
  },
  {
    "index": 277,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UK: UKCA",
    "range_preview": "\u2610"
  },
  {
    "index": 278,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Iceland: IMA",
    "range_preview": "\u2610"
  },
  {
    "index": 279,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Israel: MoH",
    "range_preview": "\u2610"
  },
  {
    "index": 280,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Egypt: EDA",
    "range_preview": "\u2610"
  },
  {
    "index": 281,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Saudi Arabia: SFDA",
    "range_preview": "\u2610"
  },
  {
    "index": 282,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Turkey: TITCK",
    "range_preview": "\u2610"
  },
  {
    "index": 283,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Norway: NoMA",
    "range_preview": "\u2610"
  },
  {
    "index": 284,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Serbia: ALIMS",
    "range_preview": "\u2610"
  },
  {
    "index": 285,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Ukraine: SMDC",
    "range_preview": "\u2610"
  },
  {
    "index": 286,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Morocco: DMP\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 287,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610China: NMPA",
    "range_preview": "\u2610"
  },
  {
    "index": 288,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Malaysia: MDA",
    "range_preview": "\u2610"
  },
  {
    "index": 289,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610South Korea: MFDS",
    "range_preview": "\u2610"
  },
  {
    "index": 290,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Taiwan: TFDA",
    "range_preview": "\u2610"
  },
  {
    "index": 291,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610India: CDSCO",
    "range_preview": "\u2610"
  },
  {
    "index": 292,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Singapore: HSA",
    "range_preview": "\u2610"
  },
  {
    "index": 293,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Japan: PMDA",
    "range_preview": "\u2610"
  },
  {
    "index": 294,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Australia: TGA",
    "range_preview": "\u2610"
  },
  {
    "index": 295,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Hong Kong: MCO",
    "range_preview": "\u2610"
  },
  {
    "index": 296,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Indonesia: MoH",
    "range_preview": "\u2610"
  },
  {
    "index": 297,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610New Zealand: MEDSAFE\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 298,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the approval/registration is not listed above. Provide more information here.>",
    "range_preview": "\u2610"
  },
  {
    "index": 299,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610IEC 60601 Report(s), Report # <Insert Report Number>\t\u2610ILAC/IAAC Report, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 300,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610IEC 60601 Report(s), Report # <Insert Report Number>\t\u2610ILAC/IAAC Report, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 301,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IEC 61010 Report(s), Report # <Insert Report Number>\t\u2610CB Scheme Report, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 302,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610 IEC 61010 Report(s), Report # <Insert Report Number>\t\u2610CB Scheme Report, Report # <Insert Report Number>",
    "range_preview": "\u2610"
  },
  {
    "index": 303,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Other: <Select \u201cOther\u201d if the report is not listed above. Provide more information here>, Report # <Insert Report Number>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 304,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UDI\t\u2610CE (EU NB)\t \u2610  Packaging/Shipping Labels\t\u2610  Product Label",
    "range_preview": "\u2610"
  },
  {
    "index": 305,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UDI\t\u2610CE (EU NB)\t \u2610  Packaging/Shipping Labels\t\u2610  Product Label",
    "range_preview": "\u2610"
  },
  {
    "index": 306,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UDI\t\u2610CE (EU NB)\t \u2610  Packaging/Shipping Labels\t\u2610  Product Label",
    "range_preview": "\u2610"
  },
  {
    "index": 307,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610UDI\t\u2610CE (EU NB)\t \u2610  Packaging/Shipping Labels\t\u2610  Product Label",
    "range_preview": "\u2610"
  },
  {
    "index": 308,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610  Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 309,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "Testing Required: <Choose an item.>",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 310,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "Registration Impact: <Choose an item.>",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 311,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Verify Intended Use consistency\t\u2610Verify changes documented in TF / DHF\t\u2610Verify changes are documented in DMR",
    "range_preview": "\u2610"
  },
  {
    "index": 312,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Verify Intended Use consistency\t\u2610Verify changes documented in TF / DHF\t\u2610Verify changes are documented in DMR",
    "range_preview": "\u2610"
  },
  {
    "index": 313,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Verify Intended Use consistency\t\u2610Verify changes documented in TF / DHF\t\u2610Verify changes are documented in DMR",
    "range_preview": "\u2610"
  },
  {
    "index": 314,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Submit to EU NB\t\u2610Submit and Update TF / DHF\t\u2610Verify 510k for change impact",
    "range_preview": "\u2610"
  },
  {
    "index": 315,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Submit to EU NB\t\u2610Submit and Update TF / DHF\t\u2610Verify 510k for change impact",
    "range_preview": "\u2610"
  },
  {
    "index": 316,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Submit to EU NB\t\u2610Submit and Update TF / DHF\t\u2610Verify 510k for change impact",
    "range_preview": "\u2610"
  },
  {
    "index": 317,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 318,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Regional RA Lead(s)\t\u2610FDA Correspondent(s)\t\u2610EU PRR(s)\t\u2610Notify RA at Implementation Manufacturing Location",
    "range_preview": "\u2610"
  },
  {
    "index": 319,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Regional RA Lead(s)\t\u2610FDA Correspondent(s)\t\u2610EU PRR(s)\t\u2610Notify RA at Implementation Manufacturing Location",
    "range_preview": "\u2610"
  },
  {
    "index": 320,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Regional RA Lead(s)\t\u2610FDA Correspondent(s)\t\u2610EU PRR(s)\t\u2610Notify RA at Implementation Manufacturing Location",
    "range_preview": "\u2610"
  },
  {
    "index": 321,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Regional RA Lead(s)\t\u2610FDA Correspondent(s)\t\u2610EU PRR(s)\t\u2610Notify RA at Implementation Manufacturing Location",
    "range_preview": "\u2610"
  },
  {
    "index": 322,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Notify Authorities of Product Changes where registered\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 323,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Notify Authorities of Product Changes where registered\t\u2610Other: <If \u201cOther\u201d is selected, provide more information here.>\u0007",
    "range_preview": "\u2610"
  },
  {
    "index": 324,
    "type": "date",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "<Click or tap to enter a date.>\u0007",
    "range_preview": "<Click or tap to enter a date.>"
  },
  {
    "index": 325,
    "type": "date",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "<Click or tap to enter a date.>\u0007",
    "range_preview": "<Click or tap to enter a date.>"
  },
  {
    "index": 326,
    "type": "combobox",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "(Medical Only) Did any Design verification and/or validation activities produce any unexpected issues of safety or effectiveness? <Choose an item.>",
    "range_preview": "<Choose an item.>"
  },
  {
    "index": 327,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610All affected reports were verified for change accuracy (CCL, models covered, content, etc.) and all documentation is stored in the Technical File (TF) of the product.",
    "range_preview": "\u2610"
  },
  {
    "index": 328,
    "type": "checkbox",
    "tag": "chk",
    "title": "chk",
    "checked": false,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "\u2610Not a Medical Device",
    "range_preview": "\u2610"
  },
  {
    "index": 329,
    "type": "date",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "<Click or tap to enter a date.>\u0007",
    "range_preview": "<Click or tap to enter a date.>"
  },
  {
    "index": 330,
    "type": "date",
    "tag": "",
    "title": "",
    "checked": null,
    "heading_path": [
      "MEDICAL ASSESSMENT"
    ],
    "heading_path_slug": [
      "medical_assessment"
    ],
    "paragraph_context": "<Click or tap to enter a date.>\u0007",
    "range_preview": "<Click or tap to enter a date.>"
  }
]
`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\select_content_control.py
# ================================
`$lang
# select_content_control.py
import sys
import win32com.client
from pathlib import Path

def main():
    if len(sys.argv) < 3:
        print("Usage: python select_content_control.py <docx_path> <index_1_based>")
        return

    doc_path = Path(sys.argv[1]).expanduser().resolve()
    idx = int(sys.argv[2])

    word = win32com.client.Dispatch("Word.Application")
    word.Visible = True   # show Word so you can see selection

    # Open without updating links, read-only False
    doc = word.Documents.Open(str(doc_path), ReadOnly=False)

    try:
        cc_count = doc.ContentControls.Count
        print(f"Opened: {doc_path}")
        print(f"Total content controls: {cc_count}")

        if idx < 1 or idx > cc_count:
            print(f"Index out of range (1..{cc_count})")
            return

        # Word collections are 1-based
        cc = doc.ContentControls(idx)
        cc.Range.Select()

        # Try to highlight (visual aid). If not supported, ignore.
        try:
            cc.Range.HighlightColorIndex = 7  # wdYellow
        except Exception:
            pass

        # Print some info
        print(f"\nSelected content control #{idx}")
        print(" Type (int):", getattr(cc, "Type", "N/A"))
        print(" Tag:", repr(getattr(cc, "Tag", "")))
        print(" Title:", repr(getattr(cc, "Title", "")))
        txt = cc.Range.Text.replace("\r", "\\r").replace("\n", "\\n")
        print(" Range preview:", txt[:300])
        if getattr(cc, "Type", None) == 8:  # checkbox
            try:
                cb = cc.CheckBox
                print(" Checkbox.CheckedSymbol:", getattr(cb, "CheckedSymbol", None))
                print(" Checkbox.UncheckedSymbol:", getattr(cb, "UncheckedSymbol", None))
            except Exception:
                print(" Checkbox properties not accessible")
            try:
                print(" Current Checked value:", bool(getattr(cc, "Checked")))
            except Exception:
                print(" Current Checked value: (not available)")

        print("\nWord should have scrolled to and selected the control. Inspect it, then close Word when done.")
    finally:
        # leave Word open for user inspection (do not doc.Close())
        pass

if __name__ == "__main__":
    main()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\set_checkboxes_from_json_2.py
# ================================
`$lang
# set_checkboxes_from_json.py
"""
Usage:
  python set_checkboxes_from_json.py <input.docx> <mapping.json> [--replace-with-x]

<input.docx>   : path to the tagged docx (e.g. refernce_template_unlocked_forced_escaped_controls_tagged.docx)
<mapping.json> : JSON file mapping control tag/title -> boolean, example:
                 { "pact_assessmentepdecrgepcchk_insert_othernumber_insert__asso": true,
                   "vemarketing_claims_are_validatedchk_marketing_claims_have_not_be": false }
--replace-with-x : optional flag; when setting a content-control's Checked property fails,
                   the script will replace the control with the glyph "X" (visible) instead
                   of leaving the original token.

Output:
  <input>_filled.docx (saved next to input)
"""

import sys, os, json, re
try:
    import win32com.client as com
except Exception as e:
    print("Requires pywin32 (win32com). Run in Windows with pywin32 installed.")
    raise

def load_json(p):
    with open(p, "r", encoding="utf-8") as fh:
        return json.load(fh)

def sanitize_key(k):
    return (k or "").strip()

def main():
    if len(sys.argv) < 3:
        print("Usage: python set_checkboxes_from_json.py <input.docx> <mapping.json> [--replace-with-x]")
        return
    IN = sys.argv[1]
    MAPF = sys.argv[2]
    replace_with_x = "--replace-with-x" in sys.argv[3:]

    if not os.path.exists(IN):
        print("Input file not found:", IN); return
    if not os.path.exists(MAPF):
        print("Mapping JSON not found:", MAPF); return

    mapping = load_json(MAPF)
    # normalize mapping keys
    mapping_norm = {sanitize_key(k): bool(v) for k, v in mapping.items()}

    word = com.Dispatch("Word.Application")
    word.Visible = False
    # Open read/write
    doc = word.Documents.Open(os.path.abspath(IN))
    try:
        total = doc.ContentControls.Count
        changed = 0
        notfound = 0
        replaced_text_count = 0

        for i in range(1, total + 1):
            try:
                cc = doc.ContentControls.Item(i)
            except Exception:
                continue
            # only care about checkbox type (8)
            try:
                cctype = int(cc.Type)
            except Exception:
                cctype = None
            if cctype != 8:
                continue

            tag = (cc.Tag or "").strip()
            title = (cc.Title or "").strip()
            key = tag if tag else title
            if not key:
                # attempt to build a fallback key from small preview text (best-effort)
                try:
                    preview = cc.Range.Text[:80].strip()
                    key = preview
                except Exception:
                    key = ""

            if not key:
                notfound += 1
                continue

            if key in mapping_norm:
                val = mapping_norm[key]
                # remove any literal tokens inside cc.Range (like <<CHK>>)
                try:
                    text_before = cc.Range.Text
                    # remove the token occurrences
                    new_text = re.sub(r'<<CHK>>', '', text_before)
                    if new_text != text_before:
                        cc.Range.Text = new_text
                        replaced_text_count += 1
                except Exception:
                    # ignore edit failures here
                    pass

                # Try to set content-control Checked property
                try:
                    cc.Checked = bool(val)
                    changed += 1
                    print(f"[SET] tag/title={key!r} -> {val}")
                except Exception as e:
                    print(f"[WARN] failed cc.Checked for key={key!r}: {e}")
                    # fallback: replace control with simple text 'X' or clear
                    try:
                        if replace_with_x and val:
                            cc.Range.Text = "X"
                        else:
                            # empty text when false
                            cc.Range.Text = ""
                        changed += 1
                        print(f"       fallback replacement done for {key!r}")
                    except Exception as e2:
                        print(f"       fallback failed too for {key!r}: {e2}")
            else:
                notfound += 1

        base, ext = os.path.splitext(IN)
        out = base + "_filled.docx"
        doc.SaveAs(os.path.abspath(out))
        print("Saved:", out)
        print("Summary: total controls:", total, "changed:", changed, "not matched:", notfound,
              "removed_text_inside_controls:", replaced_text_count)
    finally:
        doc.Close(False)
        word.Quit()

if __name__ == "__main__":
    main()


# python set_checkboxes_from_json_2.py refernce_template_unlocked_forced_escaped_controls_tagged.docx mapping.json

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\set_checkboxes_from_json.py
# ================================
`$lang
# set_checkboxes_from_json.py
import sys, json, os
import win32com.client as com

IN = sys.argv[1]
MAP = sys.argv[2]  # json file: { "tag_or_title": true, "chk": false, ... }

m = json.load(open(MAP, "r", encoding="utf-8"))
word = com.Dispatch("Word.Application")
word.Visible = False
doc = word.Documents.Open(os.path.abspath(IN))
try:
    changed = 0
    for i in range(1, doc.ContentControls.Count+1):
        cc = doc.ContentControls.Item(i)
        tag = (cc.Tag or "").strip()
        title = (cc.Title or "").strip()
        key = tag if tag else title
        if not key:
            continue
        if key in m:
            val = bool(m[key])
            try:
                cc.Checked = val
            except Exception:
                # fallback: replace control with symbol text
                cc.Range.Text = "X" if val else ""
            changed += 1
            print(f"Set {key} -> {val}")
    out = os.path.splitext(IN)[0] + "_filled.docx"
    doc.SaveAs(os.path.abspath(out))
    print("Saved:", out, "changed", changed)
finally:
    doc.Close(False)
    word.Quit()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\set_one_tag.py
# ================================
`$lang
import sys, os
import win32com.client as win32

if len(sys.argv) < 5:
    print("Usage: python set_one_tag.py <docx> <index 1-based> <tag> <title>")
    sys.exit(1)

path   = os.path.abspath(sys.argv[1])
index  = int(sys.argv[2])          # 1-based!
newtag = sys.argv[3]
title  = sys.argv[4]

word = win32.Dispatch("Word.Application")
word.Visible = True
doc  = word.Documents.Open(path)
try:
    ctl = doc.ContentControls.Item(index)   # 1-based COM collection
    ctl.Tag = newtag
    ctl.Title = title
    doc.Save()
    print(f"OK: set Tag='{newtag}', Title='{title}' on control #{index}")
finally:
    doc.Close(SaveChanges=0)
    word.Quit()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\summarize_controls.py
# ================================
`$lang
# summarize_controls.py
import sys, json, csv, pathlib

def from_audit(audit):
    cc = audit.get("content_controls", {})
    print("From audit_report.json:")
    print(" Total content controls:", cc.get("total"))
    print(" By type:", cc.get("by_type"))
    print(" Locked controls:", cc.get("locked_count"))
    print(" Controls with empty Tag or Title:", cc.get("empty_tag_or_title"))
    print(" Checkbox symbol summary:", cc.get("checkbox_symbol_summary"))
    leftovers = audit.get("leftover_tokens", {})
    print(" Leftover chk tokens:", len(leftovers.get("chk_tokens", [])))
    box_hits = leftovers.get("box_glyph_hits", [])
    print(" Leftover box glyph occurrences found:", len(box_hits))
    print()

def inspect_controls_dump(controls_json):
    # expected structure: {"controls": [ {index, tag, title, type, range_preview, context_snippet}, ... ]}
    controls = controls_json.get("controls", [])
    types = {}
    empties = []
    for c in controls:
        t = c.get("type") or c.get("control_type") or "unknown"
        types.setdefault(t, []).append(c)
        if not c.get("tag") or not c.get("title"):
            empties.append(c)
    print("From controls_report.json:")
    print(" Total controls in dump:", len(controls))
    print(" Types breakdown:")
    for t, arr in types.items():
        print(f"  - {t}: {len(arr)}")
    print(" Controls with empty tag/title:", len(empties))
    if empties:
        print(" Listing first 20 empties (index, type, range_preview, context_snippet):")
        for c in empties[:20]:
            print(f"  idx:{c.get('index')} type:{c.get('type')} preview:{c.get('range_preview')!r} ctx:{(c.get('context_snippet') or '')[:80]!r}")
    print()
    return types, empties

def write_csv_controls(controls_json, outfn="controls_flat.csv"):
    controls = controls_json.get("controls", [])
    if not controls:
        print("No controls to write.")
        return
    keys = ["index","type","tag","title","range_preview","context_snippet"]
    with open(outfn, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, keys)
        w.writeheader()
        for c in controls:
            row = {k: c.get(k, "") for k in keys}
            w.writerow(row)
    print("Wrote", outfn)

def main():
    if len(sys.argv) < 2:
        print("Usage: python summarize_controls.py audit_report.json [controls_report.json]")
        return
    audit_fn = sys.argv[1]
    audit = json.load(open(audit_fn, encoding="utf-8"))
    from_audit(audit)
    if len(sys.argv) > 2:
        ctrl_fn = sys.argv[2]
        controls_json = json.load(open(ctrl_fn, encoding="utf-8"))
        types, empties = inspect_controls_dump(controls_json)
        write_csv_controls(controls_json, outfn="controls_flat.csv")
    else:
        print("If you want per-control details (index/tag/title), pass your controls_report.json as the 2nd arg.")

if __name__ == "__main__":
    main()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\unlock_and_replace.py
# ================================
`$lang
import zipfile
import io
import re
from pathlib import Path

INPUT = Path("refernce_template.docx")   # change if needed
OUTPUT = Path("refernce_template_unlocked.docx")

DOC_XML = "word/document.xml"

def read_docx_xml(z, name):
    try:
        data = z.read(name)
        return data.decode("utf-8")
    except KeyError:
        return None

def write_docx_xml(z_out, name, xml_text):
    z_out.writestr(name, xml_text.encode("utf-8"))

def process_docx(in_path: Path, out_path: Path):
    # read input zip
    with zipfile.ZipFile(in_path, 'r') as zin:
        # read document.xml
        doc_xml = read_docx_xml(zin, DOC_XML)
        if doc_xml is None:
            raise RuntimeError("document.xml not found in docx")

        # 1) remove any <w:documentProtection .../> element
        #    (handles both empty-element and start/end pair)
        doc_xml_new = re.sub(r'<w:documentProtection\b[^/>]*(?:/>|>.*?</w:documentProtection>)', '', doc_xml, flags=re.DOTALL)

        # 2) replace all checkbox glyphs with token <<CHK>>
        doc_xml_new = doc_xml_new.replace("☐", "<<CHK>>")

        # copy everything into new zip, but use modified document.xml
        with zipfile.ZipFile(out_path, 'w', compression=zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                if item.filename == DOC_XML:
                    # write modified document.xml
                    write_docx_xml(zout, DOC_XML, doc_xml_new)
                else:
                    # copy as-is
                    zout.writestr(item, zin.read(item.filename))

if __name__ == "__main__":
    if not INPUT.exists():
        print("Input not found:", INPUT)
    else:
        process_docx(INPUT, OUTPUT)
        print("Wrote", OUTPUT)

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\unprotect_doc.py
# ================================
`$lang
# unprotect_doc.py
import sys, os
import win32com.client as com

IN = sys.argv[1] if len(sys.argv)>1 else "refernce_template_unlocked_forced_escaped.docx"
PWD = sys.argv[2] if len(sys.argv)>2 else ""   # put password if there is one

word = com.Dispatch("Word.Application")
word.Visible = False
doc = word.Documents.Open(os.path.abspath(IN))
try:
    try:
        if PWD:
            doc.Unprotect(Password=PWD)
        else:
            doc.Unprotect()
        print("Unprotected (or already unprotected).")
    except Exception as e:
        print("Unprotect failed:", e)
    # save new file
    out = os.path.splitext(IN)[0] + "_unprotected.docx"
    doc.SaveAs(os.path.abspath(out))
    print("Saved:", out)
finally:
    doc.Close(False)
    word.Quit()

`

# ================================
# FILE: C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited_01\validate_and_fix_docx.py
# ================================
`$lang
# validate_and_fix_docx.py
# Run this inside your venv (where lxml is available).
#
# Usage:
#   python validate_and_fix_docx.py
#
# It will create a backup DOCX and write a fixed file with suffix _fixed.docx.
#
import zipfile, os, shutil, re, sys
from lxml import etree

# --- EDIT this to point at your problematic docx file ---
DOCX_PATH = r"C:\Users\K Santosh Kumar\Desktop\HEALTHARK\04_thermofisher\Downloaded_Documents\edited\refernce_template_unlocked_angles_fixed.docx"
# ----------------------------------------------------------------

if not os.path.exists(DOCX_PATH):
    print("DOCX not found:", DOCX_PATH); sys.exit(1)

BASE = os.path.splitext(DOCX_PATH)[0]
BACKUP = BASE + "_repair_bak.docx"
OUTPATH = BASE + "_fixed.docx"
TMPDIR = BASE + "_tmp"

def safe_backup():
    if not os.path.exists(BACKUP):
        shutil.copy2(DOCX_PATH, BACKUP)
        print("Backup created:", BACKUP)
    else:
        print("Backup already exists:", BACKUP)

# remove illegal XML control chars
ILLEGAL_RE = re.compile(
    r'[\x00-\x08\x0B\x0C\x0E-\x1F]'
)

# We know the original problem had literal <<CHK>> inside <w:t>:
# replace both literal and escaped forms with a checkbox glyph
MARKER_REPLACEMENTS = [
    (b'<<CHK>>', '\u2610'),          # literal
    (b'&lt;&lt;CHK&gt;&gt;', '\u2610') # already-escaped
]

def process_parts(in_path, out_path):
    modified = {}
    with zipfile.ZipFile(in_path, 'r') as zin:
        names = zin.namelist()
        # iterate and pre-fix parts that are XML (word/*.xml)
        for name in names:
            data = zin.read(name)
            if name.startswith('word/') and name.endswith('.xml'):
                try:
                    txt = data.decode('utf-8')
                except Exception:
                    # try latin-1 fallback but note this is rare for Word XML
                    txt = data.decode('utf-8', errors='replace')

                orig_txt = txt

                # 1) remove illegal control chars
                txt2 = ILLEGAL_RE.sub('', txt)

                # 2) replace marker forms with checkbox glyph (operate on the decoded text)
                # handle both literal and already-escaped
                txt2 = txt2.replace('<<CHK>>', '\u2610')
                txt2 = txt2.replace('&lt;&lt;CHK&gt;&gt;', '\u2610')

                if txt2 != orig_txt:
                    modified[name] = txt2.encode('utf-8')
                    print(f"Prepared fixes for: {name} (changed)")
                else:
                    # keep original bytes if unchanged
                    modified[name] = None

            else:
                # non-word xml or binary part: keep as-is
                modified[name] = None

        # Build a candidate fixed zip in memory (write changed bytes or original bytes)
        with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as zout:
            for name in names:
                if modified.get(name) is not None:
                    zout.writestr(name, modified[name])
                else:
                    zout.writestr(name, zin.read(name))

    print("Wrote candidate fixed docx to:", out_path)

def validate_docx(path):
    errors = []
    with zipfile.ZipFile(path, 'r') as z:
        for name in z.namelist():
            if name.endswith('.xml'):
                raw = z.read(name)
                try:
                    # try parse
                    etree.fromstring(raw)
                except etree.XMLSyntaxError as e:
                    # collect error info
                    msg = str(e)
                    # try to show snippet around error line/col
                    ln = getattr(e, 'position', (None, None))[0]
                    col = getattr(e, 'position', (None, None))[1]
                    snippet = None
                    try:
                        text = raw.decode('utf-8', errors='replace')
                        if ln is not None and col is not None:
                            lines = text.splitlines()
                            idx = max(0, ln-2)
                            snippet = "\n".join(f"{i+1:5d}: {lines[i]}" for i in range(idx, min(len(lines), ln+1)))
                        else:
                            snippet = text[:2000]
                    except Exception:
                        snippet = "<could not decode snippet>"
                    errors.append({
                        "part": name,
                        "error": msg,
                        "line": ln,
                        "col": col,
                        "snippet": snippet
                    })
    return errors

def main():
    safe_backup()
    process_parts(DOCX_PATH, OUTPATH)

    print("Validating fixed package...")
    errs = validate_docx(OUTPATH)
    if not errs:
        print("Validation passed: no XML syntax errors detected in any .xml parts.")
        print("Try opening", OUTPATH, "in Word (use Open and Repair if Word prompts).")
    else:
        print("Validation found XML errors in the fixed package. Details:")
        for e in errs:
            print("-" * 80)
            print("Part:", e['part'])
            print("Error:", e['error'])
            print("Line:", e['line'], "Col:", e['col'])
            print("Snippet around error (if available):")
            print(e['snippet'][:2000])
            print("-" * 80)
        print("If errors persist, copy & paste the first part+error snippet here and I'll analyze further.")

if __name__ == "__main__":
    main()

`
